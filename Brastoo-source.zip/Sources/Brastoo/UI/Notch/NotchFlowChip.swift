// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import SwiftUI

/// The scene that is on, in the open island's header: its icon, its name and
/// how long it has been on. A click offers to end it, which puts everything
/// back. With no scene on, there is nothing here at all.
struct NotchFlowChip: View {
    /// Beside a camera, or next to the capture actions, the icon alone fits.
    var compact = false
    let openFlow: () -> Void
    @ObservedObject private var l10n = L10n.shared
    @ObservedObject private var engine = FlowEngine.shared

    var body: some View {
        if let active = engine.active {
            let text = FlowStrings.localized(l10n.language)
            NotchMenuButton(title: active.name, items: [
                NotchMenuItem(title: text.endAndRestore, symbol: "stop.fill",
                              action: { FlowEngine.shared.endActive() }),
                .separator,
                NotchMenuItem(title: text.openFlow, symbol: "sparkles", action: openFlow),
            ], cornerRadius: 9) {
                HStack(spacing: 5) {
                    Image(systemName: active.symbol)
                        .font(.system(size: 11, weight: .bold))
                    if !compact {
                        Text(active.name)
                            .font(.system(size: 11.5, weight: .semibold))
                            .lineLimit(1)
                            .frame(maxWidth: 96)
                            .fixedSize()
                        Text(active.startedAt, style: .timer)
                            .font(.system(size: 11, weight: .medium).monospacedDigit())
                            .foregroundStyle(Color.white.opacity(0.62))
                            .lineLimit(1)
                            .fixedSize()
                    }
                }
                .foregroundStyle(Color.white)
                .padding(.horizontal, compact ? 0 : 9)
                .frame(minWidth: 28, minHeight: 28, maxHeight: 28)
                .background(Color.white.opacity(0.11), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 9, style: .continuous)
                        .strokeBorder(Theme.brandBlue.opacity(0.85), lineWidth: 1)
                }
                .contentShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
            }
            .help(active.name)
        }
    }
}
