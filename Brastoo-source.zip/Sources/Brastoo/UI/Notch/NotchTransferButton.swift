// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import SwiftUI

/// File Transfer in the open island's header: always in view, in the brand
/// blue, one click from the transfer window. While something is moving it
/// says how far each direction has gone instead of its name.
struct NotchTransferButton: View {
    /// Beside a camera, or next to the capture actions, there is room for
    /// the arrows only.
    var compact = false
    let action: () -> Void
    @ObservedObject private var l10n = L10n.shared
    @ObservedObject private var transfers = TransferService.shared

    private var title: String { TransferStrings.localized(l10n.language).windowTitle }

    private var label: String {
        let activity = transfers.activity
        var parts: [String] = []
        if let upload = activity.upload { parts.append("↑ \(TransferFormat.percent(upload.fraction))") }
        if let download = activity.download { parts.append("↓ \(TransferFormat.percent(download.fraction))") }
        return parts.isEmpty ? TransferStrings.localized(l10n.language).footerButton : parts.joined(separator: "  ")
    }

    var body: some View {
        Button(action: action) {
            HStack(spacing: 5) {
                Image(systemName: "arrow.up.arrow.down")
                    .font(.system(size: 11, weight: .bold))
                if !compact {
                    Text(label)
                        .font(.system(size: 11.5, weight: .semibold).monospacedDigit())
                        .lineLimit(1)
                        .fixedSize()
                }
            }
            .foregroundStyle(.white)
            .padding(.horizontal, compact ? 0 : 10)
            .frame(minWidth: 28, minHeight: 28, maxHeight: 28)
            .background(Theme.brandBlue, in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
        }
        .buttonStyle(NotchButtonStyle(cornerRadius: 9))
        .help(title)
        .accessibilityLabel(title)
    }
}
