// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import SwiftUI

/// The review itself: one button runs the three analyses, each one shows
/// what it is looking at while it runs, and the results wait to be reviewed
/// before anything is carried out.
struct ReviewOverviewPage: View {
    @ObservedObject private var l10n = L10n.shared
    @ObservedObject private var review = MacReview.shared
    @ObservedObject private var cleaner = JunkCleaner.shared
    @ObservedObject private var protection = ReviewProtection.shared
    @ObservedObject private var speed = ReviewSpeed.shared
    @ObservedObject private var router = MacReviewRouter.shared

    var body: some View {
        ReviewPage {
            ReviewPageHeader(MacReviewText.name, caption: headline) {
                HStack(spacing: 14) {
                    if review.isAnalysing {
                        TimelineView(.animation(minimumInterval: 1.0 / 30)) { moment in
                            Text(ReviewLiveRow.percent(review.overallFraction(at: moment.date)))
                                .font(.system(size: 30, weight: .semibold, design: .rounded).monospacedDigit())
                                .frame(minWidth: 74, alignment: .trailing)
                        }
                    }
                    mainButton
                }
            }
            SettingsCard {
                ForEach(MacReview.Stage.allCases) { stage in
                    if stage != .cleaning { ReviewRule() }
                    row(for: stage)
                }
            }
            footer
        }
    }

    // MARK: - Heading

    private var headline: String {
        switch review.phase {
        case .idle:
            return rv("Três análises, uma depois da outra. Nada é apagado durante a análise: você revê tudo antes.",
                      "Three analyses, one after the other. Nothing is deleted during the analysis: you review everything first.",
                      "Tre analisi, una dopo l'altra. Nulla viene eliminato durante l'analisi: rivedi tutto prima.",
                      "Tres análisis, uno tras otro. Nada se borra durante el análisis: lo revisas todo antes.")
        case .analysing:
            return rv("Analisando o Mac…", "Analysing the Mac…", "Analisi del Mac in corso…", "Analizando el Mac…")
        case .reviewed:
            return rv("Análise concluída. Reveja cada parte ou execute tudo de uma vez.",
                      "Analysis complete. Review each part or carry it all out at once.",
                      "Analisi completata. Rivedi ogni parte o esegui tutto in una volta.",
                      "Análisis terminado. Revisa cada parte o ejecútalo todo de una vez.")
        case .running:
            return rv("Cuidando do Mac…", "Looking after the Mac…", "Mi prendo cura del Mac…", "Cuidando del Mac…")
        case .finished:
            return rv("Pronto.", "All done.", "Fatto.", "Listo.")
        }
    }

    @ViewBuilder
    private var mainButton: some View {
        switch review.phase {
        case .idle:
            Button(rv("Analisar", "Analyse", "Analizza", "Analizar")) { review.analyse() }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .keyboardShortcut(.defaultAction)
        case .analysing:
            Button(rv("Cancelar", "Cancel", "Annulla", "Cancelar")) { review.cancel() }
                .buttonStyle(.link)
            ReviewAnalysingPill()
        case .reviewed, .finished:
            Button(rv("Analisar de novo", "Analyse again", "Analizza di nuovo", "Analizar de nuevo")) { review.analyse() }
                .controlSize(.large)
        case .running:
            ProgressView().controlSize(.small)
        }
    }

    // MARK: - The three stages

    private enum RowState {
        case idle, queued, live, done
    }

    private func state(of stage: MacReview.Stage) -> RowState {
        switch review.phase {
        case .idle: return .idle
        case .analysing(let current):
            if stage.rawValue < current.rawValue { return .done }
            return stage == current ? .live : .queued
        case .reviewed, .running, .finished: return .done
        }
    }

    @ViewBuilder
    private func row(for stage: MacReview.Stage) -> some View {
        switch state(of: stage) {
        case .idle:
            VStack(alignment: .leading, spacing: 3) {
                Text(stage.title).font(.headline)
                Text(stage.caption)
                    .font(.callout)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        case .queued:
            HStack(alignment: .firstTextBaseline) {
                Text(stage.title).font(.headline).foregroundStyle(.secondary)
                Spacer(minLength: 8)
                Text(rv("aguardando", "waiting", "in attesa", "en espera"))
                    .font(.callout)
                    .foregroundStyle(.tertiary)
            }
        case .live:
            ReviewLiveRow(stage: stage)
        case .done:
            HStack(alignment: .center, spacing: 14) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(stage.title).font(.headline)
                    Text(resultCaption(stage))
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 12)
                Text(resultValue(stage))
                    .font(.system(size: 20, weight: .semibold, design: .rounded).monospacedDigit())
                    .lineLimit(1)
                Button(rv("Rever", "Review", "Rivedi", "Revisar")) { router.tab = Self.tab(for: stage) }
                    .disabled(review.phase == .running)
            }
        }
    }

    private static func tab(for stage: MacReview.Stage) -> ReviewTab {
        switch stage {
        case .cleaning: return .cleaning
        case .protection: return .protection
        case .speed: return .speed
        }
    }

    private func resultValue(_ stage: MacReview.Stage) -> String {
        switch stage {
        case .cleaning:
            switch cleaner.phase {
            case .results: return ReviewSizes.text(cleaner.selectedSize)
            case .done(let freed, _): return ReviewSizes.text(freed)
            default: return "–"
            }
        case .protection:
            return protection.phase == .ready ? "\(protection.concerns.count)" : "–"
        case .speed:
            return speed.phase == .ready ? "\(speed.ticked.count)" : "–"
        }
    }

    private func resultCaption(_ stage: MacReview.Stage) -> String {
        switch stage {
        case .cleaning:
            switch cleaner.phase {
            case .results:
                if cleaner.items.isEmpty { return l10n.s.cleanerNothingFound }
                let found = ReviewSizes.text(cleaner.totalSize)
                return rv("marcado para limpar, de \(found) encontrados", "ticked to clean, of \(found) found",
                          "selezionato da pulire, su \(found) trovati", "marcado para limpiar, de \(found) encontrados")
            case .done:
                return rv("foram para a Lixeira", "went to the Trash", "spostati nel Cestino", "fueron a la Papelera")
            case .cleaning:
                return l10n.s.cleanerCleaning
            default:
                return rv("Abra a Limpeza para analisar de novo.", "Open Cleaning to analyse again.",
                          "Apri Pulizia per analizzare di nuovo.", "Abre Limpieza para analizar de nuevo.")
            }
        case .protection:
            let concerns = protection.concerns
            guard !concerns.isEmpty else {
                return rv("Nada pede atenção.", "Nothing asks for attention.", "Nulla richiede attenzione.", "Nada pide atención.")
            }
            let named = concerns.prefix(2).map(\.title).joined(separator: " · ")
            let rest = concerns.count - 2
            return rest > 0 ? named + rv(" e mais \(rest)", " and \(rest) more", " e altri \(rest)", " y \(rest) más") : named
        case .speed:
            let chores = ReviewSpeed.Chore.allCases.filter(speed.ticked.contains)
            guard !chores.isEmpty else {
                return rv("Nenhuma tarefa marcada.", "No chores ticked.", "Nessuna attività selezionata.", "Ninguna tarea marcada.")
            }
            return chores.map(\.title).joined(separator: " · ")
        }
    }

    // MARK: - What comes after

    @ViewBuilder
    private var footer: some View {
        switch review.phase {
        case .idle, .analysing:
            EmptyView()
        case .reviewed:
            SettingsCard {
                Text(plan)
                    .fixedSize(horizontal: false, vertical: true)
                Text(rv("O que é limpo vai para a Lixeira. Para as tarefas que só um administrador pode fazer, o macOS pede a senha uma vez.",
                        "What is cleaned goes to the Trash. For the chores only an administrator may do, macOS asks for the password once.",
                        "Ciò che viene pulito va nel Cestino. Per le attività che solo un amministratore può eseguire, macOS chiede la password una volta.",
                        "Lo que se limpia va a la Papelera. Para las tareas que solo un administrador puede hacer, macOS pide la contraseña una vez."))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Button(rv("Limpar e otimizar", "Clean and optimise", "Pulisci e ottimizza", "Limpiar y optimizar")) { review.run() }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .disabled(!review.hasWork)
            }
        case .running:
            SettingsCard {
                HStack(spacing: 10) {
                    ProgressView().controlSize(.small)
                    Text(review.runningChores
                         ? rv("Executando as tarefas de velocidade…", "Running the speed chores…",
                              "Esecuzione delle attività di velocità…", "Ejecutando las tareas de velocidad…")
                         : l10n.s.cleanerCleaning)
                }
            }
        case .finished:
            SettingsCard {
                Text(review.outcomeSentence)
                    .fixedSize(horizontal: false, vertical: true)
                if review.failed > 0 {
                    Text(review.failed == 1
                         ? rv("1 item não pôde ser movido e ficou onde estava.",
                              "1 item could not be moved and stayed where it was.",
                              "1 elemento non è stato spostato ed è rimasto dov'era.",
                              "1 elemento no se pudo mover y se quedó donde estaba.")
                         : rv("\(review.failed) itens não puderam ser movidos e ficaram onde estavam.",
                              "\(review.failed) items could not be moved and stayed where they were.",
                              "\(review.failed) elementi non sono stati spostati e sono rimasti dov'erano.",
                              "\(review.failed) elementos no se pudieron mover y se quedaron donde estaban."))
                        .font(.caption)
                        .foregroundStyle(.orange)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
    }

    /// What pressing the button will do, in a sentence.
    private var plan: String {
        let size = ReviewSizes.text(review.cleaningSize)
        let chores = speed.ticked.count
        let cleans = cleaner.phase == .results && cleaner.selectedCount > 0
        let tasks = chores == 1
            ? rv("1 tarefa de velocidade", "1 speed chore", "1 attività di velocità", "1 tarea de velocidad")
            : rv("\(chores) tarefas de velocidade", "\(chores) speed chores", "\(chores) attività di velocità", "\(chores) tareas de velocidad")
        switch (cleans, chores > 0) {
        case (true, true):
            return rv("Move \(size) para a Lixeira e executa \(tasks).",
                      "Moves \(size) to the Trash and runs \(tasks).",
                      "Sposta \(size) nel Cestino ed esegue \(tasks).",
                      "Mueve \(size) a la Papelera y ejecuta \(tasks).")
        case (true, false):
            return rv("Move \(size) para a Lixeira.", "Moves \(size) to the Trash.",
                      "Sposta \(size) nel Cestino.", "Mueve \(size) a la Papelera.")
        case (false, true):
            return rv("Executa \(tasks).", "Runs \(tasks).", "Esegue \(tasks).", "Ejecuta \(tasks).")
        case (false, false):
            return rv("Não há nada marcado para fazer.", "There is nothing ticked to do.",
                      "Non c'è nulla di selezionato da fare.", "No hay nada marcado para hacer.")
        }
    }
}

/// The stage being analysed, live.
struct ReviewLiveRow: View {
    let stage: MacReview.Stage

    private let review = MacReview.shared

    static func percent(_ fraction: Double) -> String {
        "\(Int((min(1, max(0, fraction)) * 100).rounded(.down)))%"
    }

    var body: some View {
        ReviewLiveBar(title: stage.title,
                      step: { review.stepName },
                      fraction: { review.fraction(of: stage, at: $0) })
    }
}

/// A scan as it runs: its bar and percentage, and under them the folder or
/// file it is on at this very moment, with the count of everything it has
/// looked at. Drawn again every frame, so the paths go by as fast as the
/// scan reads them.
struct ReviewLiveBar: View {
    let title: String
    /// What the scan is on, in words; asked every frame.
    let step: () -> String
    /// How far it has got at a given moment, from 0 to 1. Nil for a search
    /// with no telling how much is left: the bar then just keeps moving.
    var fraction: ((Date) -> Double)?

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30)) { moment in
            let activity = ScanActivity.shared.latest()
            let reached = fraction?(moment.date)
            VStack(alignment: .leading, spacing: 7) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(title).font(.headline)
                    Text(step())
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    Spacer(minLength: 8)
                    if let reached {
                        Text(ReviewLiveRow.percent(reached))
                            .font(.system(size: 15, weight: .semibold, design: .rounded).monospacedDigit())
                    }
                }
                if let reached {
                    ProgressView(value: reached)
                        .progressViewStyle(.linear)
                } else {
                    ProgressView()
                        .progressViewStyle(.linear)
                }
                Text(activity.text.isEmpty ? " " : ReviewPath.short(activity.text))
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text(activity.count == 1
                     ? rv("1 item verificado", "1 item checked", "1 elemento controllato", "1 elemento comprobado")
                     : rv("\(activity.count.formatted()) itens verificados", "\(activity.count.formatted()) items checked",
                          "\(activity.count.formatted()) elementi controllati", "\(activity.count.formatted()) elementos comprobados"))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.tertiary)
            }
        }
    }
}
