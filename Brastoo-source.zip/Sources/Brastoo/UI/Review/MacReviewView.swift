// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import SwiftUI

/// The pages of the Mac Review window.
enum ReviewTab: String, CaseIterable, Identifiable {
    case overview, cleaning, protection, speed, largeFiles, diskMap, apps, updates

    var id: String { rawValue }

    var title: String {
        switch self {
        case .overview: return rv("Análise", "Analysis", "Analisi", "Análisis")
        case .cleaning: return MacReview.Stage.cleaning.title
        case .protection: return MacReview.Stage.protection.title
        case .speed: return MacReview.Stage.speed.title
        case .largeFiles: return rv("Arquivos grandes", "Large files", "File grandi", "Archivos grandes")
        case .diskMap: return rv("Mapa do disco", "Disk map", "Mappa del disco", "Mapa del disco")
        case .apps: return rv("Gerenciar aplicativos", "Manage apps", "Gestisci applicazioni", "Gestionar aplicaciones")
        case .updates: return FeatureStrings.appUpdates(L10n.shared.language).pageTitle
        }
    }

    var symbol: String {
        switch self {
        case .overview: return "waveform.path.ecg"
        case .cleaning: return "sparkle"
        case .protection: return "lock.shield"
        case .speed: return "gauge.with.needle"
        case .largeFiles: return "doc.text.magnifyingglass"
        case .diskMap: return "chart.pie"
        case .apps: return "square.grid.2x2"
        case .updates: return "arrow.down.app"
        }
    }

    /// 0 for the review itself, 1 for space, 2 for apps.
    var group: Int {
        switch self {
        case .overview, .cleaning, .protection, .speed: return 0
        case .largeFiles, .diskMap: return 1
        case .apps, .updates: return 2
        }
    }

    static func groupTitle(_ group: Int) -> String {
        switch group {
        case 0: return MacReviewText.name
        case 1: return rv("Espaço", "Space", "Spazio", "Espacio")
        default: return rv("Aplicativos", "Apps", "Applicazioni", "Aplicaciones")
        }
    }
}

/// The few names of the review other parts of the app need: its menu item,
/// its panel tile, its row in the Command Bar.
enum MacReviewText {
    static var name: String {
        rv("Revisão do Mac", "Mac Review", "Revisione del Mac", "Revisión del Mac")
    }

    static var panelCaption: String {
        rv("Limpeza, proteção e velocidade em uma análise",
           "Cleaning, protection and speed in one analysis",
           "Pulizia, protezione e velocità in un'unica analisi",
           "Limpieza, protección y velocidad en un análisis")
    }

    static var menuItem: String {
        rv("Revisão do Mac…", "Mac Review…", "Revisione del Mac…", "Revisión del Mac…")
    }

    static var commandTitle: String {
        rv("Abrir a Revisão do Mac", "Open Mac Review", "Apri Revisione del Mac", "Abrir Revisión del Mac")
    }
}

/// Which page the window shows. Other parts of the app set it before opening
/// the window, to land on a page.
final class MacReviewRouter: ObservableObject {
    static let shared = MacReviewRouter()

    @Published var tab = ReviewTab.overview

    private init() {}
}

/// The Mac Review window: the pages in a sidebar, as Settings has them, and
/// the chosen page beside it.
struct MacReviewView: View {
    @ObservedObject private var l10n = L10n.shared
    @ObservedObject private var router = MacReviewRouter.shared
    @ObservedObject private var review = MacReview.shared

    private var selection: Binding<ReviewTab?> {
        Binding(get: { router.tab }, set: { chosen in
            if let chosen { router.tab = chosen }
        })
    }

    var body: some View {
        ZStack {
            pages
            // After a review was carried out the whole window celebrates
            // for a moment, over everything, and then the review starts over.
            if review.celebrating {
                ReviewCelebrationView()
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.35), value: review.celebrating)
        .frame(minWidth: 780, maxWidth: .infinity, minHeight: 520, maxHeight: .infinity)
        .id(l10n.language)
    }

    private var pages: some View {
        NavigationSplitView {
            List(selection: selection) {
                ForEach(0..<3, id: \.self) { group in
                    Section(ReviewTab.groupTitle(group)) {
                        ForEach(ReviewTab.allCases.filter { $0.group == group }) { tab in
                            HStack(spacing: 9) {
                                Image(systemName: tab.symbol)
                                    .foregroundStyle(router.tab == tab ? AnyShapeStyle(.primary) : AnyShapeStyle(.tint))
                                    .frame(width: 18)
                                Text(tab.title)
                            }
                            .tag(tab)
                            .help(tab.title)
                        }
                    }
                }
            }
            .listStyle(.sidebar)
            .navigationSplitViewColumnWidth(min: 198, ideal: 212, max: 250)
        } detail: {
            // The detail is sometimes asked for a size with nothing to fit
            // in; a page that answers with the height of all its rows would
            // grow the window. This reports the room it was really given.
            GeometryReader { geometry in
                page
                    .frame(width: geometry.size.width, height: geometry.size.height, alignment: .top)
            }
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private var page: some View {
        switch router.tab {
        case .overview: ReviewOverviewPage()
        case .cleaning: CleanerView()
        case .protection: ReviewProtectionPage()
        case .speed: ReviewSpeedPage()
        case .largeFiles: ReviewLargeFilesPage()
        case .diskMap: ReviewDiskMapPage()
        case .apps: ReviewAppsPage()
        case .updates: ReviewUpdatesPage()
        }
    }
}

/// The top of a page: its name, a line about it, and room on the right for
/// the page's main button. The same heading the redesigned Settings pages
/// carry.
struct ReviewPageHeader<Trailing: View>: View {
    let title: String
    let caption: String
    private let trailing: Trailing

    init(_ title: String, caption: String, @ViewBuilder trailing: () -> Trailing) {
        self.title = title
        self.caption = caption
        self.trailing = trailing()
    }

    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.title2.bold())
                Text(caption)
                    .font(.callout)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 12)
            trailing
        }
    }
}

extension ReviewPageHeader where Trailing == EmptyView {
    init(_ title: String, caption: String) {
        self.init(title, caption: caption) { EmptyView() }
    }
}

/// A page laid out the way the redesigned Settings pages are: one column of
/// cards, never wider than is comfortable to read, scrolling when it is long.
struct ReviewPage<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                content
            }
            .frame(maxWidth: 760)
            .frame(maxWidth: .infinity)
            .padding(22)
        }
    }
}

/// The hairline between the rows of a card.
struct ReviewRule: View {
    var body: some View {
        Divider().opacity(0.7)
    }
}

/// The dot that says how much a line matters.
struct ReviewDot: View {
    let weight: ReviewFinding.Weight

    var body: some View {
        Circle()
            .fill(color)
            .frame(width: 8, height: 8)
            .accessibilityHidden(true)
    }

    private var color: Color {
        switch weight {
        case .danger: return .red
        case .attention: return .orange
        case .note: return .accentColor
        case .fine: return .green
        }
    }
}

/// A path the way a person reads one: the home folder as a tilde.
enum ReviewPath {
    private static let home = NSHomeDirectory()

    static func short(_ path: String) -> String {
        // The root of the startup disk goes by the name the Finder gives it.
        if path == "/" { return FileManager.default.displayName(atPath: "/") }
        return path.hasPrefix(home) ? "~" + String(path.dropFirst(home.count)) : path
    }
}
