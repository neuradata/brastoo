// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import AppKit
import SwiftUI

extension MacReview {
    /// What the last run did, in a sentence.
    var outcomeSentence: String {
        let size = ReviewSizes.text(freed)
        let chores = choresDone
        let done = chores == 1
            ? rv("1 tarefa foi feita", "1 chore was done", "1 attività eseguita", "se hizo 1 tarea")
            : rv("\(chores) tarefas foram feitas", "\(chores) chores were done", "\(chores) attività eseguite", "se hicieron \(chores) tareas")
        if freed > 0, chores > 0 {
            return rv("\(size) foram para a Lixeira e \(done).",
                      "\(size) went to the Trash and \(done).",
                      "\(size) spostati nel Cestino e \(done).",
                      "\(size) fueron a la Papelera y \(done).")
        }
        if freed > 0 {
            return rv("\(size) foram para a Lixeira.", "\(size) went to the Trash.",
                      "\(size) spostati nel Cestino.", "\(size) fueron a la Papelera.")
        }
        if chores > 0 {
            return done.prefix(1).uppercased() + String(done.dropFirst()) + "."
        }
        return rv("Nada foi alterado.", "Nothing was changed.", "Nulla è stato modificato.", "No se cambió nada.")
    }
}

/// What the window shows for a few seconds after a review was carried out:
/// the Mac in the middle with sparkles going off around it, confetti coming
/// down, and what was done underneath. A click sends it away early.
///
/// With Reduce Motion on, nothing moves: the Mac and the words are there.
struct ReviewCelebrationView: View {
    @ObservedObject private var review = MacReview.shared
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var began = Date()

    private static let macSize: CGFloat = 210

    var body: some View {
        ZStack {
            Color(nsColor: .windowBackgroundColor)
            TimelineView(.animation(paused: reduceMotion)) { moment in
                let time = reduceMotion ? 0 : moment.date.timeIntervalSince(began)
                ZStack {
                    if !reduceMotion {
                        Canvas { context, size in
                            ReviewConfetti.draw(in: context, size: size, time: time)
                        }
                    }
                    VStack(spacing: 14) {
                        ZStack {
                            mac
                                .offset(y: sin(time * 1.5) * 4)
                                .scaleEffect(1 + 0.012 * sin(time * 1.5 + 1))
                            if !reduceMotion {
                                Canvas { context, size in
                                    ReviewSparkles.draw(in: context, size: size, time: time)
                                }
                            }
                        }
                        .frame(width: Self.macSize + 150, height: Self.macSize + 60)
                        Text(rv("Seu Mac está novo de novo", "Your Mac is like new again",
                                "Il tuo Mac è di nuovo come nuovo", "Tu Mac está como nuevo otra vez"))
                            .font(.system(size: 28, weight: .bold))
                        Text(review.outcomeSentence)
                            .font(.title3)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.horizontal, 40)
                }
            }
        }
        .contentShape(Rectangle())
        .onTapGesture { review.startOver() }
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isButton)
    }

    /// This Mac as the system draws it; a laptop where it has no picture.
    @ViewBuilder
    private var mac: some View {
        if let picture = NSImage(named: NSImage.computerName) {
            Image(nsImage: picture)
                .resizable()
                .interpolation(.high)
                .aspectRatio(contentMode: .fit)
                .frame(width: Self.macSize, height: Self.macSize)
                .shadow(color: .black.opacity(0.28), radius: 18, y: 10)
        } else {
            Text(verbatim: "💻")
                .font(.system(size: Self.macSize * 0.7))
        }
    }
}

/// Numbers between 0 and 1 that look random and are the same every time,
/// so each piece of confetti keeps its colour, pace and sway from frame to
/// frame without anything being stored.
private func scattered(_ index: Int, _ salt: Int) -> Double {
    let value = sin(Double(index) * 12.9898 + Double(salt) * 78.233) * 43_758.5453
    return value - value.rounded(.down)
}

/// Confetti falling without end: each piece drifts down at its own pace,
/// swaying and tumbling, and comes back in at the top.
private enum ReviewConfetti {
    private static let pieces = 120
    private static let colours: [Color] = [
        Theme.brandBlue,
        Color(red: 1.00, green: 0.80, blue: 0.16),
        Color(red: 1.00, green: 0.36, blue: 0.52),
        Color(red: 0.30, green: 0.82, blue: 0.50),
        Color(red: 1.00, green: 0.56, blue: 0.20),
        Color(red: 0.62, green: 0.46, blue: 0.96),
        Color(red: 0.36, green: 0.80, blue: 0.94),
    ]

    static func draw(in context: GraphicsContext, size: CGSize, time: Double) {
        for index in 0..<pieces {
            let pace = 0.09 + 0.13 * scattered(index, 2)
            let fall = scattered(index, 3) + time * pace
            let y = (fall - fall.rounded(.down)) * (size.height + 60) - 30
            let sway = sin(time * (0.8 + 1.6 * scattered(index, 4)) + 6.283 * scattered(index, 5)) * 22
            let x = scattered(index, 1) * size.width + sway
            let width = 7 + 6 * scattered(index, 8)
            let height = 4 + 4 * scattered(index, 9)
            // A flat piece turning over in the air is seen now full, now edge on.
            let turn = cos(time * (2 + 4 * scattered(index, 7)) + 6.283 * scattered(index, 10))

            var piece = context
            piece.translateBy(x: x, y: y)
            piece.rotate(by: .radians(time * (0.8 + 2.4 * scattered(index, 6)) + 6.283 * scattered(index, 11)))
            piece.scaleBy(x: 1, y: max(0.12, abs(turn)))
            piece.opacity = 0.92
            let shape = Path(roundedRect: CGRect(x: -width / 2, y: -height / 2, width: width, height: height),
                             cornerRadius: 1.2)
            piece.fill(shape, with: .color(colours[index % colours.count]))
        }
    }
}

/// Little stars going off around the Mac, each in its own place and at its
/// own beat: it opens, turns a little, throws a few specks and is gone.
private enum ReviewSparkles {
    /// Where each one goes off, from the middle, as a share of the room.
    /// On the Mac itself: the corners of its screen, its lid, its base.
    private static let places: [CGPoint] = [
        CGPoint(x: -0.21, y: -0.21), CGPoint(x: 0.22, y: -0.23), CGPoint(x: -0.25, y: 0.02),
        CGPoint(x: 0.25, y: -0.02), CGPoint(x: -0.17, y: 0.20), CGPoint(x: 0.19, y: 0.19),
        CGPoint(x: 0.01, y: -0.27), CGPoint(x: -0.08, y: -0.06), CGPoint(x: 0.10, y: 0.05),
        CGPoint(x: -0.28, y: 0.21), CGPoint(x: 0.29, y: 0.22), CGPoint(x: 0.03, y: 0.23),
    ]

    static func draw(in context: GraphicsContext, size: CGSize, time: Double) {
        for (index, place) in places.enumerated() {
            let beat = 1.1 + 0.9 * scattered(index, 21)
            let turn = (time + beat * scattered(index, 22)) / beat
            let progress = (turn - turn.rounded(.down)) / 0.6
            guard progress < 1 else { continue }
            let swell = sin(.pi * progress)
            let centre = CGPoint(x: size.width / 2 + place.x * size.width,
                                 y: size.height / 2 + place.y * size.height)
            let reach = (11 + 13 * scattered(index, 23)) * swell

            var star = context
            star.translateBy(x: centre.x, y: centre.y)
            star.rotate(by: .radians(progress * 0.9))
            star.opacity = min(1, swell * 1.6)
            star.addFilter(.shadow(color: Color(red: 1, green: 0.86, blue: 0.3).opacity(0.9), radius: 5))
            star.fill(fourPoints(reach), with: .color(Color(red: 1.0, green: 0.84, blue: 0.22)))
            star.fill(fourPoints(reach * 0.45), with: .color(.white))

            // The specks it throws: out along six lines, fading as they go.
            var specks = context
            specks.translateBy(x: centre.x, y: centre.y)
            specks.opacity = max(0, 1 - progress) * 0.9
            for ray in 0..<6 {
                let angle = Double(ray) / 6 * 2 * .pi + scattered(index, 24)
                let distance = (10 + 22 * scattered(index, 25)) * progress + 6
                let dot = CGRect(x: cos(angle) * distance - 1.4, y: sin(angle) * distance - 1.4, width: 2.8, height: 2.8)
                specks.fill(Path(ellipseIn: dot), with: .color(Color(red: 1.0, green: 0.9, blue: 0.5)))
            }
        }
    }

    /// A star of four long points, as a sparkle is drawn.
    private static func fourPoints(_ reach: Double) -> Path {
        var path = Path()
        let waist = reach * 0.2
        for corner in 0..<8 {
            let angle = Double(corner) / 8 * 2 * .pi - .pi / 2
            let radius = corner.isMultiple(of: 2) ? reach : waist
            let point = CGPoint(x: cos(angle) * radius, y: sin(angle) * radius)
            if corner == 0 {
                path.move(to: point)
            } else {
                path.addLine(to: point)
            }
        }
        path.closeSubpath()
        return path
    }
}

/// The main button while an analysis runs: it says so, and a soft line of
/// many colours travels round its edge. It is a sign, not a control; Cancel
/// sits beside it.
struct ReviewAnalysingPill: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private static let colours: [Color] = [
        Color(red: 0.04, green: 0.55, blue: 0.89),
        Color(red: 0.55, green: 0.42, blue: 0.98),
        Color(red: 1.00, green: 0.38, blue: 0.58),
        Color(red: 1.00, green: 0.72, blue: 0.24),
        Color(red: 0.28, green: 0.84, blue: 0.62),
        Color(red: 0.04, green: 0.55, blue: 0.89),
    ]

    var body: some View {
        Text(rv("Analisando…", "Analysing…", "Analisi…", "Analizando…"))
            .font(.system(size: 13, weight: .medium))
            .padding(.horizontal, 16)
            .padding(.vertical, 7.5)
            .background(Capsule().fill(.quaternary.opacity(0.6)))
            .overlay {
                TimelineView(.animation(paused: reduceMotion)) { moment in
                    // Kept within one turn: a gradient loses its colours when
                    // handed an angle of billions of degrees.
                    let seconds = moment.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 3)
                    let angle = Angle.degrees(seconds * 120)
                    let line = AngularGradient(colors: Self.colours, center: .center, angle: angle)
                    ZStack {
                        Capsule().strokeBorder(line, lineWidth: 3.5)
                            .blur(radius: 5)
                            .opacity(0.75)
                        Capsule().strokeBorder(line, lineWidth: 1.6)
                    }
                }
            }
            .accessibilityLabel(rv("Analisando", "Analysing", "Analisi in corso", "Analizando"))
    }
}
