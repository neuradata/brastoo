// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import AppKit
import SwiftUI

// MARK: - Protection

/// What the protection analysis found, the gravest first, each with the
/// button that takes the person to where it is fixed.
struct ReviewProtectionPage: View {
    @ObservedObject private var protection = ReviewProtection.shared
    @ObservedObject private var review = MacReview.shared
    @State private var glide = ReviewGlide()

    var body: some View {
        ReviewPage {
            ReviewPageHeader(MacReview.Stage.protection.title,
                             caption: rv("Confere as proteções do macOS, o que abre sozinho, quem assinou os apps e o que pode ver a sua navegação. Não é um antivírus.",
                                         "Checks macOS's protections, what starts by itself, who signed the apps and what can see your browsing. It is not an antivirus.",
                                         "Controlla le protezioni di macOS, cosa si avvia da solo, chi ha firmato le app e cosa può vedere la tua navigazione. Non è un antivirus.",
                                         "Comprueba las protecciones de macOS, lo que se abre solo, quién firmó las apps y qué puede ver tu navegación. No es un antivirus.")) {
                Button(protection.phase == .ready
                       ? rv("Analisar de novo", "Analyse again", "Analizza di nuovo", "Analizar de nuevo")
                       : rv("Analisar", "Analyse", "Analizza", "Analizar")) {
                    protection.scan()
                }
                .controlSize(.large)
                .disabled(protection.phase == .scanning || review.isAnalysing)
            }
            switch protection.phase {
            case .idle:
                SettingsCard {
                    Text(rv("Ainda não analisado.", "Not analysed yet.", "Non ancora analizzato.", "Aún sin analizar."))
                        .foregroundStyle(.secondary)
                }
            case .scanning:
                SettingsCard {
                    ReviewLiveBar(title: MacReview.Stage.protection.title,
                                  step: { protection.step },
                                  fraction: { glide.value(toward: protection.progress.current, at: $0) })
                }
                .onAppear { glide.reset() }
            case .ready:
                group(rv("Pede atenção", "Asks for attention", "Richiede attenzione", "Pide atención"),
                      protection.findings.filter { $0.weight == .danger || $0.weight == .attention })
                group(rv("Para saber", "Good to know", "Da sapere", "Para saber"),
                      protection.findings.filter { $0.weight == .note })
                group(rv("Em ordem", "In order", "In ordine", "En orden"),
                      protection.findings.filter { $0.weight == .fine })
            }
        }
    }

    @ViewBuilder
    private func group(_ title: String, _ findings: [ReviewFinding]) -> some View {
        if !findings.isEmpty {
            SettingsCard(title: title) {
                ForEach(Array(findings.enumerated()), id: \.element.id) { index, finding in
                    if index > 0 { ReviewRule() }
                    ReviewFindingRow(finding: finding)
                }
            }
        }
    }
}

private struct ReviewFindingRow: View {
    let finding: ReviewFinding

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            ReviewDot(weight: finding.weight)
                .padding(.top, 5)
            VStack(alignment: .leading, spacing: 2) {
                Text(finding.title)
                    .fixedSize(horizontal: false, vertical: true)
                Text(finding.detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .textSelection(.enabled)
            }
            Spacer(minLength: 12)
            if let path = finding.path {
                Button(L10n.shared.s.cleanerRevealInFinder) {
                    NSWorkspace.shared.activateFileViewerSelecting([path])
                }
                .controlSize(.small)
            }
            if let title = finding.fixTitle, let fix = finding.fix {
                Button(title) {
                    DispatchQueue.global(qos: .userInitiated).async(execute: fix)
                }
                .controlSize(.small)
            }
        }
    }
}

// MARK: - Speed

/// What the speed analysis measured, and the chores: tick the ones wanted
/// and run them together.
struct ReviewSpeedPage: View {
    @ObservedObject private var speed = ReviewSpeed.shared
    @ObservedObject private var review = MacReview.shared
    @State private var glide = ReviewGlide()

    private var tickedChores: [ReviewSpeed.Chore] {
        ReviewSpeed.Chore.allCases.filter(speed.ticked.contains)
    }

    var body: some View {
        ReviewPage {
            ReviewPageHeader(MacReview.Stage.speed.title,
                             caption: rv("O que está pesando no Mac agora e as tarefas de manutenção que ajudam. As que pedem senha de administrador rodam juntas, com um pedido só.",
                                         "What is weighing on the Mac right now and the maintenance chores that help. Those that need the administrator password run together, with one request.",
                                         "Cosa sta pesando sul Mac ora e le attività di manutenzione che aiutano. Quelle che richiedono la password di amministratore vengono eseguite insieme, con una sola richiesta.",
                                         "Lo que está pesando en el Mac ahora y las tareas de mantenimiento que ayudan. Las que piden la contraseña de administrador se ejecutan juntas, con una sola petición.")) {
                Button(speed.phase == .ready
                       ? rv("Analisar de novo", "Analyse again", "Analizza di nuovo", "Analizar de nuevo")
                       : rv("Analisar", "Analyse", "Analizza", "Analizar")) {
                    speed.analyse()
                }
                .controlSize(.large)
                .disabled(speed.phase == .analysing || speed.running || review.isAnalysing)
            }
            if speed.phase == .analysing {
                SettingsCard {
                    ReviewLiveBar(title: MacReview.Stage.speed.title,
                                  step: { speed.step },
                                  fraction: { glide.value(toward: speed.progress.current, at: $0) })
                }
                .onAppear { glide.reset() }
            } else if !speed.readings.isEmpty {
                SettingsCard(title: rv("Agora", "Right now", "Adesso", "Ahora")) {
                    ForEach(Array(speed.readings.enumerated()), id: \.element.id) { index, reading in
                        if index > 0 { ReviewRule() }
                        readingRow(reading)
                    }
                }
            }
            SettingsCard(title: rv("Tarefas", "Chores", "Attività", "Tareas")) {
                ForEach(Array(ReviewSpeed.Chore.allCases.enumerated()), id: \.element.id) { index, chore in
                    if index > 0 { ReviewRule() }
                    choreRow(chore)
                }
            }
            HStack(spacing: 12) {
                Button {
                    speed.run()
                } label: {
                    Text(tickedChores.isEmpty
                         ? rv("Executar", "Run", "Esegui", "Ejecutar")
                         : tickedChores.count == 1
                         ? rv("Executar 1 tarefa", "Run 1 chore", "Esegui 1 attività", "Ejecutar 1 tarea")
                         : rv("Executar \(tickedChores.count) tarefas", "Run \(tickedChores.count) chores",
                              "Esegui \(tickedChores.count) attività", "Ejecutar \(tickedChores.count) tareas"))
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(tickedChores.isEmpty || speed.running || review.phase == .running)
                if speed.running {
                    ProgressView().controlSize(.small)
                }
                if let freed = speed.memoryFreed {
                    Text(rv("\(ReviewSizes.memoryText(freed)) de memória liberados", "\(ReviewSizes.memoryText(freed)) of memory freed",
                            "\(ReviewSizes.memoryText(freed)) di memoria liberati", "\(ReviewSizes.memoryText(freed)) de memoria liberados"))
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
            }
            if let report = speed.diskReport, !report.isEmpty {
                Text(report)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)
            }
        }
    }

    private func readingRow(_ reading: ReviewSpeed.Reading) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                if reading.weight != .fine {
                    ReviewDot(weight: reading.weight)
                }
                Text(reading.name)
                Spacer(minLength: 12)
                Text(reading.value)
                    .font(.body.monospacedDigit())
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            if let note = reading.note {
                Text(note)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private func choreRow(_ chore: ReviewSpeed.Chore) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Toggle("", isOn: Binding(get: { speed.ticked.contains(chore) }, set: { on in
                if on {
                    speed.ticked.insert(chore)
                } else {
                    speed.ticked.remove(chore)
                }
            }))
            .toggleStyle(.checkbox)
            .labelsHidden()
            .disabled(speed.running)
            .accessibilityLabel(chore.title)
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(chore.title)
                    if speed.suggested.contains(chore) {
                        Text(rv("sugerida", "suggested", "consigliata", "sugerida"))
                            .font(.system(size: 9, weight: .bold))
                            .foregroundStyle(Color.white)
                            .padding(.horizontal, 5)
                            .padding(.vertical, 1)
                            .background(Capsule().fill(Color.accentColor))
                    }
                }
                Text(chore.needsAdmin
                     ? chore.caption + " " + rv("Pede a senha de administrador.", "Asks for the administrator password.",
                                                "Richiede la password di amministratore.", "Pide la contraseña de administrador.")
                     : chore.caption)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 12)
            switch speed.outcomes[chore] {
            case .done?:
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 17))
                    .foregroundStyle(.green)
                    .help(rv("Tarefa já concluída nesta sessão", "Chore already done in this session",
                             "Attività già eseguita in questa sessione", "Tarea ya hecha en esta sesión"))
                    .accessibilityLabel(rv("Tarefa já concluída nesta sessão", "Chore already done in this session",
                                           "Attività già eseguita in questa sessione", "Tarea ya hecha en esta sesión"))
            case .failed?:
                Text(rv("não foi feita", "not done", "non eseguita", "no se hizo"))
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.orange)
            case nil:
                EmptyView()
            }
        }
    }
}

// MARK: - Large files

/// The largest files of the chosen folders, and the ones not opened in a
/// long time. Ticked ones go to the Trash.
struct ReviewLargeFilesPage: View {
    @ObservedObject private var files = ReviewLargeFiles.shared

    /// Dates in the app's language, which need not be the system's.
    private static func day(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: L10n.shared.language.rawValue)
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter.string(from: date)
    }

    var body: some View {
        ReviewPage {
            ReviewPageHeader(ReviewTab.largeFiles.title,
                             caption: rv("Os arquivos maiores das suas pastas e os que você não abre há muito tempo.",
                                         "The largest files in your folders and the ones you have not opened in a long time.",
                                         "I file più grandi delle tue cartelle e quelli che non apri da molto tempo.",
                                         "Los archivos más grandes de tus carpetas y los que no abres desde hace mucho.")) {
                if files.scanning {
                    Button(rv("Parar", "Stop", "Ferma", "Parar")) { files.cancel() }
                        .controlSize(.large)
                } else {
                    Button(rv("Buscar", "Search", "Cerca", "Buscar")) { files.scan() }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                }
            }
            SettingsCard {
                HStack(spacing: 14) {
                    Picker(rv("A partir de", "From", "A partire da", "A partir de"), selection: $files.smallest) {
                        ForEach(ReviewLargeFiles.sizes, id: \.self) { size in
                            Text(ReviewSizes.text(size)).tag(size)
                        }
                    }
                    .fixedSize()
                    Picker(rv("Sem abrir há", "Not opened for", "Non aperti da", "Sin abrir desde hace"), selection: $files.months) {
                        ForEach(ReviewLargeFiles.ages, id: \.self) { months in
                            Text(months == 0
                                 ? rv("qualquer tempo", "any time", "qualsiasi periodo", "cualquier tiempo")
                                 : rv("\(months) meses", "\(months) months", "\(months) mesi", "\(months) meses")).tag(months)
                        }
                    }
                    .fixedSize()
                    Spacer(minLength: 8)
                    Button(rv("Pastas…", "Folders…", "Cartelle…", "Carpetas…")) { files.chooseFolders() }
                }
                .disabled(files.scanning)
                Text(files.folders.map { ReviewPath.short($0.path) }.joined(separator: "  ·  "))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            if files.scanning {
                SettingsCard {
                    ReviewLiveBar(title: rv("Procurando", "Searching", "Ricerca in corso", "Buscando"), step: { "" })
                }
            } else if files.entries.isEmpty {
                if files.hasScanned {
                    SettingsCard {
                        Text(rv("Nenhum arquivo desse tamanho nessas pastas.", "No files of that size in those folders.",
                                "Nessun file di quelle dimensioni in quelle cartelle.", "Ningún archivo de ese tamaño en esas carpetas."))
                            .foregroundStyle(.secondary)
                    }
                }
            } else {
                SettingsCard {
                    LazyVStack(alignment: .leading, spacing: 9) {
                        ForEach(Array(files.entries.enumerated()), id: \.element.id) { index, entry in
                            if index > 0 { ReviewRule() }
                            fileRow(entry)
                        }
                    }
                }
                HStack(spacing: 12) {
                    Button(rv("Mover para a Lixeira", "Move to Trash", "Sposta nel Cestino", "Mover a la Papelera")) { files.trashTicked() }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                        .disabled(files.ticked.isEmpty)
                    if !files.ticked.isEmpty {
                        Text("\(files.ticked.count) · \(ReviewSizes.text(files.tickedSize))")
                            .font(.callout.monospacedDigit())
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }

    private func fileRow(_ entry: ReviewLargeFiles.Entry) -> some View {
        HStack(spacing: 10) {
            Toggle("", isOn: Binding(get: { files.ticked.contains(entry.id) }, set: { on in
                if on {
                    files.ticked.insert(entry.id)
                } else {
                    files.ticked.remove(entry.id)
                }
            }))
            .toggleStyle(.checkbox)
            .labelsHidden()
            .accessibilityLabel(FileManager.default.displayName(atPath: entry.url.path))
            Image(nsImage: NSWorkspace.shared.icon(forFile: entry.url.path))
                .resizable()
                .frame(width: 24, height: 24)
            VStack(alignment: .leading, spacing: 1) {
                // As the Finder names it: an app without its ".app".
                Text(FileManager.default.displayName(atPath: entry.url.path))
                    .lineLimit(1)
                    .truncationMode(.middle)
                Text(ReviewPath.short(entry.url.deletingLastPathComponent().path))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.head)
            }
            Spacer(minLength: 12)
            if let opened = entry.lastOpened {
                Text(Self.day(opened))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Text(ReviewSizes.text(entry.size))
                .font(.body.monospacedDigit())
                .frame(minWidth: 76, alignment: .trailing)
        }
        .contextMenu {
            Button(L10n.shared.s.cleanerRevealInFinder) {
                NSWorkspace.shared.activateFileViewerSelecting([entry.url])
            }
        }
    }
}

// MARK: - Disk map

/// How a folder's space is divided among what is inside it. A double click
/// goes into a folder.
struct ReviewDiskMapPage: View {
    @ObservedObject private var map = ReviewDiskMap.shared

    var body: some View {
        ReviewPage {
            ReviewPageHeader(ReviewTab.diskMap.title,
                             caption: rv("Quanto cada pasta ocupa. Dois cliques entram na pasta.",
                                         "How much each folder takes. A double click goes into the folder.",
                                         "Quanto occupa ogni cartella. Un doppio clic entra nella cartella.",
                                         "Cuánto ocupa cada carpeta. Un doble clic entra en la carpeta.")) {
                Button(rv("Atualizar", "Refresh", "Aggiorna", "Actualizar")) { map.refresh() }
                    .controlSize(.large)
            }
            SettingsCard {
                HStack(spacing: 10) {
                    Button {
                        map.goUp()
                    } label: {
                        Image(systemName: "chevron.up")
                    }
                    .disabled(!map.canGoUp)
                    .help(rv("Pasta superior", "Enclosing folder", "Cartella superiore", "Carpeta superior"))
                    Text(ReviewPath.short(map.location.path))
                        .lineLimit(1)
                        .truncationMode(.head)
                    Spacer(minLength: 12)
                    if map.measuring {
                        ProgressView().controlSize(.small)
                    }
                    Text(ReviewSizes.text(map.total))
                        .font(.body.monospacedDigit().weight(.semibold))
                }
            }
            if !map.entries.isEmpty {
                let largest = max(1, map.entries.compactMap(\.size).max() ?? 1)
                SettingsCard {
                    LazyVStack(alignment: .leading, spacing: 9) {
                        ForEach(Array(map.entries.enumerated()), id: \.element.id) { index, entry in
                            if index > 0 { ReviewRule() }
                            mapRow(entry, largest: largest)
                        }
                    }
                }
            }
        }
        .onAppear {
            if map.entries.isEmpty { map.open(map.location) }
        }
    }

    private func mapRow(_ entry: ReviewDiskMap.Entry, largest: Int64) -> some View {
        HStack(spacing: 10) {
            Image(nsImage: NSWorkspace.shared.icon(forFile: entry.url.path))
                .resizable()
                .frame(width: 22, height: 22)
            Text(FileManager.default.displayName(atPath: entry.url.path))
                .lineLimit(1)
                .truncationMode(.middle)
                .frame(width: 220, alignment: .leading)
            if let size = entry.size {
                ProgressView(value: Double(size), total: Double(largest))
                    .progressViewStyle(.linear)
                Text(ReviewSizes.text(size))
                    .font(.body.monospacedDigit())
                    .frame(width: 84, alignment: .trailing)
            } else {
                Spacer(minLength: 8)
                ProgressView().controlSize(.mini)
            }
        }
        .contentShape(Rectangle())
        .onTapGesture(count: 2) {
            if entry.isFolder { map.open(entry.url) }
        }
        .contextMenu {
            Button(L10n.shared.s.cleanerRevealInFinder) {
                NSWorkspace.shared.activateFileViewerSelecting([entry.url])
            }
            Button(rv("Mover para a Lixeira", "Move to Trash", "Sposta nel Cestino", "Mover a la Papelera")) { map.trash(entry) }
        }
    }
}

// MARK: - Apps

/// The apps on the Mac, to decide which to keep. Uninstalling one is handed
/// to the Uninstaller, which lists everything the app left around first.
struct ReviewAppsPage: View {
    @ObservedObject private var apps = ReviewApps.shared
    @State private var query = ""

    /// "há 2 semanas", in the app's language, which need not be the system's.
    private static func ago(_ date: Date) -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.locale = Locale(identifier: L10n.shared.language.rawValue)
        formatter.unitsStyle = .full
        formatter.dateTimeStyle = .named
        return formatter.localizedString(for: date, relativeTo: Date())
    }

    var body: some View {
        let shown = apps.ordered(matching: query)
        ReviewPage {
            ReviewPageHeader(ReviewTab.apps.title,
                             caption: rv("Quanto espaço cada app ocupa e quando foi aberto pela última vez. Desinstalar passa pelo Desinstalador, que mostra tudo o que o app deixou no Mac antes de remover.",
                                         "How much room each app takes and when it was last opened. Uninstalling goes through the Uninstaller, which shows everything the app left on the Mac before removing it.",
                                         "Quanto spazio occupa ogni app e quando è stata aperta l'ultima volta. La disinstallazione passa dal Disinstallatore, che mostra tutto ciò che l'app ha lasciato sul Mac prima di rimuoverla.",
                                         "Cuánto espacio ocupa cada app y cuándo se abrió por última vez. Desinstalar pasa por el Desinstalador, que muestra todo lo que la app dejó en el Mac antes de eliminarla.")) {
                Button(rv("Atualizar", "Refresh", "Aggiorna", "Actualizar")) { apps.load() }
                    .controlSize(.large)
                    .disabled(apps.loading)
            }
            SettingsCard {
                HStack(spacing: 12) {
                    TextField(L10n.shared.s.uninstallerPickerSearch, text: $query)
                        .textFieldStyle(.roundedBorder)
                    Picker("", selection: $apps.order) {
                        ForEach(ReviewApps.Order.allCases) { order in
                            Text(order.title).tag(order)
                        }
                    }
                    .pickerStyle(.segmented)
                    .labelsHidden()
                    .fixedSize()
                }
                if !apps.apps.isEmpty {
                    Text(summary)
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }
            if apps.loading && apps.apps.isEmpty {
                SettingsCard {
                    HStack(spacing: 10) {
                        ProgressView().controlSize(.small)
                        Text(L10n.shared.s.uninstallerScanning).foregroundStyle(.secondary)
                    }
                }
            } else if !shown.isEmpty {
                SettingsCard {
                    LazyVStack(alignment: .leading, spacing: 9) {
                        ForEach(Array(shown.enumerated()), id: \.element.id) { index, line in
                            if index > 0 { ReviewRule() }
                            appRow(line)
                        }
                    }
                }
            }
        }
        .onAppear {
            if apps.apps.isEmpty { apps.load() }
        }
    }

    /// How many apps, and how much room they take once that is known.
    private var summary: String {
        let count = apps.apps.count
        let counted = count == 1 ? rv("1 app", "1 app", "1 app", "1 app")
            : rv("\(count) apps", "\(count) apps", "\(count) app", "\(count) apps")
        let total = apps.totalSize
        return total > 0 ? "\(counted) · \(ReviewSizes.text(total))" : counted
    }

    private func appRow(_ line: ReviewApps.AppLine) -> some View {
        HStack(spacing: 10) {
            Image(nsImage: line.app.icon)
                .resizable()
                .frame(width: 30, height: 30)
            VStack(alignment: .leading, spacing: 1) {
                Text(line.app.name)
                    .lineLimit(1)
                Text(detail(line))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 12)
            if let size = line.size {
                Text(ReviewSizes.text(size))
                    .font(.body.monospacedDigit())
            } else {
                ProgressView().controlSize(.mini)
            }
            Menu {
                Button(rv("Abrir", "Open", "Apri", "Abrir")) { apps.open(line) }
                Button(L10n.shared.s.cleanerRevealInFinder) { apps.reveal(line) }
                if apps.isRunning(line) {
                    Button(rv("Encerrar", "Quit", "Esci", "Salir")) { apps.quit(line) }
                }
                Divider()
                Button(rv("Desinstalar…", "Uninstall…", "Disinstalla…", "Desinstalar…")) { apps.uninstall(line) }
            } label: {
                Image(systemName: "ellipsis.circle")
            }
            .menuStyle(.borderlessButton)
            .menuIndicator(.hidden)
            .fixedSize()
            .help(rv("Ações", "Actions", "Azioni", "Acciones"))
        }
    }

    private func detail(_ line: ReviewApps.AppLine) -> String {
        var parts: [String] = []
        if !line.version.isEmpty { parts.append(line.version) }
        if line.fromAppStore { parts.append("App Store") }
        if let used = line.lastUsed {
            let when = Self.ago(used)
            parts.append(rv("aberto \(when)", "opened \(when)", "aperta \(when)", "abierta \(when)"))
        } else {
            parts.append(rv("sem registro de uso", "no record of use", "nessun uso registrato", "sin registro de uso"))
        }
        return parts.joined(separator: " · ")
    }
}

// MARK: - App updates

/// The app update list, the same one Settings shows. The search starts by
/// itself when the page opens.
struct ReviewUpdatesPage: View {
    @ObservedObject private var l10n = L10n.shared
    @ObservedObject private var features = FeatureRuntime.shared

    private var text: AppUpdateStrings { FeatureStrings.appUpdates(l10n.language) }

    var body: some View {
        // Read so the page follows the feature being switched on or off.
        let _ = features.revision
        Form {
            if AppFeature.appUpdates.isAvailable {
                Section(text.pageTitle) {
                    Text(text.caption)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    AppUpdatesListView()
                        .padding(.vertical, 2)
                }
                Section {
                    Button(rv("Frequência e fontes da busca…", "Check frequency and sources…",
                              "Frequenza e fonti della ricerca…", "Frecuencia y fuentes de la búsqueda…")) {
                        SettingsRouter.shared.page = .appUpdates
                        appDelegate()?.openSettingsWindow()
                    }
                }
            } else {
                Section(text.pageTitle) {
                    Text(rv("As atualizações de apps estão desligadas em Ajustes › Recursos.",
                            "App updates are switched off in Settings › Features.",
                            "Gli aggiornamenti delle app sono disattivati in Impostazioni › Funzioni.",
                            "Las actualizaciones de apps están desactivadas en Ajustes › Funciones."))
                        .foregroundStyle(.secondary)
                    Button(rv("Abrir Recursos…", "Open Features…", "Apri Funzioni…", "Abrir Funciones…")) {
                        SettingsRouter.shared.page = .features
                        appDelegate()?.openSettingsWindow()
                    }
                }
            }
        }
        .formStyle(.grouped)
        .onAppear {
            // Opening the page is asking what is new: the search starts now.
            if !AppUpdatesService.shared.isChecking {
                AppUpdatesService.shared.check()
            }
        }
    }
}
