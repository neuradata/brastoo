// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import SwiftUI

/// Settings › General › My Mac: four pictures to choose from, each with its
/// name underneath. The pictures are shown at their own size, never
/// stretched; the tiles around them are what share the width.
struct MyMacPicker: View {
    @ObservedObject private var l10n = L10n.shared
    @AppStorage(MyMac.storageKey) private var stored = ""

    /// Room for the tallest picture, so the four names line up.
    private static let pictureHeight: CGFloat = 64

    private var selection: MacKind { MacKind(rawValue: stored) ?? MyMac.detected }

    var body: some View {
        SettingsCard(title: MyMac.title(l10n.language)) {
            Text(MyMac.caption(l10n.language))
                .font(.system(size: 12))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            HStack(alignment: .top, spacing: 10) {
                ForEach(MacKind.allCases) { kind in
                    tile(kind)
                }
            }
        }
    }

    private func tile(_ kind: MacKind) -> some View {
        let selected = kind == selection
        return Button {
            stored = kind.rawValue
        } label: {
            VStack(spacing: 9) {
                Group {
                    if let image = kind.image {
                        Image(nsImage: image)
                    } else {
                        Image(systemName: "desktopcomputer")
                            .font(.system(size: 30))
                            .foregroundStyle(.secondary)
                    }
                }
                .frame(height: Self.pictureHeight, alignment: .bottom)
                Text(kind.name)
                    .font(.system(size: 12, weight: selected ? .semibold : .regular))
                    .foregroundStyle(selected ? Color.primary : Color.secondary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .padding(.horizontal, 6)
            .background(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(selected ? Theme.brandBlue.opacity(0.12) : Color.primary.opacity(0.04))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .strokeBorder(selected ? Theme.brandBlue : Color.primary.opacity(0.08),
                                  lineWidth: selected ? 1.5 : 1)
            )
            .contentShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(kind.name)
        .accessibilityAddTraits(selected ? [.isSelected] : [])
    }
}
