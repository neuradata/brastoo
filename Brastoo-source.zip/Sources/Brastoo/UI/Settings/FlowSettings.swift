// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import SwiftUI

/// A scene on its way into the editor: a new one, a template or one being changed.
struct FlowDraft: Identifiable {
    let id = UUID()
    let scene: FlowScene
    let isNew: Bool
}

extension FlowScene {
    /// "When Zoom opens", in the words of the person's language.
    func triggerSummary(_ strings: FlowStrings) -> String {
        switch trigger {
        case .manual:
            return strings.summaryManual
        case .apps:
            var list = triggerApps.prefix(2).map { InstalledApps.name(for: $0) }.joined(separator: ", ")
            if triggerApps.count > 2 { list += "…" }
            return String(format: strings.summaryAppsFormat, list)
        case .display:
            return strings.summaryDisplay
        }
    }

    /// What it does, as short as it can be said.
    func actionsSummary(_ strings: FlowStrings) -> String {
        var parts: [String] = []
        if keepsAwake { parts.append(strings.shortAwake) }
        if hidesDesktopIcons { parts.append(strings.shortIcons) }
        if audioOutputUID != nil { parts.append(audioOutputName ?? strings.actionAudio) }
        let opened = opensApps.map { InstalledApps.name(for: $0) } + opensItems.map { FlowSystem.itemName($0) }
        if !opened.isEmpty {
            var list = opened.prefix(2).joined(separator: ", ")
            if opened.count > 2 { list += "…" }
            parts.append(String(format: strings.shortOpensFormat, list))
        }
        var shortcuts: [String] = []
        for name in [startShortcut, endShortcut] where !name.isEmpty && !shortcuts.contains(name) {
            shortcuts.append(name)
        }
        for name in shortcuts {
            parts.append(String(format: strings.shortShortcutFormat, name))
        }
        return parts.isEmpty ? strings.noActions : parts.joined(separator: " · ")
    }
}

/// Settings › Flow: the scenes, the one that is on, ready-made ones to start
/// from, and the list of what scenes have done.
struct FlowSettings: View {
    @ObservedObject private var l10n = L10n.shared
    @ObservedObject private var store = FlowStore.shared
    @ObservedObject private var engine = FlowEngine.shared
    @AppStorage(FlowStore.Key.notifyAutomatic) private var notifyAutomatic = true
    @State private var draft: FlowDraft?

    private var text: FlowStrings { FlowStrings.localized(l10n.language) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack(alignment: .firstTextBaseline) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Flow").font(.title2.bold())
                        Text(text.tagline)
                            .font(.callout)
                            .foregroundStyle(Color.secondary)
                    }
                    Spacer(minLength: 12)
                    Button {
                        draft = FlowDraft(scene: FlowScene(name: ""), isNew: true)
                    } label: {
                        Label(text.newScene, systemImage: "plus")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(Theme.brandBlue)
                }
                if let active = engine.active {
                    activeCard(active)
                }
                if store.scenes.isEmpty {
                    introCard
                } else {
                    scenesCard
                }
                templatesCard
                optionsCard
                historyCard
            }
            .frame(maxWidth: 760)
            .frame(maxWidth: .infinity)
            .padding(22)
        }
        .sheet(item: $draft) { draft in
            FlowSceneEditor(draft: draft) { scene in
                self.draft = nil
                save(scene)
            } onCancel: {
                self.draft = nil
            }
        }
    }

    private func save(_ scene: FlowScene) {
        store.save(scene)
        engine.restartIfActive(scene.id)
        if scene.trigger != .manual, notifyAutomatic { Notifier.requestPermission() }
    }

    // MARK: - The scene that is on

    private func activeCard(_ active: FlowActiveScene) -> some View {
        HStack(alignment: .center, spacing: 14) {
            Image(systemName: active.symbol)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Color.white)
                .frame(width: 42, height: 42)
                .background(Theme.brandBlue, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(active.name)
                        .font(.headline)
                        .lineLimit(1)
                    Text(active.startedAt, style: .timer)
                        .font(.callout.monospacedDigit())
                        .foregroundStyle(Color.secondary)
                }
                Text(changesLine(active))
                    .font(.caption)
                    .foregroundStyle(Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 12)
            Button(text.endAndRestore) { engine.endActive() }
                .buttonStyle(.borderedProminent)
                .tint(Theme.brandBlue)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.brandBlue.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(Theme.brandBlue.opacity(0.4), lineWidth: 1)
        }
    }

    /// What will be put back, which is what the button beside it promises.
    private func changesLine(_ active: FlowActiveScene) -> String {
        let parts: [String] = active.changes.map { change in
            switch change {
            case .keepAwake: return text.shortAwake
            case .desktopIcons: return text.shortIcons
            case .audioOutput: return text.actionAudio
            }
        }
        return parts.isEmpty ? text.activeNothingChanged : parts.joined(separator: " · ")
    }

    // MARK: - Scenes

    private var introCard: some View {
        SettingsCard {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: "sparkles")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(Theme.brandBlue)
                    .frame(width: 26)
                Text(text.intro)
                    .font(.callout)
                    .foregroundStyle(Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var scenesCard: some View {
        SettingsCard(title: text.scenesTitle) {
            ForEach(Array(store.scenes.enumerated()), id: \.element.id) { index, scene in
                if index > 0 { Divider() }
                sceneRow(scene, index: index)
            }
            if store.scenes.count > 1 {
                Text(text.orderHint)
                    .font(.caption)
                    .foregroundStyle(Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private func sceneRow(_ scene: FlowScene, index: Int) -> some View {
        let isOn = engine.isActive(scene.id)
        return HStack(spacing: 12) {
            Image(systemName: scene.symbol)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(isOn ? Color.white : Theme.brandBlue)
                .frame(width: 34, height: 34)
                .background(isOn ? Theme.brandBlue : Theme.brandBlue.opacity(0.13),
                            in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(scene.name)
                    .fontWeight(.medium)
                    .lineLimit(1)
                Text(scene.triggerSummary(text))
                    .font(.caption)
                    .foregroundStyle(Color.secondary)
                    .lineLimit(1)
                Text(scene.actionsSummary(text))
                    .font(.caption)
                    .foregroundStyle(Color.secondary.opacity(0.75))
                    .lineLimit(1)
            }
            Spacer(minLength: 10)
            if scene.trigger != .manual {
                Toggle(text.automaticHelp, isOn: Binding(
                    get: { scene.isEnabled },
                    set: { store.setEnabled($0, for: scene.id) }))
                    .labelsHidden()
                    .toggleStyle(.switch)
                    .controlSize(.small)
                    .help(text.automaticHelp)
            }
            Button(isOn ? text.end : text.start) {
                engine.toggle(scene.id)
            }
            .controlSize(.small)
            Menu {
                Button(text.edit) {
                    draft = FlowDraft(scene: scene, isNew: false)
                }
                Divider()
                Button(text.moveUp) { store.move(scene.id, by: -1) }
                    .disabled(index == 0)
                Button(text.moveDown) { store.move(scene.id, by: 1) }
                    .disabled(index == store.scenes.count - 1)
                Divider()
                Button(text.delete, role: .destructive) {
                    engine.endIfActive(scene.id)
                    store.remove(scene.id)
                }
            } label: {
                Image(systemName: "ellipsis.circle")
                    .font(.system(size: 14))
            }
            .menuStyle(.borderlessButton)
            .menuIndicator(.hidden)
            .fixedSize()
        }
    }

    // MARK: - Templates

    private var templatesCard: some View {
        SettingsCard(title: text.templatesTitle) {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 10)], spacing: 10) {
                ForEach(FlowPreset.allCases) { preset in
                    Button {
                        draft = FlowDraft(scene: preset.scene(text), isNew: true)
                    } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            Image(systemName: preset.symbol)
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundStyle(Theme.brandBlue)
                                .frame(height: 22)
                            Text(preset.name(text))
                                .font(.system(size: 13, weight: .semibold))
                                .lineLimit(1)
                            Text(preset.caption(text))
                                .font(.caption)
                                .foregroundStyle(Color.secondary)
                                .multilineTextAlignment(.leading)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .frame(maxWidth: .infinity, minHeight: 76, alignment: .topLeading)
                        .padding(12)
                        .background(Color.primary.opacity(0.055),
                                    in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .contentShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
            }
            Text(text.templatesCaption)
                .font(.caption)
                .foregroundStyle(Color.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    // MARK: - Options

    private var optionsCard: some View {
        SettingsCard {
            SettingsRow(symbol: "bell", title: text.notifyTitle, caption: text.notifyCaption) {
                Toggle(text.notifyTitle, isOn: $notifyAutomatic)
                    .labelsHidden()
                    .toggleStyle(.switch)
                    .onChange(of: notifyAutomatic) { _, wanted in
                        if wanted { Notifier.requestPermission() }
                    }
            }
        }
    }

    // MARK: - Activity

    /// The list split where a scene starts, newest scene first, with each
    /// scene's own lines in the order they happened.
    private var history: [[FlowLogEntry]] {
        var groups: [[FlowLogEntry]] = []
        for entry in engine.log {
            let opens = entry.kind == .started || entry.kind == .startedAuto || entry.kind == .recovered
            if opens || groups.isEmpty {
                groups.append([entry])
            } else {
                groups[groups.count - 1].append(entry)
            }
        }
        return Array(groups.reversed().prefix(8))
    }

    private var historyCard: some View {
        SettingsCard {
            HStack {
                Text(text.historyTitle).font(.headline)
                Spacer()
                if !engine.log.isEmpty {
                    Button(text.clearHistory) { engine.clearLog() }
                        .controlSize(.small)
                }
            }
            if engine.log.isEmpty {
                Text(text.historyEmpty)
                    .font(.callout)
                    .foregroundStyle(Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            } else {
                let groups = history
                ForEach(Array(groups.enumerated()), id: \.offset) { index, group in
                    if index > 0 { Divider() }
                    VStack(alignment: .leading, spacing: 5) {
                        ForEach(group) { entry in
                            historyLine(entry)
                        }
                    }
                }
            }
        }
    }

    private func historyLine(_ entry: FlowLogEntry) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(time(entry.date))
                .font(.caption.monospacedDigit())
                .foregroundStyle(Color.secondary)
                .frame(width: 92, alignment: .leading)
            Image(systemName: entry.symbol)
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(entry.kind == .failed ? Color.orange
                                 : entry.isHeading ? Theme.brandBlue : Color.secondary)
                .frame(width: 16)
            Text(entry.text(text))
                .font(.system(size: 12.5, weight: entry.isHeading ? .semibold : .regular))
                .foregroundStyle(entry.isHeading ? Color.primary : Color.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
    }

    /// The hour alone for today; the day too for anything older.
    private func time(_ date: Date) -> String {
        if Calendar.current.isDateInToday(date) {
            return date.formatted(date: .omitted, time: .shortened)
        }
        return date.formatted(date: .numeric, time: .shortened)
    }
}
