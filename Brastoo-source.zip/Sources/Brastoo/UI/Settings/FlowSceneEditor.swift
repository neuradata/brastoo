// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import SwiftUI

/// The sheet where a scene is made or changed: its name and icon, what
/// starts it, and what it does. Nothing is kept until Save.
struct FlowSceneEditor: View {
    /// Which of the two app lists the app picker is filling.
    private enum AppList: String, Identifiable {
        case trigger, opens

        var id: String { rawValue }
    }

    private static let symbols = [
        "sparkles", "video.fill", "person.2.fill", "rectangle.on.rectangle", "tv",
        "chevron.left.forwardslash.chevron.right", "terminal.fill", "record.circle",
        "headphones", "music.note", "book.fill", "pencil.and.outline",
        "moon.fill", "bolt.fill", "gamecontroller.fill", "briefcase.fill",
    ]

    let isNew: Bool
    let onSave: (FlowScene) -> Void
    let onCancel: () -> Void

    @ObservedObject private var l10n = L10n.shared
    @State private var scene: FlowScene
    @State private var outputs: [FlowAudio.Output] = []
    @State private var shortcuts: [String] = []
    @State private var picking: AppList?
    @State private var link = ""

    init(draft: FlowDraft,
         onSave: @escaping (FlowScene) -> Void,
         onCancel: @escaping () -> Void) {
        isNew = draft.isNew
        self.onSave = onSave
        self.onCancel = onCancel
        _scene = State(initialValue: draft.scene)
    }

    private var text: FlowStrings { FlowStrings.localized(l10n.language) }

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text(isNew ? text.editorNew : text.editorEdit)
                        .font(.title3.bold())
                    identityCard
                    triggerCard
                    actionsCard
                    openingCard
                    shortcutsCard
                }
                .padding(20)
            }
            Divider()
            HStack {
                Spacer()
                Button(text.cancel, action: onCancel)
                    .keyboardShortcut(.cancelAction)
                Button(text.save) { save() }
                    .keyboardShortcut(.defaultAction)
                    .buttonStyle(.borderedProminent)
                    .tint(Theme.brandBlue)
                    .disabled(!scene.isComplete)
            }
            .padding(14)
        }
        .frame(width: 580, height: 680)
        .onAppear {
            outputs = FlowAudio.outputs()
            FlowSystem.loadShortcuts { shortcuts = $0 }
        }
        .sheet(item: $picking) { list in
            appPicker(for: list)
        }
    }

    private func save() {
        var saved = scene
        saved.name = scene.name.trimmingCharacters(in: .whitespacesAndNewlines)
        // A scene only waits for apps while that is how it starts.
        if saved.trigger != .apps { saved.triggerApps = [] }
        onSave(saved)
    }

    // MARK: - Name and icon

    private var identityCard: some View {
        SettingsCard {
            HStack(spacing: 12) {
                Image(systemName: scene.symbol)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(Color.white)
                    .frame(width: 36, height: 36)
                    .background(Theme.brandBlue, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                TextField(text.namePlaceholder, text: $scene.name)
                    .textFieldStyle(.roundedBorder)
                    .font(.system(size: 14))
                    .accessibilityLabel(text.nameLabel)
            }
            LazyVGrid(columns: Array(repeating: GridItem(.fixed(34), spacing: 6), count: 8),
                      alignment: .leading, spacing: 6) {
                ForEach(Self.symbols, id: \.self) { symbol in
                    Button {
                        scene.symbol = symbol
                    } label: {
                        Image(systemName: symbol)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(scene.symbol == symbol ? Theme.brandBlue : Color.secondary)
                            .frame(width: 34, height: 30)
                            .background(scene.symbol == symbol ? Theme.brandBlue.opacity(0.16) : Color.primary.opacity(0.05),
                                        in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                            .contentShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
            }
            .accessibilityLabel(text.iconLabel)
        }
    }

    // MARK: - When it starts

    private var triggerCard: some View {
        SettingsCard(title: text.whenTitle) {
            Picker(text.whenTitle, selection: $scene.trigger) {
                Text(text.triggerManual).tag(FlowTrigger.manual)
                Text(text.triggerApps).tag(FlowTrigger.apps)
                Text(FlowSystem.needsSecondDisplay ? text.triggerSecondDisplay : text.triggerDisplay)
                    .tag(FlowTrigger.display)
            }
            .pickerStyle(.radioGroup)
            .labelsHidden()
            if scene.trigger == .apps {
                appRows(scene.triggerApps) { bundleID in
                    scene.triggerApps.removeAll { $0 == bundleID }
                }
                Button {
                    picking = .trigger
                } label: {
                    Label(text.addApp, systemImage: "plus")
                }
                .controlSize(.small)
            }
            Text(triggerCaption)
                .font(.caption)
                .foregroundStyle(Color.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var triggerCaption: String {
        switch scene.trigger {
        case .manual: return text.triggerManualCaption
        case .apps: return text.triggerAppsCaption
        case .display: return text.triggerDisplayCaption
        }
    }

    // MARK: - What it changes

    private var actionsCard: some View {
        SettingsCard(title: text.actionsTitle) {
            SettingsRow(symbol: "cup.and.saucer", title: text.actionAwake, caption: text.actionAwakeCaption) {
                Toggle(text.actionAwake, isOn: $scene.keepsAwake)
                    .labelsHidden()
                    .toggleStyle(.switch)
            }
            Divider()
            SettingsRow(symbol: "menubar.dock.rectangle", title: text.actionIcons, caption: text.actionIconsCaption) {
                Toggle(text.actionIcons, isOn: $scene.hidesDesktopIcons)
                    .labelsHidden()
                    .toggleStyle(.switch)
            }
            Divider()
            SettingsRow(symbol: "speaker.wave.2", title: text.actionAudio, caption: text.actionAudioCaption) {
                Picker(text.actionAudio, selection: audioSelection) {
                    Text(text.audioKeep).tag("")
                    ForEach(audioChoices) { output in
                        Text(output.name).tag(output.uid)
                    }
                }
                .pickerStyle(.menu)
                .labelsHidden()
                .frame(maxWidth: 220)
            }
        }
    }

    /// The outputs connected now, plus the saved one while it is away, so
    /// opening the editor never drops a choice just because the headphones
    /// are in their case.
    private var audioChoices: [FlowAudio.Output] {
        var choices = outputs
        if let uid = scene.audioOutputUID, !choices.contains(where: { $0.uid == uid }) {
            choices.append(FlowAudio.Output(
                uid: uid,
                name: String(format: text.audioDisconnectedFormat, scene.audioOutputName ?? uid)))
        }
        return choices
    }

    private var audioSelection: Binding<String> {
        Binding(
            get: { scene.audioOutputUID ?? "" },
            set: { uid in
                if uid.isEmpty {
                    scene.audioOutputUID = nil
                    scene.audioOutputName = nil
                } else if let output = outputs.first(where: { $0.uid == uid }) {
                    scene.audioOutputUID = output.uid
                    scene.audioOutputName = output.name
                }
            })
    }

    // MARK: - What it opens

    private var openingCard: some View {
        SettingsCard {
            listHeading(symbol: "app.badge", title: text.actionOpenApps, caption: text.actionOpenAppsCaption)
            appRows(scene.opensApps) { bundleID in
                scene.opensApps.removeAll { $0 == bundleID }
            }
            Button {
                picking = .opens
            } label: {
                Label(text.addApp, systemImage: "plus")
            }
            .controlSize(.small)
            .padding(.leading, settingsRowTextInset)

            Divider()

            listHeading(symbol: "doc", title: text.actionOpenItems, caption: text.actionOpenItemsCaption)
            ForEach(scene.opensItems, id: \.self) { item in
                HStack(spacing: 9) {
                    Image(systemName: FlowSystem.itemIsFile(item) ? "doc" : "link")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(Color.secondary)
                        .frame(width: 18)
                    Text(FlowSystem.itemName(item))
                        .lineLimit(1)
                    Text(item)
                        .font(.caption)
                        .foregroundStyle(Color.secondary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    Spacer(minLength: 8)
                    removeButton { scene.opensItems.removeAll { $0 == item } }
                }
                .padding(.leading, settingsRowTextInset)
            }
            HStack(spacing: 8) {
                Button {
                    chooseFiles()
                } label: {
                    Label(text.addFile, systemImage: "plus")
                }
                .controlSize(.small)
                TextField("https://", text: $link)
                    .textFieldStyle(.roundedBorder)
                    .controlSize(.small)
                    .autocorrectionDisabled()
                    .onSubmit(addLink)
                Button(text.addLink, action: addLink)
                    .controlSize(.small)
                    .disabled(link.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding(.leading, settingsRowTextInset)
        }
    }

    private func listHeading(symbol: String, title: String, caption: String) -> some View {
        SettingsRow(symbol: symbol, title: title, caption: caption) { EmptyView() }
    }

    private func appRows(_ bundleIDs: [String], remove: @escaping (String) -> Void) -> some View {
        ForEach(bundleIDs, id: \.self) { bundleID in
            HStack(spacing: 9) {
                Image(nsImage: InstalledApps.icon(for: bundleID))
                    .resizable()
                    .frame(width: 18, height: 18)
                Text(InstalledApps.name(for: bundleID))
                    .lineLimit(1)
                Spacer(minLength: 8)
                removeButton { remove(bundleID) }
            }
            .padding(.leading, settingsRowTextInset)
        }
    }

    private func removeButton(_ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: "minus.circle.fill")
                .foregroundStyle(Color.secondary)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(text.remove)
    }

    private func chooseFiles() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = true
        guard panel.runModal() == .OK else { return }
        for url in panel.urls where !scene.opensItems.contains(url.path) {
            scene.opensItems.append(url.path)
        }
    }

    private func addLink() {
        let typed = link.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !typed.isEmpty, let url = FlowSystem.itemURL(typed) else { return }
        let item = url.isFileURL ? url.path : url.absoluteString
        if !scene.opensItems.contains(item) { scene.opensItems.append(item) }
        link = ""
    }

    private func appPicker(for list: AppList) -> some View {
        let listed = Set(list == .trigger ? scene.triggerApps : scene.opensApps)
        let add: (String?) -> Void = { bundleID in
            picking = nil
            guard let bundleID, !listed.contains(bundleID) else { return }
            switch list {
            case .trigger: scene.triggerApps.append(bundleID)
            case .opens: scene.opensApps.append(bundleID)
            }
        }
        return AppPickerView(canBrowseApplications: true,
                             onCancel: { picking = nil },
                             onSelect: { url in add(Bundle(url: url)?.bundleIdentifier) },
                             onSelectApp: { app in add(app.bundleID ?? Bundle(url: app.url)?.bundleIdentifier) },
                             loadApps: { InstalledApps.installedBundleApplications(excluding: listed) })
    }

    // MARK: - Shortcuts

    private var shortcutsCard: some View {
        SettingsCard(title: text.shortcutsTitle) {
            SettingsRow(symbol: "play", title: text.shortcutStart) {
                shortcutPicker(text.shortcutStart, selection: $scene.startShortcut)
            }
            Divider()
            SettingsRow(symbol: "stop", title: text.shortcutEnd) {
                shortcutPicker(text.shortcutEnd, selection: $scene.endShortcut)
            }
            Text(text.shortcutsCaption)
                .font(.caption)
                .foregroundStyle(Color.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private func shortcutPicker(_ title: String, selection: Binding<String>) -> some View {
        // The saved name stays in the list while the names are still loading,
        // and after the shortcut was renamed or removed in the Shortcuts app.
        var names = shortcuts
        let saved = selection.wrappedValue
        if !saved.isEmpty, !names.contains(saved) { names.insert(saved, at: 0) }
        return Picker(title, selection: selection) {
            Text(text.shortcutNone).tag("")
            ForEach(names, id: \.self) { name in
                Text(name).tag(name)
            }
        }
        .pickerStyle(.menu)
        .labelsHidden()
        .frame(maxWidth: 240)
    }
}
