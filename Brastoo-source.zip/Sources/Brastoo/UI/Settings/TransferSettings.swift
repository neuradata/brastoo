// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import SwiftUI

/// Settings › Transfers: where received items go, how long a code lives, what
/// the app announces, and how the two computers are allowed to connect.
struct TransferSettings: View {
    @ObservedObject private var l10n = L10n.shared
    @AppStorage(TransferPreferences.Key.destinationPath) private var destinationPath = ""
    @AppStorage(TransferPreferences.Key.revealWhenDone) private var revealWhenDone = false
    @AppStorage(TransferPreferences.Key.copyCodeAutomatically) private var copyCodeAutomatically = false
    @AppStorage(TransferPreferences.Key.expiryMinutes) private var expiryMinutes = 1_440
    @AppStorage(TransferPreferences.Key.notifyReceived) private var notifyReceived = true
    @AppStorage(TransferPreferences.Key.notifyUploadStarted) private var notifyUploadStarted = true
    @AppStorage(TransferPreferences.Key.menuBarStatus) private var menuBarStatus = true
    @AppStorage(TransferPreferences.Key.keepAwake) private var keepAwake = true
    @AppStorage(TransferPreferences.Key.connectionMode) private var connectionMode =
        TransferPreferences.ConnectionMode.automatic.rawValue
    @AppStorage(TransferPreferences.Key.customRelayURL) private var customRelayURL = ""
    @AppStorage(TransferPreferences.Key.hideAddresses) private var hideAddresses = false

    private var text: TransferStrings { TransferStrings.localized(l10n.language) }

    private var mode: TransferPreferences.ConnectionMode {
        TransferPreferences.ConnectionMode(rawValue: connectionMode) ?? .automatic
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack(alignment: .firstTextBaseline) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(text.settingsTitle).font(.title2.bold())
                        Text(AppInfo.slogan)
                            .font(.callout)
                            .foregroundStyle(Color.secondary)
                    }
                    Spacer(minLength: 12)
                    Button(text.openWindowButton) {
                        appDelegate()?.openTransferWindow()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(Theme.brandBlue)
                }
                receivingCard
                sendingCard
                alertsCard
                systemCard
                securityCard
            }
            .frame(maxWidth: 760)
            .frame(maxWidth: .infinity)
            .padding(22)
        }
    }

    // MARK: - Receiving

    private var receivingCard: some View {
        SettingsCard(title: text.sectionReceiving) {
            SettingsRow(symbol: "folder", title: text.destinationLabel,
                        caption: text.destinationCaption) {
                HStack(spacing: 8) {
                    Text(destinationName)
                        .font(.callout)
                        .foregroundStyle(Color.secondary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                        .frame(maxWidth: 180, alignment: .trailing)
                    Button(text.changeButton) { chooseDestination() }
                }
            }
            Divider()
            SettingsRow(symbol: "magnifyingglass", title: text.revealTitle,
                        caption: text.revealCaption) {
                Toggle(text.revealTitle, isOn: $revealWhenDone)
                    .labelsHidden()
                    .toggleStyle(.switch)
            }
        }
    }

    private var destinationName: String {
        _ = destinationPath
        return TransferPreferences.destination.lastPathComponent
    }

    private func chooseDestination() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.canCreateDirectories = true
        panel.allowsMultipleSelection = false
        panel.directoryURL = TransferPreferences.destination
        guard panel.runModal() == .OK, let url = panel.url else { return }
        destinationPath = url.path
    }

    // MARK: - Sending

    private var sendingCard: some View {
        SettingsCard(title: text.sectionSending) {
            SettingsRow(symbol: "doc.on.clipboard", title: text.autoCopyTitle,
                        caption: text.autoCopyCaption) {
                Toggle(text.autoCopyTitle, isOn: $copyCodeAutomatically)
                    .labelsHidden()
                    .toggleStyle(.switch)
            }
            Divider()
            SettingsRow(symbol: "timer", title: text.expiryTitle,
                        caption: text.expiryCaption) {
                Picker(text.expiryTitle, selection: $expiryMinutes) {
                    ForEach(TransferPreferences.expiryChoices, id: \.self) { minutes in
                        Text(text.expiryLabel(minutes: minutes)).tag(minutes)
                    }
                }
                .pickerStyle(.menu)
                .labelsHidden()
                .fixedSize()
            }
        }
    }

    // MARK: - Notifications

    private var alertsCard: some View {
        SettingsCard(title: text.sectionAlerts) {
            SettingsRow(symbol: "checkmark.circle", title: text.alertReceivedTitle,
                        caption: text.alertReceivedCaption) {
                Toggle(text.alertReceivedTitle, isOn: $notifyReceived)
                    .labelsHidden()
                    .toggleStyle(.switch)
                    .onChange(of: notifyReceived) { _, wanted in
                        if wanted { Notifier.requestPermission() }
                    }
            }
            Divider()
            SettingsRow(symbol: "person.crop.circle.badge.checkmark", title: text.alertUploadTitle,
                        caption: text.alertUploadCaption) {
                Toggle(text.alertUploadTitle, isOn: $notifyUploadStarted)
                    .labelsHidden()
                    .toggleStyle(.switch)
                    .onChange(of: notifyUploadStarted) { _, wanted in
                        if wanted { Notifier.requestPermission() }
                    }
            }
        }
    }

    // MARK: - Menu bar and power

    private var systemCard: some View {
        SettingsCard(title: text.sectionSystem) {
            SettingsRow(symbol: "menubar.rectangle", title: text.menuBarTitle,
                        caption: text.menuBarCaption) {
                Toggle(text.menuBarTitle, isOn: $menuBarStatus)
                    .labelsHidden()
                    .toggleStyle(.switch)
            }
            Divider()
            SettingsRow(symbol: "moon.zzz", title: text.keepAwakeTitle,
                        caption: text.keepAwakeCaption) {
                Toggle(text.keepAwakeTitle, isOn: $keepAwake)
                    .labelsHidden()
                    .toggleStyle(.switch)
            }
        }
    }

    // MARK: - Security and network

    private var securityCard: some View {
        SettingsCard(title: text.sectionSecurity) {
            SettingsRow(symbol: "point.3.connected.trianglepath.dotted", title: text.connectionTitle,
                        caption: connectionCaption) {
                Picker(text.connectionTitle, selection: $connectionMode) {
                    Text(text.connectionAutomatic)
                        .tag(TransferPreferences.ConnectionMode.automatic.rawValue)
                    Text(text.connectionDirect)
                        .tag(TransferPreferences.ConnectionMode.direct.rawValue)
                    Text(text.connectionCustom)
                        .tag(TransferPreferences.ConnectionMode.custom.rawValue)
                }
                .pickerStyle(.menu)
                .labelsHidden()
                .fixedSize()
            }
            if mode == .custom {
                VStack(alignment: .leading, spacing: 5) {
                    TextField(text.relayPlaceholder, text: $customRelayURL)
                        .textFieldStyle(.roundedBorder)
                        .font(.system(size: 12, design: .monospaced))
                        .autocorrectionDisabled()
                    if TransferPreferences.validRelay(customRelayURL) == nil {
                        Text(text.relayInvalid)
                            .font(.caption)
                            .foregroundStyle(Color.orange)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(.leading, settingsRowTextInset)
            }
            Divider()
            SettingsRow(symbol: "eye.slash", title: text.hideAddressesTitle,
                        caption: text.hideAddressesCaption) {
                Toggle(text.hideAddressesTitle, isOn: $hideAddresses)
                    .labelsHidden()
                    .toggleStyle(.switch)
                    // With no relay the code has nothing but addresses to carry.
                    .disabled(mode == .direct)
            }
            Divider()
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 17))
                    .foregroundStyle(Theme.brandBlue)
                    .frame(width: 26)
                Text(text.securityNote)
                    .font(.system(size: 12))
                    .foregroundStyle(Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var connectionCaption: String {
        switch mode {
        case .automatic: return text.connectionAutomaticCaption
        case .direct: return text.connectionDirectCaption
        case .custom: return text.connectionCustomCaption
        }
    }
}
