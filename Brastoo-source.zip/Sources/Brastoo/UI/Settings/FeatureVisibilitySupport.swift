// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Vorssaint

import Combine
import Foundation

/// The Settings pages. Lives here (without SwiftUI) so the visibility rules
/// below and the unit tests can reason about pages without pulling UI in.
enum SettingsPage: Hashable {
    case general, features, energy, monitor
    case mouse, switcher, dock, keyDebounce, superKey, cutPaste, autoQuit, quitProtection, cleaner, uninstaller, urlCleaner, homebrew, appUpdates, media, clipboard, windowLayout, shelf, quickTools, textSnippets, screenshot, radialMenu, commandBar, killProcess, portManager, notch
    case shortcuts, advanced, about, releaseNotes, support
    case transfers
    case flow
}

/// Stable, non-localized identities for destinations inside shared Settings
/// pages. Raw values may be persisted or used by UI identifiers, so cases can
/// be added but never renamed.
enum SettingsSectionAnchor: String, CaseIterable, Hashable {
    case panelConfiguration
    case mixer
    case audioPriority
    case musicBlocking
    case keepAwake
    case brightness
    case extraBrightness
    case bluetoothSleep
    case scrollDirection
    case focusFollowsMouse
    case smoothScroll
    case linearScroll
    case mouseAcceleration
    case mouseNavigation
    case mouseButtonShortcuts
    case middleClick
    case mouseClickDebounce
    case switcher
    case dock
    case dockClick
    case finderCutPaste
    case finderRename
    case clipboardHistory
    case pastePlain
    case quickLauncher
    case quickToggles
    case screenshot
    case screenRecorder
    case colorPicker
    case screenOCR
    case micMute
    case cameraPreview
    case wallpaper
    case scratchpad
    case cleaningMode
    case soundOutputSwitcher
    case keyboardBrightnessShortcuts
    case fanControl
    case windowMaximizer

    var page: SettingsPage {
        switch self {
        case .panelConfiguration, .mixer, .audioPriority, .musicBlocking,
             .soundOutputSwitcher:
            return .general
        case .keepAwake, .brightness, .extraBrightness, .bluetoothSleep: return .energy
        case .scrollDirection, .focusFollowsMouse, .smoothScroll, .linearScroll, .mouseAcceleration, .mouseNavigation, .mouseButtonShortcuts,
             .middleClick, .mouseClickDebounce:
            return .mouse
        case .switcher: return .switcher
        case .dock, .dockClick: return .dock
        case .finderCutPaste, .finderRename: return .cutPaste
        case .clipboardHistory, .pastePlain: return .clipboard
        case .quickLauncher, .quickToggles, .micMute, .cameraPreview, .wallpaper, .scratchpad, .cleaningMode:
            return .quickTools
        case .screenshot, .screenRecorder, .colorPicker, .screenOCR:
            return .screenshot
        case .keyboardBrightnessShortcuts: return .shortcuts
        case .fanControl: return .monitor
        case .windowMaximizer: return .windowLayout
        }
    }
}

/// A feature's nearest configuration surface. The optional anchor distinguishes
/// a feature section on a shared page; nil means the page itself is the target.
struct FeatureSettingsDestination: Hashable {
    let page: SettingsPage
    let sectionAnchor: SettingsSectionAnchor?

    init(_ page: SettingsPage, sectionAnchor: SettingsSectionAnchor? = nil) {
        self.page = page
        self.sectionAnchor = sectionAnchor
    }

    var hasValidSectionAnchor: Bool {
        sectionAnchor == nil || sectionAnchor?.page == page
    }
}

struct SettingsDestinationRequest: Equatable {
    let id: UUID
    let destination: FeatureSettingsDestination
}

/// A one-shot request to reveal a specific feature's row inside the Features
/// hub, correlated with the destination request that carries it by sharing
/// the same request id.
struct SettingsFeatureTargetRequest: Equatable {
    let id: UUID
    let feature: AppFeature
}

/// Selects a Settings destination and publishes a fresh request identity even
/// when callers ask for the same page and anchor repeatedly.
final class SettingsRouter: ObservableObject {
    static let shared = SettingsRouter()

    private struct HistoryEntry {
        let destination: FeatureSettingsDestination
        let sidebarFeature: AppFeature?
    }

    @Published var page: SettingsPage = .general {
        didSet {
            guard page != oldValue else { return }
            destination = FeatureSettingsDestination(page)
            sidebarFeature = nil
            pendingDestinationRequest = nil
            pendingFeatureTarget = nil
            if !isTraversingHistory {
                history.removeSubrange((historyIndex + 1)..<history.count)
                history.append(HistoryEntry(destination: destination, sidebarFeature: nil))
                historyIndex += 1
            }
        }
    }
    @Published private(set) var destination = FeatureSettingsDestination(.general)
    @Published private(set) var sidebarFeature: AppFeature?
    @Published private(set) var requestID = UUID()
    @Published private(set) var pendingDestinationRequest: SettingsDestinationRequest?
    /// One-shot hint for the Features hub: which feature row to reveal once
    /// the requested page lands. Always set (to nil when no target is given)
    /// on every `request`, so a stale target from an earlier search can never
    /// leak into a later, unrelated navigation.
    @Published private(set) var pendingFeatureTarget: SettingsFeatureTargetRequest?
    /// One-shot hint for the Cleaner page's tool switcher, so a panel surface
    /// can land directly on a specific tool. Consumed and cleared on arrival.
    @Published var cleanerTool: String?
    /// One-shot hint for the Dynamic Island page, so a section of the island
    /// can open its own options. Consumed and cleared on arrival.
    @Published var notchModule: NotchModule?

    private var history = [HistoryEntry(destination: FeatureSettingsDestination(.general),
                                        sidebarFeature: nil)]
    private var historyIndex = 0
    private var isTraversingHistory = false

    init() {}

    /// `replacingVisit` swaps what the current visit shows without adding a
    /// history entry, for a fallback when the visited tool went away.
    func request(_ destination: FeatureSettingsDestination, targetFeature: AppFeature? = nil,
                 sidebarFeature: AppFeature? = nil, replacingVisit: Bool = false) {
        let requestID = UUID()
        let samePage = page == destination.page
        page = destination.page
        self.destination = destination
        self.sidebarFeature = sidebarFeature?.settingsDestination == destination ? sidebarFeature : nil
        let entry = HistoryEntry(destination: destination, sidebarFeature: self.sidebarFeature)
        // Section requests refine the current page visit, not a new history
        // entry. General and Energy show one tool per anchor, so switching
        // tools there is a visit of its own.
        if samePage && !isTraversingHistory && !replacingVisit
            && Self.anchorSelectsTool(on: destination.page)
            && history[historyIndex].destination != destination {
            history.removeSubrange((historyIndex + 1)..<history.count)
            history.append(entry)
            historyIndex += 1
        } else {
            history[historyIndex] = entry
        }
        pendingDestinationRequest = SettingsDestinationRequest(id: requestID,
                                                               destination: destination)
        pendingFeatureTarget = targetFeature.map {
            SettingsFeatureTargetRequest(id: requestID, feature: $0)
        }
        self.requestID = requestID
    }

    private static func anchorSelectsTool(on page: SettingsPage) -> Bool {
        page == .general || page == .energy
    }

    func goBack(isPageVisible: (SettingsPage) -> Bool = { _ in true }) {
        navigateHistory(step: -1, isPageVisible: isPageVisible)
    }

    func goForward(isPageVisible: (SettingsPage) -> Bool = { _ in true }) {
        navigateHistory(step: 1, isPageVisible: isPageVisible)
    }

    func canGoBack(isPageVisible: (SettingsPage) -> Bool = { _ in true }) -> Bool {
        historyTarget(step: -1, isPageVisible: isPageVisible) != nil
    }

    func canGoForward(isPageVisible: (SettingsPage) -> Bool = { _ in true }) -> Bool {
        historyTarget(step: 1, isPageVisible: isPageVisible) != nil
    }

    private func navigateHistory(step: Int, isPageVisible: (SettingsPage) -> Bool) {
        guard let index = historyTarget(step: step, isPageVisible: isPageVisible) else { return }
        historyIndex = index
        isTraversingHistory = true
        cleanerTool = nil
        notchModule = nil
        let entry = history[index]
        request(entry.destination, sidebarFeature: entry.sidebarFeature)
        isTraversingHistory = false
    }

    private func historyTarget(step: Int, isPageVisible: (SettingsPage) -> Bool) -> Int? {
        var index = historyIndex + step
        while history.indices.contains(index) {
            if isPageVisible(history[index].destination.page) { return index }
            index += step
        }
        return nil
    }

    /// Clears only the request a view actually handled. A newer request that
    /// arrived while the destination page was being installed must survive.
    func consumeDestinationRequest(id: UUID) {
        guard pendingDestinationRequest?.id == id else { return }
        pendingDestinationRequest = nil
    }

    /// Clears only the feature target a view actually revealed. Mirrors
    /// `consumeDestinationRequest`: a newer request that arrived while the
    /// Features hub was still laying out must survive.
    func consumeFeatureTarget(id: UUID) {
        guard pendingFeatureTarget?.id == id else { return }
        pendingFeatureTarget = nil
    }
}

extension AppFeature {
    /// The hub itself is the honest fallback for features without a separate
    /// configuration surface, but linking a row back to its current page would
    /// present a chevron that appears to do nothing.
    var hasNavigableSettingsDestination: Bool {
        settingsDestination.page != .features
    }

    /// Exhaustive by design: adding an AppFeature requires choosing its
    /// Settings destination before the project compiles.
    var settingsDestination: FeatureSettingsDestination {
        switch self {
        case .switcher: return FeatureSettingsDestination(.switcher, sectionAnchor: .switcher)
        case .dockPreview: return FeatureSettingsDestination(.dock, sectionAnchor: .dock)
        case .dockClick: return FeatureSettingsDestination(.dock, sectionAnchor: .dockClick)
        case .windowMaximizer:
            return FeatureSettingsDestination(.windowLayout, sectionAnchor: .windowMaximizer)
        case .windowLayout: return FeatureSettingsDestination(.windowLayout)
        case .autoQuit: return FeatureSettingsDestination(.autoQuit)
        case .quitWindowProtection: return FeatureSettingsDestination(.quitProtection)

        case .scrollInverter, .scrollHorizontal:
            return FeatureSettingsDestination(.mouse, sectionAnchor: .scrollDirection)
        case .focusFollowsMouse:
            return FeatureSettingsDestination(.mouse, sectionAnchor: .focusFollowsMouse)
        case .smoothScroll:
            return FeatureSettingsDestination(.mouse, sectionAnchor: .smoothScroll)
        case .linearScroll:
            return FeatureSettingsDestination(.mouse, sectionAnchor: .linearScroll)
        case .mouseAcceleration:
            return FeatureSettingsDestination(.mouse, sectionAnchor: .mouseAcceleration)
        case .mouseNavigation:
            return FeatureSettingsDestination(.mouse, sectionAnchor: .mouseNavigation)
        case .mouseButtonShortcuts:
            return FeatureSettingsDestination(.mouse, sectionAnchor: .mouseButtonShortcuts)
        case .middleClick:
            return FeatureSettingsDestination(.mouse, sectionAnchor: .middleClick)
        case .mouseClickDebounce:
            return FeatureSettingsDestination(.mouse, sectionAnchor: .mouseClickDebounce)
        case .keyboardDebounce: return FeatureSettingsDestination(.keyDebounce)
        case .textSnippets: return FeatureSettingsDestination(.textSnippets)
        case .superKey: return FeatureSettingsDestination(.superKey)

        case .clipboardHistory:
            return FeatureSettingsDestination(.clipboard, sectionAnchor: .clipboardHistory)
        case .pastePlain:
            return FeatureSettingsDestination(.clipboard, sectionAnchor: .pastePlain)
        case .finderCutPaste:
            return FeatureSettingsDestination(.cutPaste, sectionAnchor: .finderCutPaste)
        case .finderRename:
            return FeatureSettingsDestination(.cutPaste, sectionAnchor: .finderRename)
        case .shelf: return FeatureSettingsDestination(.shelf)
        case .urlCleaner: return FeatureSettingsDestination(.urlCleaner)
        case .diskImageInstaller: return FeatureSettingsDestination(.features)

        case .mixer:
            return FeatureSettingsDestination(.general, sectionAnchor: .mixer)
        case .soundOutputSwitcher:
            return FeatureSettingsDestination(.general, sectionAnchor: .soundOutputSwitcher)
        case .audioPriority:
            return FeatureSettingsDestination(.general, sectionAnchor: .audioPriority)
        case .micMute:
            return FeatureSettingsDestination(.quickTools, sectionAnchor: .micMute)
        case .musicBlock:
            return FeatureSettingsDestination(.general, sectionAnchor: .musicBlocking)

        case .keepAwake:
            return FeatureSettingsDestination(.energy, sectionAnchor: .keepAwake)
        case .brightness:
            return FeatureSettingsDestination(.energy, sectionAnchor: .brightness)
        case .extraBrightness:
            return FeatureSettingsDestination(.energy, sectionAnchor: .extraBrightness)
        case .bluetoothSleep:
            return FeatureSettingsDestination(.energy, sectionAnchor: .bluetoothSleep)

        case .quickLauncher:
            return FeatureSettingsDestination(.quickTools, sectionAnchor: .quickLauncher)
        case .quickToggles:
            return FeatureSettingsDestination(.quickTools, sectionAnchor: .quickToggles)
        case .colorPicker:
            return FeatureSettingsDestination(.screenshot, sectionAnchor: .colorPicker)
        case .screenOCR:
            return FeatureSettingsDestination(.screenshot, sectionAnchor: .screenOCR)
        case .cleaningMode:
            return FeatureSettingsDestination(.quickTools, sectionAnchor: .cleaningMode)
        case .mediaTools: return FeatureSettingsDestination(.media)
        case .cleaner: return FeatureSettingsDestination(.cleaner)
        case .uninstaller: return FeatureSettingsDestination(.uninstaller)
        case .killProcess: return FeatureSettingsDestination(.killProcess)
        case .portManager: return FeatureSettingsDestination(.portManager)
        case .homebrew: return FeatureSettingsDestination(.homebrew)
        case .appUpdates: return FeatureSettingsDestination(.appUpdates)
        case .screenshot:
            return FeatureSettingsDestination(.screenshot, sectionAnchor: .screenshot)
        case .cameraPreview:
            return FeatureSettingsDestination(.quickTools, sectionAnchor: .cameraPreview)
        case .wallpaper:
            return FeatureSettingsDestination(.quickTools, sectionAnchor: .wallpaper)
        case .notch, .notchCalendar, .notchNotifications, .notchGestures, .notchTimer, .notchAccessories, .notchLyrics, .notchQueue, .notchLiveEqualizer, .notchDownloads, .notchAgents, .notchWatch: return FeatureSettingsDestination(.notch)
        case .radialMenu: return FeatureSettingsDestination(.radialMenu)
        case .scratchpad:
            return FeatureSettingsDestination(.quickTools, sectionAnchor: .scratchpad)
        case .commandBar: return FeatureSettingsDestination(.commandBar)
        case .screenRecorder:
            return FeatureSettingsDestination(.screenshot, sectionAnchor: .screenRecorder)

        case .monitorCPU, .monitorGPU, .monitorMemory, .monitorNetwork, .monitorDisk, .monitorPower, .connectedDevices:
            return FeatureSettingsDestination(.monitor)
        case .fanControl:
            return FeatureSettingsDestination(.monitor, sectionAnchor: .fanControl)
        }
    }
}

/// Which hub features keep each Settings page alive. A page with several
/// features only disappears when ALL of them are switched off in the hub.
enum FeatureVisibilitySupport {
    static let monitorFeatures: [AppFeature] = [
        .monitorCPU, .monitorGPU, .monitorMemory, .monitorNetwork, .monitorDisk, .monitorPower,
        .connectedDevices, .fanControl,
    ]

    /// Features gating a page; empty means the page is part of the app and
    /// always shows (General, Shortcuts, About and friends).
    static func features(for page: SettingsPage) -> [AppFeature] {
        switch page {
        case .energy: return [.keepAwake, .brightness, .extraBrightness, .bluetoothSleep]
        case .monitor: return monitorFeatures
        case .mouse: return [.scrollInverter, .scrollHorizontal, .focusFollowsMouse, .smoothScroll, .linearScroll, .mouseAcceleration, .mouseNavigation, .mouseButtonShortcuts,
                             .middleClick, .mouseClickDebounce]
        case .switcher: return [.switcher]
        case .dock: return [.dockPreview, .dockClick]
        case .windowLayout: return [.windowLayout, .windowMaximizer]
        case .autoQuit: return [.autoQuit]
        case .quitProtection: return [.quitWindowProtection]
        case .clipboard: return [.clipboardHistory, .pastePlain, .finderCutPaste]
        case .cutPaste: return [.finderCutPaste, .finderRename]
        case .shelf: return [.shelf]
        case .media: return [.mediaTools]
        case .quickTools: return [.quickLauncher, .quickToggles, .micMute,
                                  .cameraPreview, .wallpaper, .scratchpad, .cleaningMode]
        case .urlCleaner: return [.urlCleaner]
        case .cleaner: return [.cleaner]
        case .homebrew: return [.homebrew]
        case .appUpdates: return [.appUpdates]
        case .uninstaller: return [.uninstaller]
        case .killProcess: return [.killProcess]
        case .portManager: return [.portManager]
        case .keyDebounce: return [.keyboardDebounce]
        case .superKey: return [.superKey]
        case .textSnippets: return [.textSnippets]
        case .screenshot: return [.screenshot, .screenRecorder, .screenOCR, .colorPicker]
        case .notch: return [.notch, .notchCalendar, .notchNotifications, .notchGestures, .notchTimer, .notchAccessories, .notchLyrics, .notchQueue, .notchLiveEqualizer, .notchDownloads, .notchAgents, .notchWatch]
        case .radialMenu: return [.radialMenu]
        case .commandBar: return [.commandBar]
        case .general, .features, .shortcuts, .advanced, .about, .releaseNotes, .support, .transfers, .flow:
            return []
        }
    }

    static func isPageVisible(_ page: SettingsPage,
                              isAvailable: (AppFeature) -> Bool) -> Bool {
        let gate = features(for: page)
        return gate.isEmpty || gate.contains(where: isAvailable)
    }

    /// Whether one of `page`'s features is among `activeFeatures`, the live
    /// users of a permission from `AppFeature.activeFeatures(using:)`. A page
    /// that several features share asks for the grant while any of them uses it.
    static func isPermissionNeeded(on page: SettingsPage,
                                   activeFeatures: [AppFeature]) -> Bool {
        features(for: page).contains(where: activeFeatures.contains)
    }
}
