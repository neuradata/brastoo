// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Vorssaint

import SwiftUI

struct WindowLayoutSettings: View {
    @ObservedObject private var l10n = L10n.shared
    @ObservedObject private var permissions = Permissions.shared
    @ObservedObject private var features = FeatureRuntime.shared
    @ObservedObject private var service = WindowLayoutService.shared
    @ObservedObject private var maximizer = WindowMaximizer.shared
    @AppStorage(DefaultsKey.windowMaximizeEnabled) private var maximizeEnabled = false
    @ObservedObject private var pointerDisplay = PointerDisplayService.shared
    @AppStorage(DefaultsKey.pointerDisplayEnabled) private var pointerDisplayEnabled = false
    @AppStorage(DefaultsKey.panelUtilityWindowLayout) private var showInPanel = true
    @AppStorage(DefaultsKey.windowLayoutShortcutsEnabled) private var shortcutsEnabled = true
    @AppStorage(DefaultsKey.windowDirectionalEnabled) private var directionalEnabled = false
    @AppStorage(DefaultsKey.windowDirectionalShortcut) private var directionalShortcutRaw = GlobalShortcut.windowDirectionalDefault.storageValue
    @AppStorage(DefaultsKey.windowEdgeSnapEnabled) private var edgeSnapEnabled = false
    @AppStorage(DefaultsKey.windowEdgeSnapDisabledZones) private var edgeSnapDisabledZones = ""
    @AppStorage(DefaultsKey.windowGestureEnabled) private var gestureEnabled = false
    @AppStorage(DefaultsKey.windowGestureModifiers) private var gestureModifiers = WindowGestureSupport.defaultModifierStorageValue
    @AppStorage(DefaultsKey.windowGestureRaiseWindow) private var gestureRaiseWindow = false
    @AppStorage(DefaultsKey.windowLayoutWindowGap) private var windowGap = 0
    @AppStorage(DefaultsKey.windowLayoutScreenGap) private var screenGap = 0
    @AppStorage(DefaultsKey.windowLayoutSideRepeatCyclesThirds) private var sideRepeatCyclesThirds = false
    @State private var systemTilingEnabled = WindowEdgeSnapSupport.isSystemTilingEnabled
    // Same preference the Switcher page exposes next to Dock Preview; it is
    // mirrored here because it is a window-juggling behavior people look for
    // on this page too.
    @AppStorage(DefaultsKey.dockClickCycleWindows) private var dockClickCycleWindows = false

    private var text: WindowLayoutFeatureStrings {
        FeatureStrings.windowLayout(l10n.language)
    }

    var body: some View {
        Form {
            if AppFeature.windowLayout.isAvailable {
                Section {
                    Toggle(text.showInPanel, isOn: $showInPanel)
                    Text(text.caption)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Label(text.permissionCaption, systemImage: "hand.raised")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            if !permissions.accessibility {
                Section(l10n.s.permissionRequired) {
                    PermissionRow(kind: .accessibility)
                }
            }

            // The green button override has no page of its own; it lives here
            // with the other window behaviors and keeps this page reachable
            // when it is the only one of the two still switched on in the hub.
            if AppFeature.windowMaximizer.isAvailable {
                windowMaximizerSection
            }

            if AppFeature.windowLayout.isAvailable {
                Section(text.gestureSection) {
                    Toggle(text.edgeSnapEnable, isOn: $edgeSnapEnabled)
                        .onChange(of: edgeSnapEnabled) { _, _ in
                            WindowLayoutService.shared.syncWithPreferences()
                        }
                    Text(text.edgeSnapCaption)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    WindowEdgeSnapZonePicker(disabledZonesStorage: $edgeSnapDisabledZones,
                                             text: text,
                                             resetTitle: l10n.s.shortcutReset)
                        .disabled(!edgeSnapEnabled)
                        .opacity(edgeSnapEnabled ? 1 : 0.45)
                        .onChange(of: edgeSnapDisabledZones) { _, _ in
                            WindowLayoutService.shared.syncWithPreferences()
                        }
                    if systemTilingEnabled {
                        Label(text.edgeSnapSystemConflict, systemImage: "exclamationmark.triangle.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                        if edgeSnapEnabled {
                            Text(text.edgeSnapWaitingForSystem)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Button(text.edgeSnapOpenSystemSettings) {
                            NSWorkspace.shared.open(WindowEdgeSnapSupport.desktopAndDockSettingsURL)
                        }
                        .controlSize(.small)
                    }
                    Toggle(text.gestureEnable, isOn: $gestureEnabled)
                        .onChange(of: gestureEnabled) { _, _ in
                            WindowLayoutService.shared.syncWithPreferences()
                        }
                    Text(text.gestureCaption)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if gestureEnabled {
                        WindowGestureModifierPicker(storageValue: $gestureModifiers,
                                                    title: text.gestureModifiers)
                            .onChange(of: gestureModifiers) { _, _ in
                                WindowLayoutService.shared.syncWithPreferences()
                            }
                        WindowGestureHints(modifierStorage: gestureModifiers,
                                           moveText: text.gestureMove,
                                           resizeText: text.gestureResize)
                        Text(text.gestureResizeHint)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Toggle(text.gestureRaiseWindow, isOn: $gestureRaiseWindow)
                    }
                }

                Section(FeatureStrings.windowLayoutIgnoredApps(l10n.language).sectionTitle) {
                    WindowLayoutIgnoredAppsList()
                }

                Section(text.gapsSection) {
                    gapPicker(text.windowGap, selection: $windowGap)
                    gapPicker(text.screenGap, selection: $screenGap)
                    Text(text.gapsCaption)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section(text.shortcuts) {
                    Toggle(text.shortcuts, isOn: $shortcutsEnabled)
                        .onChange(of: shortcutsEnabled) { _, _ in
                            WindowLayoutService.shared.syncWithPreferences()
                        }
                    Text(text.shortcutsCaption)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if !service.failedShortcutActions.isEmpty {
                        Text(l10n.s.shortcutUnavailable)
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                    Toggle(WindowDirectionalStrings.localized(l10n.language).title,
                           isOn: $directionalEnabled)
                        .onChange(of: directionalEnabled) { _, _ in service.syncWithPreferences() }
                    Text(WindowDirectionalStrings.localized(l10n.language).caption)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if directionalEnabled {
                        ShortcutRecorderButton(shortcut: directionalShortcut,
                                               isEnabled: permissions.accessibility,
                                               waitingTitle: l10n.s.shortcutPressKeys,
                                               invalidAction: {},
                                               captureAction: saveDirectionalShortcut)
                            .frame(width: 108)
                        if service.directionalShortcutRegistrationFailed {
                            Text(l10n.s.shortcutUnavailable)
                                .font(.caption)
                                .foregroundStyle(.orange)
                        }
                    }
                }

                // The pointer moves without Accessibility, so this sits outside
                // the window shortcuts toggle and works before that grant.
                Section {
                    Toggle(PointerDisplayStrings.localized(l10n.language).title,
                           isOn: $pointerDisplayEnabled)
                        .onChange(of: pointerDisplayEnabled) { _, _ in
                            // Also syncs the pointer key, and starts or stops
                            // watching app switches for Ignore apps.
                            service.syncWithPreferences()
                        }
                    Text(PointerDisplayStrings.localized(l10n.language).caption)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    ShortcutPreferenceRow(role: .pointerNextDisplay,
                                          isEnabled: pointerDisplayEnabled,
                                          additionalConflict: {
                                              service.shortcutConflictTitle($0)
                                          }) {
                        pointerDisplay.syncWithPreferences()
                    }
                    if pointerDisplayEnabled, pointerDisplay.shortcutRegistrationFailed {
                        Text(l10n.s.shortcutUnavailable)
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                }

                Section {
                    Toggle(l10n.s.dockClickCycleWindows, isOn: $dockClickCycleWindows)
                        .onChange(of: dockClickCycleWindows) { _, _ in
                            DockClickService.shared.syncWithPreferences()
                        }
                    Text(l10n.s.dockClickCycleWindowsCaption)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                placementSections

                Section(text.other) {
                    actionRow(.maximize)
                    actionRow(.marginMaximize)
                    actionRow(.fullScreen)
                    actionRow(.center)
                    actionRow(.previousDisplay)
                    actionRow(.nextDisplay)
                    actionRow(.restore)
                    if let message = resultMessage {
                        Text(message)
                            .font(.caption)
                            .foregroundStyle(resultColor)
                    }
                }
            }
        }
        .formStyle(.grouped)
        .onAppear { refreshSystemTilingState() }
        .onReceive(NotificationCenter.default.publisher(
            for: NSApplication.didBecomeActiveNotification)) { _ in
            refreshSystemTilingState()
        }
    }

    private var windowMaximizerSection: some View {
        Section {
            Toggle(l10n.s.windowMaximizeName, isOn: $maximizeEnabled)
                .onChange(of: maximizeEnabled) { _, _ in
                    WindowMaximizer.shared.syncWithPreferences()
                }
            Text(l10n.s.windowMaximizeCaption)
                .font(.caption)
                .foregroundStyle(.secondary)
            if maximizeEnabled, maximizer.isRunning {
                Label(l10n.s.windowMaximizeActiveNow, systemImage: "checkmark.circle.fill")
                    .font(.caption)
                    .foregroundStyle(.green)
            }
            WindowMaximizerExclusionsList()
        }
        .settingsFormSectionAnchor(.windowMaximizer)
    }

    private var directionalShortcut: GlobalShortcut {
        GlobalShortcut(storageValue: directionalShortcutRaw) ?? .windowDirectionalDefault
    }

    private func saveDirectionalShortcut(_ shortcut: GlobalShortcut) {
        guard service.directionalShortcutConflictTitle(shortcut) == nil else { return }
        directionalShortcutRaw = shortcut.storageValue
        service.syncWithPreferences()
    }

    /// The gaps take effect on the next placement — the engine reads them
    /// per apply — so the pickers need no service sync.
    private func gapPicker(_ title: String, selection: Binding<Int>) -> some View {
        Picker(title, selection: selection) {
            ForEach(WindowLayoutGaps.presets, id: \.self) { value in
                Text(gapPresetTitle(value)).tag(value)
            }
        }
        .pickerStyle(.menu)
    }

    private func gapPresetTitle(_ value: Int) -> String {
        let name: String
        switch value {
        case 0: return text.gapNone
        case 8: name = text.gapTiny
        case 16: name = text.gapSmall
        case 32: name = text.gapMedium
        case 64: name = text.gapLarge
        case 128: name = text.gapExtraLarge
        default: return "\(value) px"
        }
        return "\(name) (\(value) px)"
    }

    private func refreshSystemTilingState() {
        systemTilingEnabled = WindowEdgeSnapSupport.isSystemTilingEnabled
        WindowLayoutService.shared.syncWithPreferences()
    }

    private static let halfActions: [WindowLayoutAction] = [
        .leftHalf, .rightHalf, .topHalf, .bottomHalf, .centerHalf,
    ]
    private static let thirdActions: [WindowLayoutAction] = [
        .leftThird, .centerThird, .rightThird, .leftTwoThirds, .rightTwoThirds, .centerTwoThirds,
        .topThird, .middleThird, .bottomThird, .topTwoThirds, .bottomTwoThirds,
    ]
    private static let quarterRowActions: [WindowLayoutAction] = [
        .topQuarter, .upperMiddleQuarter, .lowerMiddleQuarter, .bottomQuarter,
    ]
    private static let quarterColumnActions: [WindowLayoutAction] = [
        .leftQuarter, .leftMiddleQuarter, .rightMiddleQuarter, .rightQuarter,
    ]
    private static let sixthActions: [WindowLayoutAction] = [
        .topLeftSixth, .topCenterSixth, .topRightSixth,
        .bottomLeftSixth, .bottomCenterSixth, .bottomRightSixth,
    ]
    private static let cornerActions: [WindowLayoutAction] = [
        .topLeft, .topRight, .bottomLeft, .bottomRight,
    ]

    /// The placement families, grouped so the form body stays within the
    /// ten-view ViewBuilder limit.
    @ViewBuilder
    private var placementSections: some View {
        Section(text.halves) {
            ForEach(Self.halfActions) { action in
                actionRow(action)
            }
            Toggle(text.sideRepeatCycle, isOn: $sideRepeatCyclesThirds)
            Text(text.sideRepeatCycleCaption)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        actionSection(text.thirds, Self.thirdActions)
        actionSection(text.quarterRows, Self.quarterRowActions)
        actionSection(text.quarterColumns, Self.quarterColumnActions)
        actionSection(text.sixths, Self.sixthActions)
        actionSection(text.corners, Self.cornerActions)
    }

    /// One section per placement family. Building the rows from an array keeps
    /// each section clear of the ten-view ViewBuilder limit and keeps the form
    /// body small enough for the type checker.
    private func actionSection(_ title: String, _ actions: [WindowLayoutAction]) -> some View {
        Section(title) {
            ForEach(actions) { action in
                actionRow(action)
            }
        }
    }

    /// One row per action: try-it button on the left, the action's global
    /// shortcut recorder inline on the right — every action is adjustable
    /// right where it lives, no separate shortcut list to hunt for.
    private func actionRow(_ action: WindowLayoutAction) -> some View {
        WindowLayoutActionRow(action: action,
                              title: title(for: action),
                              symbol: symbol(for: action),
                              applyEnabled: permissions.accessibility,
                              shortcutEnabled: shortcutsEnabled && permissions.accessibility)
    }

    private func title(for action: WindowLayoutAction) -> String {
        action.title(text)
    }

    private func symbol(for action: WindowLayoutAction) -> String {
        action.symbolName
    }

    private var resultMessage: String? {
        switch service.lastResult {
        case .success(let restored): return restored ? text.restored : text.done
        case .failure(.missingAccessibility): return text.missingPermission
        case .failure(.noWindow): return text.noWindow
        case .failure(.noRestore): return text.noRestore
        case .failure(.failed): return text.failed
        case nil: return nil
        }
    }

    private var resultColor: Color {
        switch service.lastResult {
        case .success: return .green
        case .failure: return .orange
        case nil: return .secondary
        }
    }
}

private struct WindowLayoutActionRow: View {
    @ObservedObject private var l10n = L10n.shared
    let action: WindowLayoutAction
    let title: String
    let symbol: String
    let applyEnabled: Bool
    let shortcutEnabled: Bool
    @AppStorage private var rawValue: String
    @State private var errorText: String?
    @State private var isRecording = false
    @State private var pendingTakeOver: GlobalShortcut?

    init(action: WindowLayoutAction,
         title: String,
         symbol: String,
         applyEnabled: Bool,
         shortcutEnabled: Bool) {
        self.action = action
        self.title = title
        self.symbol = symbol
        self.applyEnabled = applyEnabled
        self.shortcutEnabled = shortcutEnabled
        _rawValue = AppStorage(
            wrappedValue: action.defaultShortcut?.storageValue
                ?? WindowLayoutAction.clearedShortcutStorageValue,
            action.shortcutKey
        )
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 8) {
                Button {
                    WindowLayoutService.shared.apply(action)
                } label: {
                    Label(title, systemImage: symbol)
                }
                .disabled(!applyEnabled)
                Spacer()
                ShortcutRecorderButton(shortcut: pendingTakeOver
                                           ?? shortcut
                                           ?? action.defaultShortcut
                                           ?? .windowLayoutLeftDefault,
                                       isEnabled: shortcutEnabled,
                                       waitingTitle: l10n.s.shortcutPressKeys,
                                       emptyTitle: pendingTakeOver == nil && shortcut == nil ? l10n.s.shortcutNone : nil,
                                       clearAction: clear,
                                       notCapturedAction: { errorText = l10n.s.shortcutNotCaptured },
                                       recordingChanged: { recording in
                                           isRecording = recording
                                           if recording {
                                               errorText = nil
                                               pendingTakeOver = nil
                                           }
                                       },
                                       invalidAction: { errorText = l10n.s.shortcutInvalid },
                                       captureAction: save)
                    .frame(width: 108)
                    .disabled(!shortcutEnabled)
                Button {
                    clear()
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .symbolRenderingMode(.hierarchical)
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                .disabled(!shortcutEnabled || shortcut == nil)
                .help(l10n.s.shortcutClear)
                .accessibilityLabel(l10n.s.shortcutClear)
                Button(l10n.s.shortcutReset) {
                    rawValue = action.defaultShortcut?.storageValue
                        ?? WindowLayoutAction.clearedShortcutStorageValue
                    errorText = nil
                    pendingTakeOver = nil
                    SystemShortcutTakeover.setTakeOver(action.shortcutKey, false)
                    WindowLayoutService.shared.syncWithPreferences()
                }
                .disabled(!shortcutEnabled || shortcut == action.defaultShortcut)
            }
            if let errorText {
                Text(errorText)
                    .font(.caption)
                    .foregroundStyle(.orange)
            } else if isRecording {
                Text(ShortcutRecordingCaption.text(l10n.s, canClear: true))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            if let pendingTakeOver {
                SystemShortcutTakeOverOffer(
                    shortcut: pendingTakeOver,
                    onAccept: {
                        rawValue = pendingTakeOver.storageValue
                        SystemShortcutTakeover.setTakeOver(action.shortcutKey, true)
                        self.pendingTakeOver = nil
                        WindowLayoutService.shared.syncWithPreferences()
                    },
                    onDismiss: {
                        self.pendingTakeOver = nil
                        errorText = String(format: l10n.s.shortcutConflictFormat, "macOS")
                    }
                )
            }
        }
        .onChange(of: l10n.language) { _, _ in errorText = nil }
    }

    private var shortcut: GlobalShortcut? {
        WindowLayoutAction.resolvedShortcut(storedValue: rawValue,
                                            defaultShortcut: action.defaultShortcut)
    }

    private func clear() {
        rawValue = WindowLayoutAction.clearedShortcutStorageValue
        errorText = nil
        pendingTakeOver = nil
        SystemShortcutTakeover.setTakeOver(action.shortcutKey, false)
        WindowLayoutService.shared.syncWithPreferences()
    }

    private func save(_ shortcut: GlobalShortcut) {
        if let conflict = GlobalShortcutRole.conflict(for: shortcut, excluding: nil) {
            errorText = String(format: l10n.s.shortcutConflictFormat, conflict.title(l10n.s))
            return
        }
        if let conflict = WindowLayoutService.shared.shortcutConflictTitle(shortcut, excluding: action) {
            errorText = String(format: l10n.s.shortcutConflictFormat, conflict)
            return
        }
        // The offer is the last word on a combination: every other check has
        // already passed, so accepting it writes exactly what a save writes.
        switch SystemShortcutTakeoverSupport.recorderDecision(
            shortcut: shortcut,
            conflictsWithMacOS: SystemShortcutTakeover.conflictsWithMacOS(shortcut),
            takenOver: SystemShortcutTakeover.isTakenOver(action.shortcutKey),
            current: GlobalShortcut(storageValue: rawValue)) {
        case .offer:
            pendingTakeOver = shortcut
            errorText = nil
            return
        case .save(let clearTakeOver):
            rawValue = shortcut.storageValue
            errorText = nil
            if clearTakeOver { SystemShortcutTakeover.setTakeOver(action.shortcutKey, false) }
        }
        WindowLayoutService.shared.syncWithPreferences()
    }
}
