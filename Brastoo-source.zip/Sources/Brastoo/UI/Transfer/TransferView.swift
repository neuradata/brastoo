// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import SwiftUI
import UniformTypeIdentifiers

/// The file transfer window: offer a file or folder and get a code for it, or
/// paste a code and fetch what it names. Every transfer shows its progress,
/// speed and time left; this is also what opens from the menu bar status.
struct TransferView: View {
    @ObservedObject private var service = TransferService.shared
    @ObservedObject private var l10n = L10n.shared
    @Environment(\.colorScheme) private var colorScheme
    @AppStorage(TransferPreferences.Key.destinationPath) private var destinationPath = ""
    @State private var code = ""
    @State private var codeRejected = false
    @State private var dropTargeted = false
    @State private var linkCopied = false

    private var text: TransferStrings { TransferStrings.localized(l10n.language) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                header
                if service.engineAvailable {
                    TransferSummary(activity: service.activity, text: text)
                    sendCard
                    receiveCard
                    shareStrip
                } else {
                    Text(text.engineMissing)
                        .font(.callout)
                        .foregroundStyle(Color.orange)
                }
            }
            .padding(24)
        }
        .frame(width: 640, height: 720)
    }

    private var header: some View {
        HStack(alignment: .center, spacing: 14) {
            BrandMark(width: 60, tint: colorScheme == .dark ? Color.white : Color(white: 0.05))
            VStack(alignment: .leading, spacing: 4) {
                Text(text.windowTitle)
                    .font(.title2.bold())
                Text(text.intro)
                    .font(.system(size: 12.5))
                    .foregroundStyle(Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 8)
            Button {
                SettingsRouter.shared.page = .transfers
                appDelegate()?.openSettingsWindow()
            } label: {
                Label(text.settingsButton, systemImage: "gearshape")
            }
            .controlSize(.small)
        }
    }

    // MARK: - Share

    /// The other side needs the app too. This says so, and hands over the
    /// link to send along: for a Mac, for Windows, or both in one message.
    private var shareStrip: some View {
        VStack(spacing: 10) {
            VStack(spacing: 2) {
                Text(text.compatibility)
                    .font(.system(size: 12.5, weight: .semibold))
                    .foregroundStyle(Color.black)
                Text(text.shareHint)
                    .font(.system(size: 12))
                    .foregroundStyle(Color.black.opacity(0.72))
            }
            .multilineTextAlignment(.center)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity)
            Menu {
                Button(text.copyMacLink) { copyLink(BrastooDownloads.mac) }
                Button(text.copyWindowsLink) { copyLink(BrastooDownloads.windows) }
                Divider()
                Button(text.copyBothLinks) {
                    copyLink(String(format: text.bothLinksFormat,
                                    BrastooDownloads.mac, BrastooDownloads.windows))
                }
            } label: {
                Label(linkCopied ? text.linkCopied : text.shareButton,
                      systemImage: linkCopied ? "checkmark" : "square.and.arrow.up")
            }
            .menuStyle(.button)
            .buttonStyle(ShareButtonStyle())
            .fixedSize()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Self.noticeYellow)
        )
        // Set apart from the tool itself: this is about the other side.
        .padding(.top, 18)
    }

    /// The yellow of a notice, the same in light and dark.
    private static let noticeYellow = Color(red: 1.0, green: 0.82, blue: 0.20)

    private func copyLink(_ link: String) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(link, forType: .string)
        linkCopied = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
            linkCopied = false
        }
    }

    // MARK: - Send

    private var sendCard: some View {
        TransferCard(title: text.sendTitle, symbol: "arrow.up.circle.fill") {
            dropZone
            ForEach(service.sends) { session in
                TransferSendRow(session: session, text: text)
            }
        }
    }

    private var dropZone: some View {
        VStack(spacing: 8) {
            Image(systemName: "tray.and.arrow.up")
                .font(.system(size: 22))
                .foregroundStyle(Theme.brandBlue)
            Text(text.dropHint)
                .font(.system(size: 12.5))
                .foregroundStyle(Color.secondary)
            Button(text.chooseButton) { chooseSource() }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 18)
        .background(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(dropTargeted ? Theme.brandBlue.opacity(0.12) : Color.clear)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .strokeBorder(dropTargeted ? Theme.brandBlue : Color.secondary.opacity(0.35),
                              style: StrokeStyle(lineWidth: 1.2, dash: [5, 4]))
        )
        .onDrop(of: [UTType.fileURL], isTargeted: $dropTargeted) { providers in
            for provider in providers {
                _ = provider.loadObject(ofClass: URL.self) { url, _ in
                    guard let url else { return }
                    DispatchQueue.main.async {
                        TransferService.shared.startSending(url)
                    }
                }
            }
            return !providers.isEmpty
        }
    }

    private func chooseSource() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = true
        guard panel.runModal() == .OK else { return }
        for url in panel.urls {
            service.startSending(url)
        }
    }

    // MARK: - Receive

    private var receiveCard: some View {
        TransferCard(title: text.receiveTitle, symbol: "arrow.down.circle.fill") {
            HStack(spacing: 8) {
                TextField(text.codePlaceholder, text: $code)
                    .textFieldStyle(.roundedBorder)
                    .font(.system(size: 12, design: .monospaced))
                    .onSubmit { startReceiving() }
                Button(text.receiveButton) { startReceiving() }
                    .buttonStyle(.borderedProminent)
                    .tint(Theme.brandBlue)
                    .disabled(code.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            if codeRejected {
                Text(text.invalidCode)
                    .font(.caption)
                    .foregroundStyle(Color.orange)
            }
            HStack(spacing: 6) {
                Text(text.destinationLabel)
                    .font(.caption)
                    .foregroundStyle(Color.secondary)
                Image(systemName: "folder")
                    .font(.caption)
                    .foregroundStyle(Color.secondary)
                // Read through the stored path so a change in Settings shows here.
                Text(destinationName)
                    .font(.caption.weight(.medium))
                    .lineLimit(1)
                    .truncationMode(.middle)
                Spacer(minLength: 8)
                Button(text.changeButton) { chooseDestination() }
                    .controlSize(.small)
            }
            ForEach(service.receives) { session in
                TransferReceiveRow(session: session, text: text)
            }
        }
    }

    private var destinationName: String {
        _ = destinationPath
        return TransferPreferences.destination.lastPathComponent
    }

    private func startReceiving() {
        let pasted = code.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !pasted.isEmpty else { return }
        if service.startReceiving(code: pasted, into: TransferPreferences.destination) {
            code = ""
            codeRejected = false
        } else {
            codeRejected = true
        }
    }

    private func chooseDestination() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.canCreateDirectories = true
        panel.allowsMultipleSelection = false
        panel.directoryURL = TransferPreferences.destination
        guard panel.runModal() == .OK, let url = panel.url else { return }
        destinationPath = url.path
    }
}

/// The share button of the notice: the elephant's blue whatever window is
/// in front, so it never fades into the yellow behind it.
private struct ShareButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 13, weight: .semibold))
            .foregroundStyle(Color.white)
            .padding(.horizontal, 16)
            .padding(.vertical, 7)
            .background(Capsule().fill(Theme.brandBlue.opacity(configuration.isPressed ? 0.8 : 1)))
            .contentShape(Capsule())
    }
}

/// The two live totals at the top of the window: what is going out and what
/// is coming in, right now.
private struct TransferSummary: View {
    let activity: TransferActivity
    let text: TransferStrings

    var body: some View {
        HStack(spacing: 12) {
            if activity.isEmpty {
                Text(text.summaryIdle)
                    .font(.system(size: 12.5))
                    .foregroundStyle(Color.secondary)
                Spacer(minLength: 0)
            } else {
                if let upload = activity.upload {
                    tile(symbol: "arrow.up", title: text.sendTitle, flow: upload)
                }
                if let download = activity.download {
                    tile(symbol: "arrow.down", title: text.receiveTitle, flow: download)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Theme.washedBlack)
        )
        .environment(\.colorScheme, .dark)
    }

    private func tile(symbol: String, title: String, flow: TransferActivity.Flow) -> some View {
        HStack(spacing: 10) {
            Image(systemName: symbol)
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(Theme.brandBlue)
                .frame(width: 30, height: 30)
                .background(Circle().fill(Theme.brandBlue.opacity(0.18)))
            VStack(alignment: .leading, spacing: 2) {
                Text(title.uppercased())
                    .font(.system(size: 9.5, weight: .bold))
                    .foregroundStyle(Color.white.opacity(0.55))
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(TransferFormat.rate(flow.rate))
                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color.white)
                        .monospacedDigit()
                    Text(TransferFormat.percent(flow.fraction))
                        .font(.system(size: 13, weight: .medium, design: .rounded))
                        .foregroundStyle(Color.white.opacity(0.7))
                        .monospacedDigit()
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// A titled panel, the frame both halves of the window share.
private struct TransferCard<Content: View>: View {
    let title: String
    let symbol: String
    let content: Content

    init(title: String, symbol: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.symbol = symbol
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 7) {
                Image(systemName: symbol)
                    .foregroundStyle(Theme.brandBlue)
                Text(title)
            }
            .font(.headline)
            content
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color(nsColor: .controlBackgroundColor))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .strokeBorder(Color(nsColor: .separatorColor).opacity(0.5))
        )
    }
}

/// Progress bar with the figures under it: how much, how fast, how long.
private struct TransferMeter: View {
    let fraction: Double
    let doneBytes: Double
    let totalBytes: Double
    let rate: Double
    let text: TransferStrings

    private var figures: String {
        var parts = [TransferFormat.percent(fraction)]
        if totalBytes > 0 {
            parts.append(String(format: text.ofFormat,
                                TransferFormat.size(doneBytes), TransferFormat.size(totalBytes)))
        }
        if rate > 0 {
            parts.append(TransferFormat.rate(rate))
            let left = max(totalBytes - doneBytes, 0)
            if left > 0 {
                parts.append(String(format: text.remainingFormat, TransferFormat.duration(left / rate)))
            }
        }
        return parts.joined(separator: "  ·  ")
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            ProgressView(value: min(max(fraction, 0), 1))
                .progressViewStyle(.linear)
                .tint(Theme.brandBlue)
            Text(figures)
                .font(.system(size: 11.5))
                .foregroundStyle(Color.secondary)
                .monospacedDigit()
                .lineLimit(1)
        }
    }
}

private struct TransferSendRow: View {
    @ObservedObject var session: TransferSend
    let text: TransferStrings
    @State private var copied = false

    private static let clock: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .short
        return formatter
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 9) {
                Image(nsImage: NSWorkspace.shared.icon(forFile: session.source.path))
                    .resizable()
                    .frame(width: 26, height: 26)
                VStack(alignment: .leading, spacing: 1) {
                    Text(session.source.lastPathComponent)
                        .font(.system(size: 12.5, weight: .medium))
                        .lineLimit(1)
                        .truncationMode(.middle)
                    if let size = session.sizeText {
                        Text(size)
                            .font(.caption)
                            .foregroundStyle(Color.secondary)
                    }
                }
                Spacer(minLength: 8)
                trailing
            }
            detail
        }
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 9, style: .continuous)
                .fill(Color.secondary.opacity(0.07))
        )
    }

    @ViewBuilder
    private var trailing: some View {
        switch session.state {
        case .preparing:
            ProgressView()
                .controlSize(.small)
            Button(text.cancel) { TransferService.shared.remove(session) }
                .controlSize(.small)
        case .ready:
            Button(text.stop) { TransferService.shared.stop(session) }
                .controlSize(.small)
        case .stopped, .expired, .failed:
            Button(text.remove) { TransferService.shared.remove(session) }
                .controlSize(.small)
        }
    }

    @ViewBuilder
    private var detail: some View {
        switch session.state {
        case .preparing:
            Text(text.preparing)
                .font(.caption)
                .foregroundStyle(Color.secondary)
        case let .ready(ticket):
            HStack(spacing: 8) {
                Text(ticket)
                    .font(.system(size: 11, design: .monospaced))
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .textSelection(.enabled)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 5)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .fill(Color(nsColor: .textBackgroundColor))
                    )
                Button(copied ? text.copied : text.copyCode) {
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString(ticket, forType: .string)
                    copied = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                        copied = false
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(Theme.brandBlue)
                .controlSize(.small)
            }
            if let upload = session.upload {
                Label(String(format: text.uploadingToFormat, upload.peer), systemImage: "arrow.up")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(Theme.brandBlue)
                TransferMeter(fraction: upload.fraction,
                              doneBytes: upload.sentBytes,
                              totalBytes: upload.totalBytes,
                              rate: upload.rate,
                              text: text)
            } else {
                Text(waitingLine)
                    .font(.caption)
                    .foregroundStyle(Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        case .stopped:
            Text(text.stopped)
                .font(.caption)
                .foregroundStyle(Color.secondary)
        case .expired:
            Text(text.expired)
                .font(.caption)
                .foregroundStyle(Color.secondary)
        case let .failed(reason):
            Text(reason.isEmpty ? text.sendFailed : "\(text.sendFailed) \(reason)")
                .font(.caption)
                .foregroundStyle(Color.orange)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    /// What to do with the code, and when it stops working.
    private var waitingLine: String {
        guard let expiry = session.expiresAt else { return text.readyHint }
        let expires = String(format: text.expiresFormat, Self.clock.string(from: expiry))
        return "\(text.readyHint) \(expires)."
    }
}

private struct TransferReceiveRow: View {
    @ObservedObject var session: TransferReceive
    let text: TransferStrings

    private var title: String {
        if let name = session.name, !name.isEmpty { return name }
        // Until the sender names the content, the start of its code stands in.
        return String(session.ticket.prefix(18)) + "…"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 9) {
                Image(systemName: symbol)
                    .font(.system(size: 18))
                    .foregroundStyle(symbolColor)
                    .frame(width: 26)
                Text(title)
                    .font(.system(size: 12.5, weight: .medium))
                    .lineLimit(1)
                    .truncationMode(.middle)
                Spacer(minLength: 8)
                trailing
            }
            detail
        }
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 9, style: .continuous)
                .fill(Color.secondary.opacity(0.07))
        )
    }

    private var symbol: String {
        switch session.state {
        case .connecting, .receiving, .finishing: return "arrow.down.circle"
        case .done: return "checkmark.circle.fill"
        case .cancelled: return "xmark.circle"
        case .failed: return "exclamationmark.triangle.fill"
        }
    }

    private var symbolColor: Color {
        switch session.state {
        case .connecting, .receiving, .finishing: return Theme.brandBlue
        case .cancelled: return Color.secondary
        case .done: return Color.green
        case .failed: return Color.orange
        }
    }

    @ViewBuilder
    private var trailing: some View {
        switch session.state {
        case .connecting, .receiving, .finishing:
            Button(text.cancel) { TransferService.shared.cancel(session) }
                .controlSize(.small)
        case .done:
            Button(text.showInFinder) { TransferService.shared.reveal(session) }
                .controlSize(.small)
            Button(text.remove) { TransferService.shared.remove(session) }
                .controlSize(.small)
        case .cancelled, .failed:
            Button(text.remove) { TransferService.shared.remove(session) }
                .controlSize(.small)
        }
    }

    @ViewBuilder
    private var detail: some View {
        switch session.state {
        case .connecting:
            HStack(spacing: 7) {
                ProgressView()
                    .controlSize(.small)
                Text(text.connecting)
                    .font(.caption)
                    .foregroundStyle(Color.secondary)
            }
        case .receiving:
            TransferMeter(fraction: session.fraction,
                          doneBytes: session.receivedBytes,
                          totalBytes: session.totalBytes,
                          rate: session.rate,
                          text: text)
        case .finishing:
            HStack(spacing: 7) {
                ProgressView()
                    .controlSize(.small)
                Text(text.finishing)
                    .font(.caption)
                    .foregroundStyle(Color.secondary)
            }
        case .done:
            Text(session.totalBytes > 0
                 ? "\(text.done)  ·  \(TransferFormat.size(session.totalBytes))"
                 : text.done)
                .font(.caption)
                .foregroundStyle(Color.secondary)
        case .cancelled:
            Text(text.cancelled)
                .font(.caption)
                .foregroundStyle(Color.secondary)
        case let .failed(reason):
            Text(failureText(reason))
                .font(.caption)
                .foregroundStyle(Color.orange)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private func failureText(_ reason: String) -> String {
        if reason.contains("already exists") { return text.alreadyExists }
        return reason.isEmpty ? text.receiveFailed : "\(text.receiveFailed) \(reason)"
    }
}
