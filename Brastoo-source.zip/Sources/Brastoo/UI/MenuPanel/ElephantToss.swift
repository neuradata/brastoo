// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import SwiftUI

/// The elephant at the top of the panel. Each time the panel opens it tosses
/// the blue square off the tip of its trunk and catches it again: the trunk
/// dips, flicks up, the square turns over in the air and lands, and the trunk
/// gives a little under it. Two seconds later it is the mark again, still,
/// exactly as drawn.
///
/// With Reduce Motion on there is no toss: the mark is simply there.
struct ElephantToss: View {
    var width: CGFloat
    var tint: Color
    /// False for the panel's mark, which tosses when the panel opens. True
    /// for a mark on a page, which tosses every time the page is shown.
    var playsOnAppear = false

    @State private var startedAt: Date?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        Group {
            if let startedAt {
                TimelineView(.animation) { moment in
                    ElephantTossFrame(width: width, tint: tint, time: moment.date.timeIntervalSince(startedAt))
                }
            } else {
                BrandMark(width: width, tint: tint)
            }
        }
        .onAppear {
            // The header is also built again when the panel changes face
            // while it is open; only a panel that has just opened tosses.
            if playsOnAppear || Date().timeIntervalSince(MenuPanelFocus.shared.lastShownAt) < 0.6 { start() }
        }
        .onReceive(NotificationCenter.default.publisher(for: .menuPanelWillShow)) { _ in
            if !playsOnAppear { start() }
        }
    }

    private func start() {
        guard !reduceMotion else {
            startedAt = nil
            return
        }
        let began = Date()
        startedAt = began
        // Back to the plain mark once the toss is over, unless the panel was
        // opened again in the meantime and a newer toss is running.
        DispatchQueue.main.asyncAfter(deadline: .now() + ElephantTossPose.duration + 0.05) {
            if startedAt == began { startedAt = nil }
        }
    }
}

/// Where everything is at one instant of the toss. Angles are in degrees,
/// clockwise; distances are in the artwork's own points (it is 640 wide).
struct ElephantTossPose {
    static let duration = 2.1

    /// How far the trunk is swung from where it is drawn.
    let trunk: Double
    /// Where the square is, from where it is drawn.
    let squareOffset: CGSize
    let squareTurn: Double
    /// The light the square gives off as it lands, 0 to 1.
    let glow: Double
    let opacity: Double
    let scale: Double

    /// True when nothing is moved from the drawing.
    var isAtRest: Bool {
        trunk == 0 && squareOffset == .zero && squareTurn == 0 && glow == 0 && opacity == 1 && scale == 1
    }

    // The mark appears, the trunk dips, flicks, the square flies and lands.
    private static let appear = 0.30
    private static let dipEnds = 0.58
    private static let flickEnds = 0.72
    private static let landing = 1.40
    private static let dip = 9.0
    private static let flick = -22.0
    /// From where the trunk swings to the middle of the square, as drawn.
    private static let reach = CGSize(width: 99, height: 1.5)
    /// How much higher than a straight line the square flies.
    private static let arc = 120.0

    init(at time: Double) {
        let t = max(0, time)
        guard t < Self.duration else {
            trunk = 0
            squareOffset = .zero
            squareTurn = 0
            glow = 0
            opacity = 1
            scale = 1
            return
        }
        let angle = Self.trunkAngle(t)
        trunk = angle
        if t < Self.flickEnds {
            // On the trunk, going where its tip goes.
            squareOffset = Self.carried(by: angle)
            squareTurn = angle
            glow = 0
        } else if t < Self.landing {
            // In the air: from where the flick let go of it back to where it
            // is drawn, over an arc, turning half way round as it goes.
            let u = (t - Self.flickEnds) / (Self.landing - Self.flickEnds)
            let release = Self.trunkAngle(Self.flickEnds)
            let from = Self.carried(by: release)
            squareOffset = CGSize(width: from.width * (1 - u),
                                  height: from.height * (1 - u) - 4 * Self.arc * u * (1 - u))
            squareTurn = release + (-180 - release) * u
            glow = 0
        } else {
            squareOffset = Self.carried(by: angle)
            squareTurn = angle
            glow = exp(-(t - Self.landing) / 0.22) * Self.ending(t)
        }
        opacity = min(1, t / 0.2)
        let u = min(1, t / Self.appear)
        // A little past full size and back, the way something set down settles.
        scale = 0.9 + 0.1 * (1 + 2.2 * pow(u - 1, 3) + 1.2 * pow(u - 1, 2))
    }

    private static func smooth(_ u: Double) -> Double {
        u * u * (3 - 2 * u)
    }

    /// 1 until the last quarter second, then down to 0, so the end is still.
    private static func ending(_ t: Double) -> Double {
        t > duration - 0.25 ? smooth(max(0, min(1, (duration - t) / 0.25))) : 1
    }

    private static func trunkAngle(_ t: Double) -> Double {
        if t < appear { return 0 }
        if t < dipEnds {
            return dip * smooth((t - appear) / (dipEnds - appear))
        }
        if t < flickEnds {
            let u = (t - dipEnds) / (flickEnds - dipEnds)
            return dip + (flick - dip) * (1 - pow(1 - u, 3))
        }
        // The trunk swings back from the flick and settles...
        let sinceFlick = t - flickEnds
        var angle = flick * exp(-6 * sinceFlick) * cos(9 * sinceFlick)
        // ...and gives under the square when it lands.
        if t >= landing {
            let sinceLanding = t - landing
            angle += 13.5 * exp(-7 * sinceLanding) * sin(11 * sinceLanding)
        }
        return angle * ending(t)
    }

    /// Where the square is taken when the trunk it sits on swings by `angle`.
    private static func carried(by angle: Double) -> CGSize {
        let radians = angle * .pi / 180
        let x = reach.width * cos(radians) - reach.height * sin(radians)
        let y = reach.width * sin(radians) + reach.height * cos(radians)
        return CGSize(width: x - reach.width, height: y - reach.height)
    }
}

/// One instant of the toss, drawn from the mark's own artwork: the body
/// stays, the trunk is the same picture cut where it leaves the head and
/// swung from there, and the square is moved on its own.
struct ElephantTossFrame: View {
    var width: CGFloat
    var tint: Color
    /// Seconds since the toss began.
    var time: Double

    // Measured on the artwork, which is 640 by 325.
    private static let art = CGSize(width: 640, height: 325)
    /// The middle of the stroke where the trunk leaves the head.
    private static let pivot = CGPoint(x: 447, y: 118)
    private static let strokeWidth: CGFloat = 38
    /// Everything right of this and below the pivot is trunk.
    private static let trunkLeft: CGFloat = 400
    /// The body keeps a little of the trunk's start, so no seam shows
    /// between the two pictures.
    private static let overlap: CGFloat = 8
    private static let squareCentre = CGPoint(x: 546, y: 119.5)

    var body: some View {
        let pose = ElephantTossPose(at: time)
        let scale = width / Self.art.width
        let height = Self.art.height * scale
        Group {
            if pose.isAtRest {
                BrandMark(width: width, tint: tint)
            } else if let mark = BrandMark.mark {
                ZStack {
                    picture(mark)
                        .mask {
                            ElephantCut(part: .body, trunkLeft: Self.trunkLeft, trunkTop: Self.pivot.y + Self.overlap)
                                .fill(style: FillStyle(eoFill: true))
                        }
                    picture(mark)
                        .mask {
                            ElephantCut(part: .trunk, trunkLeft: Self.trunkLeft, trunkTop: Self.pivot.y)
                        }
                        .rotationEffect(.degrees(pose.trunk), anchor: Self.unit(Self.pivot))
                    // The elbow: a round joint the width of the stroke, so the
                    // swung trunk meets the head without a gap.
                    Circle()
                        .fill(tint)
                        .frame(width: (Self.strokeWidth - 2) * scale, height: (Self.strokeWidth - 2) * scale)
                        .position(x: Self.pivot.x * scale, y: Self.pivot.y * scale)
                    if let accent = BrandMark.accent {
                        Image(nsImage: accent)
                            .interpolation(.high)
                            .antialiased(true)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .rotationEffect(.degrees(pose.squareTurn), anchor: Self.unit(Self.squareCentre))
                            .shadow(color: Theme.brandBlue.opacity(0.9 * pose.glow), radius: 3)
                            .offset(x: pose.squareOffset.width * scale, y: pose.squareOffset.height * scale)
                    }
                }
                .frame(width: width, height: height)
                .scaleEffect(pose.scale)
                // Faded as one picture: the joint lies over the stroke, and
                // would show through it if each part faded on its own.
                .compositingGroup()
                .opacity(pose.opacity)
            } else {
                BrandMark(width: width, tint: tint)
            }
        }
    }

    private func picture(_ mark: NSImage) -> some View {
        Image(nsImage: mark)
            .renderingMode(.template)
            .interpolation(.high)
            .antialiased(true)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .foregroundStyle(tint)
    }

    private static func unit(_ point: CGPoint) -> UnitPoint {
        UnitPoint(x: point.x / art.width, y: point.y / art.height)
    }
}

/// The two halves the mark is cut into for the toss, as shapes over the
/// artwork: the trunk's corner, or everything but it.
private struct ElephantCut: Shape {
    enum Part {
        case body, trunk
    }

    let part: Part
    let trunkLeft: CGFloat
    let trunkTop: CGFloat

    func path(in bounds: CGRect) -> Path {
        let sx = bounds.width / 640
        let sy = bounds.height / 325
        let trunk = CGRect(x: bounds.minX + trunkLeft * sx, y: bounds.minY + trunkTop * sy,
                           width: bounds.width - trunkLeft * sx, height: bounds.height - trunkTop * sy)
        var path = Path()
        switch part {
        case .trunk:
            path.addRect(trunk)
        case .body:
            // The whole picture with the trunk's corner left out.
            path.addRect(bounds)
            path.addRect(trunk)
        }
        return path
    }
}
