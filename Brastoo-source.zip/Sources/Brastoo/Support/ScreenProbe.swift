// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

#if BRASTOO_DEVELOPMENT
import AppKit
import SwiftUI

/// Draws the screens that came with 1.7.0 into pictures and exits, so they
/// can be looked at without anyone opening them by hand:
///
///     BrastooDeveloper --telas <folder>
///
/// The windows are real ones, kept fully transparent and deaf to the mouse,
/// so nothing shows on the display. One whole Mac Review is also run, to see
/// it through its stages: the cleaning stage with a stand-in that opens
/// nothing of the person's, the protection and speed stages for real, since
/// those only read. Nothing is cleaned and no chore is run.
enum ScreenProbe {
    /// Never key, never main: the probe must not take the keyboard from
    /// whatever the person is doing.
    private final class ProbeWindow: NSWindow {
        override var canBecomeKey: Bool { false }
        override var canBecomeMain: Bool { false }
    }

    private typealias Step = (wait: TimeInterval, work: (@escaping () -> Void) -> Void)

    private static var folder = URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
    private static var steps: [Step] = []
    private static var windows: [NSWindow] = []
    private static var languageBefore: String?

    static func runIfRequestedAndExit() {
        let arguments = CommandLine.arguments
        guard let flag = arguments.firstIndex(of: "--telas"), arguments.count > flag + 1 else { return }
        folder = URL(fileURLWithPath: arguments[flag + 1], isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        setvbuf(stdout, nil, _IOLBF, 0)

        let app = NSApplication.shared
        app.setActivationPolicy(.accessory)
        DispatchQueue.main.async {
            prepare()
            plan()
            next()
        }
        app.run()
        exit(0)
    }

    // MARK: - The plan

    private static func prepare() {
        languageBefore = UserDefaults.standard.string(forKey: DefaultsKey.language)
        L10n.shared.language = .ptBR
        ReviewChime.probeSilenced = true
        ReviewDiskMap.measuresFolders = false
        ReviewApps.measuresSizes = false
        MacReview.cleanerScanStandIn = { JunkCleaner.shared.probeScan(secondsPerCategory: 0.45) }
        // The sound, written out to be measured.
        try? ReviewChime.probeData.write(to: folder.appendingPathComponent("som.wav"))
        print("TELAS idioma do sistema: \(Locale.preferredLanguages.first ?? "?") · versão \(AppInfo.version)")
    }

    private static func plan() {
        let reviewSize = NSSize(width: 920, height: 640)
        let reviewHost = NSHostingController(rootView: AnyView(MacReviewView()))
        var review: NSWindow?

        add(0.1) { review = open(reviewHost, size: reviewSize, dark: true, title: MacReviewText.name) }
        add(0.9) {
            shoot(review, "01-analise-inicio")
            // The sidebar is glass, which a picture taken this way leaves
            // blank. Its rows are counted instead, and the Settings window,
            // whose sidebar is built the same way and is known to work, is
            // put through the same two checks for comparison.
            countRows(review, "Revisão do Mac")
        }
        var settings: NSWindow?
        add(0.05) {
            settings = open(NSHostingController(rootView: AnyView(SettingsView())),
                            size: NSSize(width: 920, height: 640), dark: true, title: "Ajustes")
        }
        add(1.0) {
            shoot(settings, "00-ajustes-para-comparar")
            countRows(settings, "Ajustes")
        }
        add(0.05) { close(settings) }

        let pages: [(ReviewTab, String, TimeInterval)] = [
            (.cleaning, "02-limpeza-inicio", 0.7),
            (.protection, "03-protecao-inicio", 0.5),
            (.speed, "04-velocidade-inicio", 0.5),
            (.largeFiles, "05-arquivos-grandes", 0.5),
            (.diskMap, "06-mapa-do-disco", 1.0),
            (.apps, "07-gerenciar-aplicativos", 2.5),
            (.updates, "08-atualizacoes-ao-entrar", 1.2),
        ]
        for (tab, name, wait) in pages {
            add(0.05) { MacReviewRouter.shared.tab = tab }
            add(wait) {
                if tab == .updates {
                    print("TELAS atualizações: procurando ao entrar = \(AppUpdatesService.shared.isChecking)")
                }
                if tab == .apps {
                    print("TELAS aplicativos listados: \(ReviewApps.shared.apps.count)")
                }
                shoot(review, name)
            }
        }

        // The searches that read the disk, pointed at places anyone may
        // read, so macOS has nothing to ask the person about.
        add(0.05) {
            print("TELAS arquivos grandes, por padrão: \(ReviewLargeFiles.shared.folders.map { ReviewPath.short($0.path) }), entra em \(ReviewLargeFiles.probeRootTops())")
            MacReviewRouter.shared.tab = .largeFiles
            ReviewLargeFiles.shared.probeSearch(in: [URL(fileURLWithPath: "/Applications")])
        }
        add(0.7) { shoot(review, "05b-arquivos-grandes-procurando") }
        steps.append((0.1, { done in
            until(atMost: 60, for: { !ReviewLargeFiles.shared.scanning }) { seconds in
                print(String(format: "TELAS arquivos grandes: %d em %.1f s", ReviewLargeFiles.shared.entries.count, seconds))
                done()
            }
        }))
        add(0.4) { shoot(review, "05c-arquivos-grandes-resultado") }
        add(0.05) {
            MacReviewRouter.shared.tab = .diskMap
            ReviewDiskMap.measuresFolders = true
            ReviewDiskMap.shared.open(URL(fileURLWithPath: "/Library"))
        }
        add(1.5) { shoot(review, "06b-mapa-medindo") }
        steps.append((0.1, { done in
            until(atMost: 60, for: { !ReviewDiskMap.shared.measuring }) { seconds in
                print(String(format: "TELAS mapa de /Library: %@ em %.1f s", ReviewSizes.text(ReviewDiskMap.shared.total), seconds))
                done()
            }
        }))
        add(0.4) { shoot(review, "06c-mapa-medido") }
        add(0.05) {
            MacReviewRouter.shared.tab = .apps
            ReviewApps.measuresSizes = true
            ReviewApps.shared.load()
        }
        add(7.0) {
            let apps = ReviewApps.shared.apps
            print("TELAS aplicativos medidos em 7 s: \(apps.filter { $0.size != nil }.count) de \(apps.count)")
            shoot(review, "07b-aplicativos-medindo")
        }

        // An analysis cancelled half way leaves everything as it was.
        add(0.05) {
            MacReviewRouter.shared.tab = .overview
            MacReview.shared.analyse()
        }
        add(1.3) { MacReview.shared.cancel() }
        add(0.6) {
            print("TELAS cancelada: revisão \(MacReview.shared.phase), limpeza \(JunkCleaner.shared.phase), proteção \(ReviewProtection.shared.phase)")
            shoot(review, "09-analise-cancelada")
        }

        // One whole analysis, watched.
        add(0.05) { MacReviewRouter.shared.tab = .overview }
        steps.append((0.4, { done in watchAnalysis(review, host: reviewHost, done: done) }))
        add(0.5) { shoot(review, "10-analise-concluida") }
        add(0.05) { MacReviewRouter.shared.tab = .protection }
        add(0.6) { shoot(review, "11-protecao-resultado") }
        add(0.05) { MacReviewRouter.shared.tab = .speed }
        add(0.6) { shoot(review, "12-velocidade-resultado") }
        add(0.05) {
            MacReviewRouter.shared.tab = .overview
            review?.appearance = NSAppearance(named: .aqua)
        }
        add(0.7) { shoot(review, "13-analise-concluida-claro") }
        // Carried out with nothing ticked, which changes nothing on the Mac
        // and still goes through every step to the end.
        add(0.05) {
            review?.appearance = NSAppearance(named: .darkAqua)
            ReviewSpeed.shared.ticked = []
            MacReview.shared.run()
        }
        add(0.8) {
            print("TELAS executada sem nada marcado: \(MacReview.shared.phase), comemorando \(MacReview.shared.celebrating)")
            shoot(review, "13b-analise-executada")
        }
        // A chore shown as done, and then the celebration and the way back.
        add(0.05) {
            ReviewSpeed.shared.probeMarkDone(.memory)
            ReviewSpeed.shared.probeMarkDone(.quickLook)
            MacReviewRouter.shared.tab = .speed
            review?.setContentSize(NSSize(width: 920, height: 1500))
        }
        add(0.8) {
            shoot(review, "12b-velocidade-feita")
            review?.setContentSize(NSSize(width: 920, height: 640))
        }
        add(0.05) {
            ReviewFanfare.probeSilenced = true
            MacReview.shared.probeCelebrate(freed: 3_420_000_000, chores: 3)
        }
        add(1.0) { shoot(review, "23-comemoracao-a") }
        add(1.3) { shoot(review, "23-comemoracao-b") }
        add(0.05) { review?.appearance = NSAppearance(named: .aqua) }
        add(0.8) { shoot(review, "23-comemoracao-claro") }
        add(0.05) {
            review?.appearance = NSAppearance(named: .darkAqua)
            MacReview.shared.startOver()
        }
        add(0.8) {
            print("TELAS depois da comemoração: \(MacReview.shared.phase), aba \(MacReviewRouter.shared.tab), proteção \(ReviewProtection.shared.findings.count), velocidade \(ReviewSpeed.shared.readings.count), limpeza \(JunkCleaner.shared.phase)")
            shoot(review, "24-depois-da-comemoracao")
        }
        add(0.05) { close(review) }

        // About and Transfer, dark and light.
        for dark in [true, false] {
            let suffix = dark ? "escuro" : "claro"
            var about: NSWindow?
            add(0.05) {
                about = open(NSHostingController(rootView: AnyView(AboutSettings())),
                             size: NSSize(width: 620, height: 760), dark: dark, title: "Sobre")
            }
            add(0.75) { shoot(about, "14-sobre-\(suffix)-animando") }
            add(2.0) { shoot(about, "14-sobre-\(suffix)") }
            add(0.05) { close(about) }
            if dark {
                // Stretched: the art at the foot must keep its size.
                var wide: NSWindow?
                add(0.05) {
                    wide = open(NSHostingController(rootView: AnyView(AboutSettings())),
                                size: NSSize(width: 1100, height: 900), dark: dark, title: "Sobre")
                }
                add(2.0) { shoot(wide, "14-sobre-esticada") }
                add(0.05) { close(wide) }
                var license: NSWindow?
                add(0.05) {
                    print("TELAS licença: texto \(LicenseNotice.licenseFile != nil), fonte \(LicenseNotice.sourceArchive != nil)")
                    license = open(NSHostingController(rootView: AnyView(LicenseNotice())),
                                   size: NSSize(width: 362, height: 170), dark: dark, title: "Licença")
                }
                add(0.6) { shoot(license, "15-licenca") }
                add(0.05) { close(license) }
            }

            var transfer: NSWindow?
            add(0.05) {
                transfer = open(NSHostingController(rootView: AnyView(TransferView())),
                                size: NSSize(width: 640, height: 720), dark: dark,
                                title: TransferStrings.localized(.ptBR).windowTitle)
            }
            add(0.7) { shoot(transfer, "15-transferir-\(suffix)") }
            add(0.05) { close(transfer) }
        }

        // The elephant: the toss frame by frame, and then running by itself.
        for dark in [true, false] {
            var sheet: NSWindow?
            add(0.05) {
                sheet = open(NSHostingController(rootView: AnyView(tossSheet(dark: dark))),
                             size: NSSize(width: 1230, height: 880), dark: dark, title: "", titled: false)
            }
            add(0.6) { shoot(sheet, dark ? "16-elefante-quadros-escuro" : "17-elefante-quadros-claro") }
            add(0.05) { close(sheet) }
        }
        var alive: NSWindow?
        add(0.05) {
            alive = open(NSHostingController(rootView: AnyView(tossAlive())),
                         size: NSSize(width: 420, height: 260), dark: true, title: "", titled: false)
        }
        add(0.6) { NotificationCenter.default.post(name: .menuPanelWillShow, object: nil) }
        add(0.66) { shoot(alive, "18-elefante-sozinho-066") }
        add(0.40) { shoot(alive, "19-elefante-sozinho-106") }
        add(0.50) { shoot(alive, "20-elefante-sozinho-156") }
        add(1.00) { shoot(alive, "21-elefante-sozinho-fim") }
        add(0.05) { close(alive) }

        // The panel's tools, where the review has its tile. Last, since it
        // wakes the most of the app.
        var tools: NSWindow?
        add(0.05) {
            let section = ScrollView {
                UtilitiesSection(collapsible: false, startCleaning: {})
                    .padding(12)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Theme.washedBlack)
            tools = open(NSHostingController(rootView: AnyView(section)),
                         size: NSSize(width: 340, height: 760), dark: true, title: "", titled: false)
        }
        add(0.9) { shoot(tools, "22-painel-utilitarios") }
        add(0.05) { close(tools) }
    }

    private static func add(_ wait: TimeInterval, _ work: @escaping () -> Void) {
        steps.append((wait, { done in
            work()
            done()
        }))
    }

    private static func next() {
        guard !steps.isEmpty else {
            finish()
            return
        }
        let step = steps.removeFirst()
        DispatchQueue.main.asyncAfter(deadline: .now() + step.wait) {
            step.work { next() }
        }
    }

    /// Waits until something is so, looking ten times a second, for no
    /// longer than `limit` seconds, and says how long it took.
    private static func until(atMost limit: TimeInterval, for condition: @escaping () -> Bool,
                             then: @escaping (TimeInterval) -> Void) {
        let began = Date()
        func look() {
            let elapsed = Date().timeIntervalSince(began)
            if condition() || elapsed > limit {
                then(elapsed)
            } else {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { look() }
            }
        }
        look()
    }

    private static func finish() {
        if let languageBefore {
            UserDefaults.standard.set(languageBefore, forKey: DefaultsKey.language)
        } else {
            UserDefaults.standard.removeObject(forKey: DefaultsKey.language)
        }
        print("TELAS PRONTAS")
        exit(0)
    }

    // MARK: - The analysis

    /// Starts an analysis and takes a picture of each stage as it runs: one
    /// as the window stands, and one with the page built again, which shows
    /// the same moment even if the window was not being redrawn.
    private static func watchAnalysis(_ window: NSWindow?, host: NSHostingController<AnyView>, done: @escaping () -> Void) {
        let review = MacReview.shared
        let began = Date()
        var stageBegan: [MacReview.Stage: Date] = [:]
        var pictured = Set<MacReview.Stage>()
        var lastStep = ""
        review.analyse()

        func poll() {
            let elapsed = Date().timeIntervalSince(began)
            let step = review.stepName
            if step != lastStep {
                lastStep = step
                print(String(format: "TELAS análise: %.1f s  %@ (%d itens)", elapsed, step, ScanActivity.shared.latest().count))
            }
            if CommandLine.arguments.contains("--ritmo"), Int(elapsed * 10) % 5 == 0 {
                // How the scan is moving, twice a second, when asked for.
                let activity = ScanActivity.shared.latest()
                print(String(format: "TELAS   %.1f s  %d  %@", elapsed, activity.count, activity.text))
            }
            if let stage = review.currentStage {
                if stageBegan[stage] == nil {
                    stageBegan[stage] = Date()
                    print(String(format: "TELAS análise: %@ começou aos %.1f s", "\(stage)", elapsed))
                }
                if !pictured.contains(stage), let since = stageBegan[stage], Date().timeIntervalSince(since) >= 0.55 {
                    pictured.insert(stage)
                    let activity = ScanActivity.shared.latest()
                    print(String(format: "TELAS análise: %@ em %.0f%%, %d itens, agora em %@", "\(stage)",
                                 review.fraction(of: stage) * 100, activity.count, activity.text))
                    shoot(window, "09-analise-\(stage)-a")
                    host.rootView = AnyView(MacReviewView().id(UUID()))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        shoot(window, "09-analise-\(stage)-b")
                    }
                }
            }
            if review.phase == .reviewed {
                let protection = ReviewProtection.shared
                let speed = ReviewSpeed.shared
                print(String(format: "TELAS análise: concluída em %.1f s", elapsed))
                print("TELAS proteção: \(protection.findings.count) linhas, \(protection.concerns.count) pedem atenção")
                for finding in protection.findings where finding.weight != .fine {
                    print("TELAS   [\(finding.weight)] \(finding.title)")
                }
                print("TELAS velocidade: \(speed.readings.count) leituras, sugeridas \(speed.suggested.map(\.rawValue).sorted()), marcadas \(speed.ticked.map(\.rawValue).sorted())")
                for reading in speed.readings {
                    print("TELAS   [\(reading.weight)] \(reading.name): \(reading.value)")
                }
                done()
                return
            }
            if elapsed > 80 {
                print("TELAS análise: não terminou em 80 s, parada em \(review.phase)")
                done()
                return
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { poll() }
        }
        poll()
    }

    // MARK: - The elephant

    private static let tossTimes: [Double] = [0, 0.08, 0.16, 0.30, 0.44, 0.58, 0.63, 0.68, 0.72, 0.84,
                                              0.96, 1.08, 1.20, 1.32, 1.40, 1.46, 1.54, 1.66, 1.85, 2.10]

    /// Every frame of the toss side by side: at the size the panel shows it,
    /// inside a box the size of the panel's header, and large.
    private static func tossSheet(dark: Bool) -> some View {
        let tint = dark ? Color.white : Color(white: 0.03)
        let ground = dark ? Theme.washedBlack : Color(white: 0.96)
        return VStack(spacing: 22) {
            HStack(spacing: 6) {
                ForEach(tossTimes, id: \.self) { time in
                    ElephantTossFrame(width: 48, tint: tint, time: time)
                        .frame(height: 28)
                        .padding(.vertical, 4)
                        .frame(width: 54)
                        .border(Color.gray.opacity(0.35), width: 0.5)
                }
            }
            LazyVGrid(columns: Array(repeating: GridItem(.fixed(228), spacing: 12), count: 5), spacing: 14) {
                ForEach(tossTimes, id: \.self) { time in
                    VStack(spacing: 6) {
                        ElephantTossFrame(width: 200, tint: tint, time: time)
                            .frame(width: 216, height: 150)
                        Text(String(format: "%.2f s", time))
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(Color.gray)
                    }
                }
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(ground)
    }

    /// The mark as the panel hosts it, left to start by itself.
    private static func tossAlive() -> some View {
        ElephantToss(width: 280, tint: .white)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Theme.washedBlack)
    }

    // MARK: - Windows and pictures

    private static func open(_ host: NSHostingController<AnyView>, size: NSSize, dark: Bool, title: String,
                             titled: Bool = true) -> NSWindow {
        // As the real windows: the window has the size it is given.
        host.sizingOptions = []
        let window = ProbeWindow(contentViewController: host)
        window.styleMask = titled ? [.titled, .closable, .miniaturizable, .resizable] : [.borderless]
        window.title = title
        window.appearance = NSAppearance(named: dark ? .darkAqua : .aqua)
        window.isReleasedWhenClosed = false
        window.isRestorable = false
        window.setContentSize(size)
        // There, so the system keeps drawing it; transparent, so nobody sees it.
        window.alphaValue = 0
        window.hasShadow = false
        window.ignoresMouseEvents = true
        window.level = .floating
        window.collectionBehavior = [.transient, .ignoresCycle]
        if let screen = NSScreen.main {
            window.setFrameOrigin(NSPoint(x: screen.visibleFrame.minX + 40, y: screen.visibleFrame.minY + 40))
        }
        window.orderFrontRegardless()
        windows.append(window)
        return window
    }

    private static func close(_ window: NSWindow?) {
        guard let window else { return }
        window.orderOut(nil)
        window.contentViewController = nil
        windows.removeAll { $0 === window }
    }

    /// The lists a window holds and how many rows each has: what a sidebar
    /// contains, for the windows whose sidebar a picture leaves blank.
    private static func countRows(_ window: NSWindow?, _ name: String) {
        guard let root = window?.contentView?.superview ?? window?.contentView else { return }
        var found: [String] = []
        func walk(_ view: NSView) {
            if let table = view as? NSTableView {
                found.append("\(type(of: table)) com \(table.numberOfRows) linhas, \(Int(table.frame.width))x\(Int(table.frame.height))")
            }
            view.subviews.forEach(walk)
        }
        walk(root)
        print("TELAS listas em \(name): \(found.isEmpty ? "nenhuma" : found.joined(separator: "; "))")
    }

    /// The whole window, title bar included, as a picture.
    private static func shoot(_ window: NSWindow?, _ name: String) {
        guard let window, let content = window.contentView else {
            print("TELA \(name): sem janela")
            return
        }
        let view = content.superview ?? content
        view.layoutSubtreeIfNeeded()
        guard let picture = view.bitmapImageRepForCachingDisplay(in: view.bounds) else {
            print("TELA \(name): sem imagem")
            return
        }
        view.cacheDisplay(in: view.bounds, to: picture)
        let file = folder.appendingPathComponent(name + ".png")
        try? picture.representation(using: .png, properties: [:])?.write(to: file)
        print("TELA \(name) \(Int(view.bounds.width))x\(Int(view.bounds.height))")
    }
}
#endif
