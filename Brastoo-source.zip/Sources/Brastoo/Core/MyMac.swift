// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import AppKit
import IOKit

/// The kinds of Mac the person can say they have in Settings › General.
enum MacKind: String, CaseIterable, Identifiable {
    case macBook
    case macStudio
    case macMini
    case iMac

    var id: String { rawValue }

    /// Product names are the same in every language.
    var name: String {
        switch self {
        case .macBook: return "MacBook"
        case .macStudio: return "Mac Studio"
        case .macMini: return "Mac mini"
        case .iMac: return "iMac"
        }
    }

    private var imageName: String {
        switch self {
        case .macBook: return "MyMac-macbook"
        case .macStudio: return "MyMac-macstudio"
        case .macMini: return "MyMac-macmini"
        case .iMac: return "MyMac-imac"
        }
    }

    /// The picture for this kind, at its own size. The files are drawn for a
    /// Retina screen, so a point is two of their pixels; nothing is scaled
    /// beyond that.
    var image: NSImage? {
        guard let url = Bundle.main.url(forResource: imageName, withExtension: "png"),
              let image = NSImage(contentsOf: url) else { return nil }
        if let pixels = image.representations.first, pixels.pixelsWide > 0, pixels.pixelsHigh > 0 {
            image.size = NSSize(width: CGFloat(pixels.pixelsWide) / 2,
                                height: CGFloat(pixels.pixelsHigh) / 2)
        }
        return image
    }
}

/// Which Mac this is, as chosen in Settings › General ("My Mac").
///
/// The choice changes one thing only: what Settings and the panel offer.
/// On anything but a MacBook, the options that exist only on a MacBook are
/// hidden: the closed lid, the battery, the keyboard light, running on
/// power. Nothing is switched off by it; a desktop Mac has none of those
/// things for an option to act on.
///
/// Until the person chooses, the kind is worked out from the hardware.
enum MyMac {
    static let storageKey = "myMacKind"

    static var kind: MacKind {
        if let stored = UserDefaults.standard.string(forKey: storageKey),
           let chosen = MacKind(rawValue: stored) {
            return chosen
        }
        return detected
    }

    static func choose(_ kind: MacKind) {
        UserDefaults.standard.set(kind.rawValue, forKey: storageKey)
    }

    static var isMacBook: Bool { kind == .macBook }

    /// Whether battery options are offered: only on a MacBook, and only when
    /// there really is a battery.
    static var showsBattery: Bool { isMacBook && PowerSampler.hasInternalBattery }

    /// Whether keyboard light options are offered.
    static var showsKeyboardLight: Bool { isMacBook && BrightnessService.keyboardLightIsSupported }

    /// What the hardware says. A battery means a MacBook; otherwise the
    /// product name tells the desktops apart. A desktop that is none of the
    /// three (a Mac Pro) counts as a Mac Studio, the closest of them.
    static let detected: MacKind = {
        if PowerSampler.hasInternalBattery { return .macBook }
        let name = (productName() ?? hardwareModel() ?? "").lowercased()
        if name.contains("macbook") { return .macBook }
        if name.contains("imac") { return .iMac }
        if name.contains("mini") { return .macMini }
        return .macStudio
    }()

    /// "Mac mini", "Mac Studio", "iMac" … as the firmware names the product.
    private static func productName() -> String? {
        let entry = IORegistryEntryFromPath(kIOMainPortDefault, "IODeviceTree:/product")
        guard entry != 0 else { return nil }
        defer { IOObjectRelease(entry) }
        let property = IORegistryEntryCreateCFProperty(entry, "product-name" as CFString,
                                                       kCFAllocatorDefault, 0)
        guard let value = property?.takeRetainedValue() else { return nil }
        if let text = value as? String { return text }
        if let data = value as? Data {
            let bytes = data.prefix(while: { $0 != 0 })
            return String(decoding: bytes, as: UTF8.self)
        }
        return nil
    }

    /// The model identifier, which still names the product on older Macs
    /// ("Macmini9,1", "iMac21,1").
    private static func hardwareModel() -> String? {
        var size = 0
        guard sysctlbyname("hw.model", nil, &size, nil, 0) == 0, size > 0 else { return nil }
        var buffer = [CChar](repeating: 0, count: size)
        guard sysctlbyname("hw.model", &buffer, &size, nil, 0) == 0 else { return nil }
        return String(cString: buffer)
    }

    // MARK: - Texts

    static func title(_ language: AppLanguage) -> String {
        switch language {
        case .ptBR: return "Meu Mac"
        case .it: return "Il mio Mac"
        case .es: return "Mi Mac"
        default: return "My Mac"
        }
    }

    static func caption(_ language: AppLanguage) -> String {
        switch language {
        case .ptBR:
            return "Escolha o seu modelo. Fora do MacBook, somem as opções que só existem nele: tampa fechada, bateria e luz do teclado."
        case .it:
            return "Scegli il tuo modello. Se non è un MacBook, spariscono le opzioni che esistono solo lì: coperchio chiuso, batteria e luce della tastiera."
        case .es:
            return "Elige tu modelo. Si no es un MacBook, se ocultan las opciones que solo existen en él: tapa cerrada, batería y luz del teclado."
        default:
            return "Choose your model. On anything but a MacBook, the options that only exist there are hidden: closed lid, battery and keyboard light."
        }
    }
}
