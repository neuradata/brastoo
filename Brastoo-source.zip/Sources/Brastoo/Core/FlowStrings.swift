// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import Foundation

/// The texts of Flow: scenes that prepare the Mac for what the person is
/// about to do and put everything back when they end.
struct FlowStrings {
    // The page
    let tagline: String
    let newScene: String
    let intro: String
    let scenesTitle: String
    let orderHint: String
    let templatesTitle: String
    let templatesCaption: String
    let activeNothingChanged: String
    let endAndRestore: String
    let start: String
    let end: String
    let edit: String
    let moveUp: String
    let moveDown: String
    let delete: String
    let automaticHelp: String
    let notifyTitle: String
    let notifyCaption: String
    let historyTitle: String
    let historyEmpty: String
    let clearHistory: String
    let openFlow: String

    // The editor
    let editorNew: String
    let editorEdit: String
    let nameLabel: String
    let namePlaceholder: String
    let iconLabel: String
    let whenTitle: String
    let triggerManual: String
    let triggerApps: String
    let triggerDisplay: String
    let triggerSecondDisplay: String
    let triggerManualCaption: String
    let triggerAppsCaption: String
    let triggerDisplayCaption: String
    let addApp: String
    let actionsTitle: String
    let actionAwake: String
    let actionAwakeCaption: String
    let actionIcons: String
    let actionIconsCaption: String
    let actionAudio: String
    let actionAudioCaption: String
    let audioKeep: String
    let audioDisconnectedFormat: String
    let actionOpenApps: String
    let actionOpenAppsCaption: String
    let actionOpenItems: String
    let actionOpenItemsCaption: String
    let addFile: String
    let addLink: String
    let shortcutsTitle: String
    let shortcutsCaption: String
    let shortcutStart: String
    let shortcutEnd: String
    let shortcutNone: String
    let remove: String
    let save: String
    let cancel: String

    // One line about a scene
    let summaryManual: String
    let summaryAppsFormat: String
    let summaryDisplay: String
    let shortAwake: String
    let shortIcons: String
    let shortOpensFormat: String
    let shortShortcutFormat: String
    let noActions: String

    // Activity
    let logStarted: String
    let logStartedAuto: String
    let logEnded: String
    let logAwakeOn: String
    let logAwakeOff: String
    let logIconsHidden: String
    let logIconsShown: String
    let logAudio: String
    let logAudioBack: String
    let logOpened: String
    let logShortcut: String
    let logFailed: String
    let logRecovered: String

    // Notification, Command Bar
    let notifyStartedTitle: String
    let notifyStartedBody: String
    let commandStart: String
    let commandEnd: String

    // Templates
    let presetMeeting: String
    let presetMeetingCaption: String
    let presetPresentation: String
    let presetPresentationCaption: String
    let presetDev: String
    let presetDevCaption: String
    let presetRecording: String
    let presetRecordingCaption: String

    static func localized(_ language: AppLanguage) -> FlowStrings {
        switch language {
        case .ptBR:
            return FlowStrings(
                tagline: "Seu Mac muda de modo junto com você.",
                newScene: "Nova cena",
                intro: "Uma cena prepara o Mac para o que você vai fazer e devolve tudo ao que era quando termina. Comece por um modelo abaixo ou crie a sua.",
                scenesTitle: "Suas cenas",
                orderHint: "Uma cena por vez. Se duas puderem começar ao mesmo tempo, vale a que está mais acima.",
                templatesTitle: "Modelos",
                templatesCaption: "Abrem já preenchidos. Nada é criado até você salvar.",
                activeNothingChanged: "Nada foi alterado no sistema.",
                endAndRestore: "Encerrar e restaurar",
                start: "Iniciar",
                end: "Encerrar",
                edit: "Editar…",
                moveUp: "Mover para cima",
                moveDown: "Mover para baixo",
                delete: "Excluir",
                automaticHelp: "Iniciar sozinha quando a condição acontecer",
                notifyTitle: "Avisar quando uma cena começar sozinha",
                notifyCaption: "Uma notificação diz qual cena entrou, para nada mudar sem você saber.",
                historyTitle: "Atividade",
                historyEmpty: "O que as cenas fizerem aparece aqui: o que mudou, quando e o que voltou.",
                clearHistory: "Limpar",
                openFlow: "Abrir Flow",
                editorNew: "Nova cena",
                editorEdit: "Editar cena",
                nameLabel: "Nome",
                namePlaceholder: "Ex.: Reunião",
                iconLabel: "Ícone",
                whenTitle: "Quando começar",
                triggerManual: "Só quando eu iniciar",
                triggerApps: "Quando um destes apps abrir",
                triggerDisplay: "Ao conectar um monitor externo",
                triggerSecondDisplay: "Ao conectar um segundo monitor",
                triggerManualCaption: "Fica ativa até você encerrar.",
                triggerAppsCaption: "A cena termina sozinha quando todos eles forem fechados.",
                triggerDisplayCaption: "A cena termina sozinha quando o monitor for desconectado.",
                addApp: "Adicionar app…",
                actionsTitle: "O que a cena faz",
                actionAwake: "Manter o Mac acordado",
                actionAwakeCaption: "Desliga de novo quando a cena termina.",
                actionIcons: "Ocultar os ícones da Mesa",
                actionIconsCaption: "O Finder reinicia por um instante para ocultar e para mostrar de volta.",
                actionAudio: "Saída de áudio",
                actionAudioCaption: "A saída que estava em uso volta quando a cena termina.",
                audioKeep: "Não alterar",
                audioDisconnectedFormat: "%@ (desconectado)",
                actionOpenApps: "Abrir apps",
                actionOpenAppsCaption: "Continuam abertos quando a cena termina.",
                actionOpenItems: "Abrir arquivos, pastas e links",
                actionOpenItemsCaption: "Um projeto, uma apresentação, a página da reunião.",
                addFile: "Adicionar arquivo ou pasta…",
                addLink: "Adicionar link",
                shortcutsTitle: "Atalhos do macOS",
                shortcutsCaption: "Para o que o macOS só deixa fazer por Atalhos, como ligar um modo de Foco. Crie o atalho no app Atalhos e escolha aqui.",
                shortcutStart: "Ao iniciar",
                shortcutEnd: "Ao encerrar",
                shortcutNone: "Nenhum",
                remove: "Remover",
                save: "Salvar",
                cancel: "Cancelar",
                summaryManual: "Manual",
                summaryAppsFormat: "Quando %@ abrir",
                summaryDisplay: "Com monitor externo",
                shortAwake: "Mac acordado",
                shortIcons: "Mesa limpa",
                shortOpensFormat: "Abre %@",
                shortShortcutFormat: "Atalho %@",
                noActions: "Sem ações ainda",
                logStarted: "Cena “%@” iniciada",
                logStartedAuto: "Cena “%@” iniciada automaticamente",
                logEnded: "Cena “%@” encerrada",
                logAwakeOn: "Manter acordado ligado",
                logAwakeOff: "Manter acordado desligado",
                logIconsHidden: "Ícones da Mesa ocultos",
                logIconsShown: "Ícones da Mesa de volta",
                logAudio: "Saída de áudio: %@",
                logAudioBack: "Saída de áudio de volta para %@",
                logOpened: "Aberto: %@",
                logShortcut: "Atalho executado: %@",
                logFailed: "Não foi possível: %@",
                logRecovered: "Alterações da cena “%@” restauradas ao abrir o app",
                notifyStartedTitle: "Cena “%@” ativa",
                notifyStartedBody: "Tudo volta ao que era quando ela terminar.",
                commandStart: "Iniciar cena: %@",
                commandEnd: "Encerrar cena: %@",
                presetMeeting: "Reunião",
                presetMeetingCaption: "Quando o app de chamadas abrir",
                presetPresentation: "Apresentação",
                presetPresentationCaption: "Ao conectar um monitor",
                presetDev: "Modo Dev",
                presetDevCaption: "Quando o editor de código abrir",
                presetRecording: "Gravação limpa",
                presetRecordingCaption: "Mesa limpa e Mac acordado")
        case .it:
            return FlowStrings(
                tagline: "Il tuo Mac cambia modalità insieme a te.",
                newScene: "Nuova scena",
                intro: "Una scena prepara il Mac per quello che stai per fare e rimette tutto com’era quando finisce. Parti da un modello qui sotto o crea la tua.",
                scenesTitle: "Le tue scene",
                orderHint: "Una scena alla volta. Se due possono partire insieme, vince quella più in alto.",
                templatesTitle: "Modelli",
                templatesCaption: "Si aprono già compilati. Niente viene creato finché non salvi.",
                activeNothingChanged: "Niente è stato modificato nel sistema.",
                endAndRestore: "Termina e ripristina",
                start: "Avvia",
                end: "Termina",
                edit: "Modifica…",
                moveUp: "Sposta su",
                moveDown: "Sposta giù",
                delete: "Elimina",
                automaticHelp: "Avviare da sola quando la condizione si verifica",
                notifyTitle: "Avvisa quando una scena parte da sola",
                notifyCaption: "Una notifica dice quale scena è entrata, così nulla cambia a tua insaputa.",
                historyTitle: "Attività",
                historyEmpty: "Qui compare quello che fanno le scene: cosa è cambiato, quando e cosa è tornato.",
                clearHistory: "Svuota",
                openFlow: "Apri Flow",
                editorNew: "Nuova scena",
                editorEdit: "Modifica scena",
                nameLabel: "Nome",
                namePlaceholder: "Es.: Riunione",
                iconLabel: "Icona",
                whenTitle: "Quando inizia",
                triggerManual: "Solo quando la avvio io",
                triggerApps: "Quando si apre una di queste app",
                triggerDisplay: "Quando collego un monitor esterno",
                triggerSecondDisplay: "Quando collego un secondo monitor",
                triggerManualCaption: "Resta attiva finché non la termini.",
                triggerAppsCaption: "La scena termina da sola quando sono tutte chiuse.",
                triggerDisplayCaption: "La scena termina da sola quando scolleghi il monitor.",
                addApp: "Aggiungi app…",
                actionsTitle: "Cosa fa la scena",
                actionAwake: "Tieni il Mac sveglio",
                actionAwakeCaption: "Si disattiva di nuovo quando la scena termina.",
                actionIcons: "Nascondi le icone della Scrivania",
                actionIconsCaption: "Il Finder si riavvia per un istante per nasconderle e per mostrarle di nuovo.",
                actionAudio: "Uscita audio",
                actionAudioCaption: "L’uscita che era in uso torna quando la scena termina.",
                audioKeep: "Non cambiare",
                audioDisconnectedFormat: "%@ (scollegato)",
                actionOpenApps: "Apri app",
                actionOpenAppsCaption: "Restano aperte quando la scena termina.",
                actionOpenItems: "Apri file, cartelle e link",
                actionOpenItemsCaption: "Un progetto, una presentazione, la pagina della riunione.",
                addFile: "Aggiungi file o cartella…",
                addLink: "Aggiungi link",
                shortcutsTitle: "Comandi rapidi di macOS",
                shortcutsCaption: "Per ciò che macOS permette solo con Comandi rapidi, come attivare una Full immersion. Crea il comando nell’app Comandi rapidi e sceglilo qui.",
                shortcutStart: "All’avvio",
                shortcutEnd: "Al termine",
                shortcutNone: "Nessuno",
                remove: "Rimuovi",
                save: "Salva",
                cancel: "Annulla",
                summaryManual: "Manuale",
                summaryAppsFormat: "Quando si apre %@",
                summaryDisplay: "Con monitor esterno",
                shortAwake: "Mac sveglio",
                shortIcons: "Scrivania pulita",
                shortOpensFormat: "Apre %@",
                shortShortcutFormat: "Comando %@",
                noActions: "Ancora nessuna azione",
                logStarted: "Scena “%@” avviata",
                logStartedAuto: "Scena “%@” avviata automaticamente",
                logEnded: "Scena “%@” terminata",
                logAwakeOn: "Tieni sveglio attivato",
                logAwakeOff: "Tieni sveglio disattivato",
                logIconsHidden: "Icone della Scrivania nascoste",
                logIconsShown: "Icone della Scrivania di nuovo visibili",
                logAudio: "Uscita audio: %@",
                logAudioBack: "Uscita audio di nuovo su %@",
                logOpened: "Aperto: %@",
                logShortcut: "Comando rapido eseguito: %@",
                logFailed: "Non è stato possibile: %@",
                logRecovered: "Modifiche della scena “%@” ripristinate all’apertura dell’app",
                notifyStartedTitle: "Scena “%@” attiva",
                notifyStartedBody: "Tutto torna com’era quando termina.",
                commandStart: "Avvia scena: %@",
                commandEnd: "Termina scena: %@",
                presetMeeting: "Riunione",
                presetMeetingCaption: "Quando si apre l’app per le chiamate",
                presetPresentation: "Presentazione",
                presetPresentationCaption: "Quando colleghi un monitor",
                presetDev: "Modalità Dev",
                presetDevCaption: "Quando si apre l’editor di codice",
                presetRecording: "Registrazione pulita",
                presetRecordingCaption: "Scrivania pulita e Mac sveglio")
        case .es:
            return FlowStrings(
                tagline: "Tu Mac cambia de modo contigo.",
                newScene: "Nueva escena",
                intro: "Una escena prepara el Mac para lo que vas a hacer y lo deja todo como estaba cuando termina. Empieza por un modelo de abajo o crea la tuya.",
                scenesTitle: "Tus escenas",
                orderHint: "Una escena a la vez. Si dos pueden empezar al mismo tiempo, gana la que está más arriba.",
                templatesTitle: "Modelos",
                templatesCaption: "Se abren ya rellenados. No se crea nada hasta que guardes.",
                activeNothingChanged: "No se ha cambiado nada en el sistema.",
                endAndRestore: "Terminar y restaurar",
                start: "Iniciar",
                end: "Terminar",
                edit: "Editar…",
                moveUp: "Mover arriba",
                moveDown: "Mover abajo",
                delete: "Eliminar",
                automaticHelp: "Iniciar sola cuando se cumpla la condición",
                notifyTitle: "Avisar cuando una escena empiece sola",
                notifyCaption: "Una notificación dice qué escena ha entrado, para que nada cambie sin que lo sepas.",
                historyTitle: "Actividad",
                historyEmpty: "Aquí aparece lo que hagan las escenas: qué cambió, cuándo y qué volvió.",
                clearHistory: "Vaciar",
                openFlow: "Abrir Flow",
                editorNew: "Nueva escena",
                editorEdit: "Editar escena",
                nameLabel: "Nombre",
                namePlaceholder: "Ej.: Reunión",
                iconLabel: "Icono",
                whenTitle: "Cuándo empieza",
                triggerManual: "Solo cuando yo la inicie",
                triggerApps: "Cuando se abra una de estas apps",
                triggerDisplay: "Al conectar un monitor externo",
                triggerSecondDisplay: "Al conectar un segundo monitor",
                triggerManualCaption: "Sigue activa hasta que la termines.",
                triggerAppsCaption: "La escena termina sola cuando todas se cierran.",
                triggerDisplayCaption: "La escena termina sola cuando desconectas el monitor.",
                addApp: "Añadir app…",
                actionsTitle: "Qué hace la escena",
                actionAwake: "Mantener el Mac despierto",
                actionAwakeCaption: "Se desactiva de nuevo cuando la escena termina.",
                actionIcons: "Ocultar los iconos del Escritorio",
                actionIconsCaption: "El Finder se reinicia un instante para ocultarlos y para mostrarlos de nuevo.",
                actionAudio: "Salida de audio",
                actionAudioCaption: "La salida que estaba en uso vuelve cuando la escena termina.",
                audioKeep: "No cambiar",
                audioDisconnectedFormat: "%@ (desconectado)",
                actionOpenApps: "Abrir apps",
                actionOpenAppsCaption: "Siguen abiertas cuando la escena termina.",
                actionOpenItems: "Abrir archivos, carpetas y enlaces",
                actionOpenItemsCaption: "Un proyecto, una presentación, la página de la reunión.",
                addFile: "Añadir archivo o carpeta…",
                addLink: "Añadir enlace",
                shortcutsTitle: "Atajos de macOS",
                shortcutsCaption: "Para lo que macOS solo permite con Atajos, como activar un modo de concentración. Crea el atajo en la app Atajos y elígelo aquí.",
                shortcutStart: "Al iniciar",
                shortcutEnd: "Al terminar",
                shortcutNone: "Ninguno",
                remove: "Quitar",
                save: "Guardar",
                cancel: "Cancelar",
                summaryManual: "Manual",
                summaryAppsFormat: "Cuando se abra %@",
                summaryDisplay: "Con monitor externo",
                shortAwake: "Mac despierto",
                shortIcons: "Escritorio limpio",
                shortOpensFormat: "Abre %@",
                shortShortcutFormat: "Atajo %@",
                noActions: "Aún sin acciones",
                logStarted: "Escena “%@” iniciada",
                logStartedAuto: "Escena “%@” iniciada automáticamente",
                logEnded: "Escena “%@” terminada",
                logAwakeOn: "Mantener despierto activado",
                logAwakeOff: "Mantener despierto desactivado",
                logIconsHidden: "Iconos del Escritorio ocultos",
                logIconsShown: "Iconos del Escritorio de vuelta",
                logAudio: "Salida de audio: %@",
                logAudioBack: "Salida de audio de vuelta a %@",
                logOpened: "Abierto: %@",
                logShortcut: "Atajo ejecutado: %@",
                logFailed: "No se pudo: %@",
                logRecovered: "Cambios de la escena “%@” restaurados al abrir la app",
                notifyStartedTitle: "Escena “%@” activa",
                notifyStartedBody: "Todo vuelve a como estaba cuando termine.",
                commandStart: "Iniciar escena: %@",
                commandEnd: "Terminar escena: %@",
                presetMeeting: "Reunión",
                presetMeetingCaption: "Cuando se abra la app de llamadas",
                presetPresentation: "Presentación",
                presetPresentationCaption: "Al conectar un monitor",
                presetDev: "Modo Dev",
                presetDevCaption: "Cuando se abra el editor de código",
                presetRecording: "Grabación limpia",
                presetRecordingCaption: "Escritorio limpio y Mac despierto")
        default:
            return FlowStrings(
                tagline: "Your Mac changes mode along with you.",
                newScene: "New scene",
                intro: "A scene gets the Mac ready for what you are about to do and puts everything back when it ends. Start from a template below or make your own.",
                scenesTitle: "Your scenes",
                orderHint: "One scene at a time. If two could start together, the one higher up wins.",
                templatesTitle: "Templates",
                templatesCaption: "They open already filled in. Nothing is created until you save.",
                activeNothingChanged: "Nothing was changed on the system.",
                endAndRestore: "End and restore",
                start: "Start",
                end: "End",
                edit: "Edit…",
                moveUp: "Move up",
                moveDown: "Move down",
                delete: "Delete",
                automaticHelp: "Start on its own when the condition happens",
                notifyTitle: "Tell me when a scene starts on its own",
                notifyCaption: "A notification says which scene came on, so nothing changes without you knowing.",
                historyTitle: "Activity",
                historyEmpty: "What scenes do shows up here: what changed, when, and what came back.",
                clearHistory: "Clear",
                openFlow: "Open Flow",
                editorNew: "New scene",
                editorEdit: "Edit scene",
                nameLabel: "Name",
                namePlaceholder: "E.g. Meeting",
                iconLabel: "Icon",
                whenTitle: "When it starts",
                triggerManual: "Only when I start it",
                triggerApps: "When one of these apps opens",
                triggerDisplay: "When an external display is connected",
                triggerSecondDisplay: "When a second display is connected",
                triggerManualCaption: "Stays on until you end it.",
                triggerAppsCaption: "The scene ends on its own once all of them are closed.",
                triggerDisplayCaption: "The scene ends on its own when the display is disconnected.",
                addApp: "Add app…",
                actionsTitle: "What the scene does",
                actionAwake: "Keep the Mac awake",
                actionAwakeCaption: "Switches off again when the scene ends.",
                actionIcons: "Hide the Desktop icons",
                actionIconsCaption: "The Finder restarts for a moment to hide them and to show them again.",
                actionAudio: "Sound output",
                actionAudioCaption: "The output that was in use comes back when the scene ends.",
                audioKeep: "Leave as it is",
                audioDisconnectedFormat: "%@ (disconnected)",
                actionOpenApps: "Open apps",
                actionOpenAppsCaption: "They stay open when the scene ends.",
                actionOpenItems: "Open files, folders and links",
                actionOpenItemsCaption: "A project, a presentation, the meeting page.",
                addFile: "Add file or folder…",
                addLink: "Add link",
                shortcutsTitle: "macOS Shortcuts",
                shortcutsCaption: "For what macOS only allows through Shortcuts, such as turning a Focus on. Make the shortcut in the Shortcuts app and choose it here.",
                shortcutStart: "On start",
                shortcutEnd: "On end",
                shortcutNone: "None",
                remove: "Remove",
                save: "Save",
                cancel: "Cancel",
                summaryManual: "Manual",
                summaryAppsFormat: "When %@ opens",
                summaryDisplay: "With an external display",
                shortAwake: "Mac awake",
                shortIcons: "Clean Desktop",
                shortOpensFormat: "Opens %@",
                shortShortcutFormat: "Shortcut %@",
                noActions: "No actions yet",
                logStarted: "Scene “%@” started",
                logStartedAuto: "Scene “%@” started automatically",
                logEnded: "Scene “%@” ended",
                logAwakeOn: "Keep Awake on",
                logAwakeOff: "Keep Awake off",
                logIconsHidden: "Desktop icons hidden",
                logIconsShown: "Desktop icons back",
                logAudio: "Sound output: %@",
                logAudioBack: "Sound output back to %@",
                logOpened: "Opened: %@",
                logShortcut: "Shortcut run: %@",
                logFailed: "Could not: %@",
                logRecovered: "Changes from the scene “%@” restored when the app opened",
                notifyStartedTitle: "Scene “%@” on",
                notifyStartedBody: "Everything goes back to how it was when it ends.",
                commandStart: "Start scene: %@",
                commandEnd: "End scene: %@",
                presetMeeting: "Meeting",
                presetMeetingCaption: "When the calls app opens",
                presetPresentation: "Presentation",
                presetPresentationCaption: "When a display is connected",
                presetDev: "Dev mode",
                presetDevCaption: "When the code editor opens",
                presetRecording: "Clean recording",
                presetRecordingCaption: "Clean Desktop and Mac awake")
        }
    }
}
