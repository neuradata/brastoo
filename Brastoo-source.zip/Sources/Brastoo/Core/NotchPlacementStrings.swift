// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import Foundation

/// The texts of two Dynamic Island settings: hiding it until the pointer
/// reaches it, and moving it left or right of the middle of the display.
struct NotchPlacementStrings {
    let autoHideTitle: String
    let autoHideCaption: String
    /// Under the ways of opening, which hiding leaves no choice about.
    let autoHideOpening: String
    let positionTitle: String
    let horizontal: String
    let centre: String
    let positionHint: String

    static func localized(_ language: AppLanguage) -> NotchPlacementStrings {
        switch language {
        case .ptBR:
            return NotchPlacementStrings(
                autoHideTitle: "Ocultar automaticamente",
                autoHideCaption: "A ilha fica fora de vista e aparece quando o ponteiro encosta no topo da tela, no lugar dela. Se você descer o ponteiro sem clicar, ela some de novo, como o Dock. Enquanto está oculta, não mostra avisos.",
                autoHideOpening: "Com o ocultar automático ligado, a ilha abre ao passar o ponteiro.",
                positionTitle: "Posição",
                horizontal: "Horizontal",
                centre: "Centralizar",
                positionHint: "Valores negativos levam a ilha para a esquerda; positivos, para a direita. O limite é até onde ela ainda abre inteira na tela. Vale para telas sem câmera embutida.")
        case .it:
            return NotchPlacementStrings(
                autoHideTitle: "Nascondi automaticamente",
                autoHideCaption: "L’isola resta fuori vista e appare quando il puntatore tocca il bordo superiore dello schermo, al suo posto. Se abbassi il puntatore senza fare clic, sparisce di nuovo, come il Dock. Mentre è nascosta non mostra avvisi.",
                autoHideOpening: "Con il nascondi automatico attivo, l’isola si apre al passaggio del puntatore.",
                positionTitle: "Posizione",
                horizontal: "Orizzontale",
                centre: "Centra",
                positionHint: "I valori negativi spostano l’isola a sinistra; quelli positivi, a destra. Il limite è fin dove si apre ancora per intero sullo schermo. Vale per gli schermi senza fotocamera integrata.")
        case .es:
            return NotchPlacementStrings(
                autoHideTitle: "Ocultar automáticamente",
                autoHideCaption: "La isla queda fuera de la vista y aparece cuando el puntero toca el borde superior de la pantalla, en su lugar. Si bajas el puntero sin hacer clic, vuelve a ocultarse, como el Dock. Mientras está oculta no muestra avisos.",
                autoHideOpening: "Con el ocultar automático activado, la isla se abre al pasar el puntero.",
                positionTitle: "Posición",
                horizontal: "Horizontal",
                centre: "Centrar",
                positionHint: "Los valores negativos llevan la isla a la izquierda; los positivos, a la derecha. El límite es hasta donde aún se abre entera en la pantalla. Vale para pantallas sin cámara integrada.")
        default:
            return NotchPlacementStrings(
                autoHideTitle: "Hide automatically",
                autoHideCaption: "The island stays out of sight and appears when the pointer touches the top of the screen where it sits. Move the pointer away without clicking and it hides again, like the Dock. While hidden it shows no notices.",
                autoHideOpening: "With automatic hiding on, the island opens when the pointer reaches it.",
                positionTitle: "Position",
                horizontal: "Horizontal",
                centre: "Centre",
                positionHint: "Negative values move the island left; positive ones, right. The limit is as far as it still opens whole on the screen. Applies to displays without a built-in camera.")
        }
    }
}
