// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Vorssaint

import Foundation

/// Static identity of the app, shared by UI, notifications and tooling.
enum AppInfo {
    static let name = "Brastoo"
    /// The brand line. It is a name, not a sentence to translate: the same in
    /// every language.
    static let slogan = "A ton of tools. One app."
    // Brastoo is a modified version of Vorssaint (© 2026 Vorssaint,
    // GPL-3.0-or-later). Every copy says so where the license asks it to:
    // the License button in About names the terms, the lack of warranty and
    // the project this one changes, and opens the license text and the source
    // archive that build.sh puts inside the app. Nothing else in the interface
    // names the upstream project.
    static let upstreamRepositoryURL = URL(string: "https://github.com/vorssaint/vorssaint-utils")!

    /// "owner/repository" on GitHub whose releases carry Brastoo's own DMGs, or
    /// nil while Brastoo has no update feed. With nil the app never checks for,
    /// downloads or installs updates. Before turning this on, also replace the
    /// signing team in UpdateInstallerSupport's code requirements.
    static let updateRepository: String? = nil

    /// Temporary links for screenshots and recordings and the in-app feedback
    /// form are served by the upstream project's own server. Brastoo has no
    /// server of its own, so both stay off instead of sending this app's
    /// uploads and reports to someone else's.
    static let hostedServicesEnabled = false

    /// The donation, Discord and social pages belong to the upstream project
    /// and its author. Off until Brastoo has links of its own.
    static let communityLinksEnabled = false

    static let websiteURL = upstreamRepositoryURL
    static let repositoryURL = upstreamRepositoryURL
    static let coffeeURL = upstreamRepositoryURL
    static let discordURL = upstreamRepositoryURL
    static let socialURL = upstreamRepositoryURL

    /// The bundle version. The fallback only applies to the bare binary
    /// (e.g. `--selftest`), never the shipped app, which reads its Info.plist.
    static var version: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "dev"
    }

    /// True for the local "Brastoo (Developer)" build (bundle id ends in `.dev`).
    /// It is never published and never auto-updates; all work is tested here first.
    static var isDeveloperBuild: Bool {
        (Bundle.main.bundleIdentifier ?? "").hasSuffix(".dev")
    }

    /// True when the current version is a pre-release (e.g. 3.3.4-beta.1 or 3.3.4-rc.1).
    static var isBeta: Bool {
        if isDeveloperBuild && UserDefaults.standard.bool(forKey: DefaultsKey.simulateBetaUI) {
            return true
        }
        let v = version.lowercased()
        return v.contains("-beta") || v.contains("-rc") || v.contains("-alpha")
    }

    /// The git commit a Developer build was compiled from, e.g. "ed2ebba · 2026-06-15 21:30"
    /// (or with a "-dirty" suffix on the SHA for uncommitted changes). build.sh stamps
    /// this into the Developer bundle only, so you can confirm at a glance that the
    /// running dev app matches the source you are about to change. nil in the official app.
    static var buildCommit: String? {
        Bundle.main.object(forInfoDictionaryKey: "BrastooBuildCommit") as? String
    }
}
