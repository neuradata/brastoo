// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import Foundation

/// Where whoever is going to receive gets Brastoo for their own computer.
enum BrastooDownloads {
    static let mac = "https://genera.downloads.fotag.app/Brastoo.dmg"
    static let windows = "https://genera.downloads.fotag.app/Brastoo-Setup.exe"
}

/// The words of the file transfer window, its menu item and its Command Bar
/// row. Portuguese, English, Italian and Spanish have their own; every other
/// language reads the English.
struct TransferStrings {
    let windowTitle: String
    let footerButton: String
    let menuItem: String
    let commandTitle: String
    let intro: String
    let compatibility: String
    /// The line under it, asking for the download link to be passed on.
    let shareHint: String
    let shareButton: String
    let copyMacLink: String
    let copyWindowsLink: String
    let copyBothLinks: String
    let linkCopied: String
    /// Takes the Mac link and then the Windows link.
    let bothLinksFormat: String

    let sendTitle: String
    let dropHint: String
    let chooseButton: String
    let preparing: String
    let readyHint: String
    let copyCode: String
    let copied: String
    let stop: String
    let remove: String
    let stopped: String
    let sendFailed: String

    let receiveTitle: String
    let codePlaceholder: String
    let receiveButton: String
    let destinationLabel: String
    let changeButton: String
    let connecting: String
    let receiving: String
    /// Takes the amount already on disk, e.g. "1,2 GB".
    let receivedFormat: String
    let done: String
    let showInFinder: String
    let cancel: String
    let cancelled: String
    let receiveFailed: String
    let alreadyExists: String
    let invalidCode: String
    let engineMissing: String

    // Live status
    let waiting: String
    /// Takes the short id of the computer that is downloading.
    let uploadingToFormat: String
    let finishing: String
    /// Takes the amount moved and the total, e.g. "210 MB" and "467 MB".
    let ofFormat: String
    /// Takes the time left, e.g. "1:23".
    let remainingFormat: String
    /// Takes a time of day.
    let expiresFormat: String
    let expired: String
    let summaryIdle: String
    let settingsButton: String

    // Notifications
    let notifyDoneTitle: String
    let notifyFailedTitle: String
    let notifyUploadTitle: String
    /// Takes the name of the item being fetched.
    let notifyUploadBodyFormat: String

    // Settings page
    let settingsTitle: String
    let openWindowButton: String
    let sectionReceiving: String
    let destinationCaption: String
    let revealTitle: String
    let revealCaption: String
    let sectionSending: String
    let autoCopyTitle: String
    let autoCopyCaption: String
    let expiryTitle: String
    let expiryCaption: String
    let expiryNever: String
    let expiry1h: String
    let expiry8h: String
    let expiry24h: String
    let expiry7d: String
    let sectionAlerts: String
    let alertReceivedTitle: String
    let alertReceivedCaption: String
    let alertUploadTitle: String
    let alertUploadCaption: String
    let sectionSystem: String
    let menuBarTitle: String
    let menuBarCaption: String
    let keepAwakeTitle: String
    let keepAwakeCaption: String
    let sectionSecurity: String
    let connectionTitle: String
    let connectionAutomatic: String
    let connectionAutomaticCaption: String
    let connectionDirect: String
    let connectionDirectCaption: String
    let connectionCustom: String
    let connectionCustomCaption: String
    let relayPlaceholder: String
    let relayInvalid: String
    let hideAddressesTitle: String
    let hideAddressesCaption: String
    let securityNote: String

    func expiryLabel(minutes: Int) -> String {
        switch minutes {
        case 60: return expiry1h
        case 480: return expiry8h
        case 1_440: return expiry24h
        case 10_080: return expiry7d
        default: return expiryNever
        }
    }

    static func localized(_ language: AppLanguage) -> TransferStrings {
        switch language {
        case .ptBR: return portuguese
        case .it: return italian
        case .es: return spanish
        default: return english
        }
    }

    private static let english = TransferStrings(
        windowTitle: "File Transfer",
        footerButton: "Transfer",
        menuItem: "Transfer Files…",
        commandTitle: "Transfer Files",
        intro: "Straight from one computer to the other, end-to-end encrypted, with no cloud in between. Send the heavy stuff: an elephant can carry it.",
        compatibility: "Whoever receives needs Brastoo, on a Mac or on Windows.",
        shareHint: "Send the download link to whoever is receiving.",
        shareButton: "Share",
        copyMacLink: "Copy Link for Mac",
        copyWindowsLink: "Copy Link for Windows",
        copyBothLinks: "Copy Both Links",
        linkCopied: "Link Copied",
        bothLinksFormat: "Brastoo for Mac: %@\nBrastoo for Windows: %@",
        sendTitle: "Send",
        dropHint: "Drag a file or a folder here",
        chooseButton: "Choose…",
        preparing: "Preparing…",
        readyHint: "Send this code to whoever is receiving. Keep Brastoo open until their download finishes.",
        copyCode: "Copy Code",
        copied: "Copied",
        stop: "Stop",
        remove: "Remove",
        stopped: "No longer being sent",
        sendFailed: "This could not be prepared for sending.",
        receiveTitle: "Receive",
        codePlaceholder: "Paste the code you were sent",
        receiveButton: "Receive",
        destinationLabel: "Save to",
        changeButton: "Change…",
        connecting: "Connecting…",
        receiving: "Receiving…",
        receivedFormat: "%@ received",
        done: "Received",
        showInFinder: "Show in Finder",
        cancel: "Cancel",
        cancelled: "Cancelled",
        receiveFailed: "This could not be received.",
        alreadyExists: "The destination folder already has an item with this name. Remove it or choose another folder, then try again.",
        invalidCode: "That is not a valid code.",
        engineMissing: "This build does not include the transfer engine.",
        waiting: "Waiting for someone to download",
        uploadingToFormat: "Sending to %@",
        finishing: "Finishing…",
        ofFormat: "%@ of %@",
        remainingFormat: "%@ left",
        expiresFormat: "Code expires at %@",
        expired: "Code expired",
        summaryIdle: "Nothing is moving right now",
        settingsButton: "Settings…",
        notifyDoneTitle: "Download finished",
        notifyFailedTitle: "Download failed",
        notifyUploadTitle: "Someone is downloading",
        notifyUploadBodyFormat: "Another computer started downloading %@.",
        settingsTitle: "Transfers",
        openWindowButton: "Open File Transfer",
        sectionReceiving: "Receiving",
        destinationCaption: "Where received files and folders are saved.",
        revealTitle: "Show in Finder when done",
        revealCaption: "Opens the folder with the received item selected.",
        sectionSending: "Sending",
        autoCopyTitle: "Copy the code automatically",
        autoCopyCaption: "As soon as a code is ready it goes to the clipboard.",
        expiryTitle: "Code expires after",
        expiryCaption: "When the time is up the code stops working and the content is no longer offered.",
        expiryNever: "Never",
        expiry1h: "1 hour",
        expiry8h: "8 hours",
        expiry24h: "24 hours",
        expiry7d: "7 days",
        sectionAlerts: "Notifications",
        alertReceivedTitle: "When a download finishes or fails",
        alertReceivedCaption: "A notification for each item you receive.",
        alertUploadTitle: "When someone starts downloading",
        alertUploadCaption: "Tells you the moment a code of yours is used.",
        sectionSystem: "Menu bar and power",
        menuBarTitle: "Show status in the menu bar",
        menuBarCaption: "Speed and progress beside the elephant while something is moving. Click it for the details.",
        keepAwakeTitle: "Keep the Mac awake",
        keepAwakeCaption: "The Mac does not sleep while content is on offer or being received. The display can still turn off.",
        sectionSecurity: "Security and network",
        connectionTitle: "Connection",
        connectionAutomatic: "Automatic",
        connectionAutomaticCaption: "Direct whenever possible, with iroh's public relays as the fallback. The relay cannot read the content.",
        connectionDirect: "Direct only",
        connectionDirectCaption: "No relay at all. Works on the same network or when one side is reachable from the internet.",
        connectionCustom: "My own relay",
        connectionCustomCaption: "Uses the relay at the address below instead of the public ones. Both sides need it.",
        relayPlaceholder: "https://relay.example.com",
        relayInvalid: "Enter an https address. Until then the connection stays automatic.",
        hideAddressesTitle: "Keep IP addresses out of the code",
        hideAddressesCaption: "The code then carries only the relay address. Whoever holds it cannot read this Mac's IP addresses from it.",
        securityNote: "Every transfer is encrypted end to end between the two computers and checked block by block with BLAKE3. Nothing is stored on a server, and a code works only while Brastoo keeps offering the content."
    )

    private static let portuguese = TransferStrings(
        windowTitle: "Transferir arquivos",
        footerButton: "Transferir",
        menuItem: "Transferir arquivos…",
        commandTitle: "Transferir arquivos",
        intro: "Direto de um computador ao outro, com criptografia de ponta a ponta e sem nuvem no caminho. Pode mandar o que for pesado: elefante aguenta.",
        compatibility: "Quem vai receber precisa usar o Brastoo, no Mac ou no Windows.",
        shareHint: "Envie o link de download para quem vai receber.",
        shareButton: "Compartilhar",
        copyMacLink: "Copiar link para Mac",
        copyWindowsLink: "Copiar link para Windows",
        copyBothLinks: "Copiar os dois links",
        linkCopied: "Link copiado",
        bothLinksFormat: "Brastoo para Mac: %@\nBrastoo para Windows: %@",
        sendTitle: "Enviar",
        dropHint: "Arraste um arquivo ou uma pasta para cá",
        chooseButton: "Escolher…",
        preparing: "Preparando…",
        readyHint: "Mande este código para quem vai receber. Deixe o Brastoo aberto até o download terminar.",
        copyCode: "Copiar código",
        copied: "Copiado",
        stop: "Parar",
        remove: "Remover",
        stopped: "Envio encerrado",
        sendFailed: "Não foi possível preparar o envio.",
        receiveTitle: "Receber",
        codePlaceholder: "Cole aqui o código que você recebeu",
        receiveButton: "Receber",
        destinationLabel: "Salvar em",
        changeButton: "Alterar…",
        connecting: "Conectando…",
        receiving: "Recebendo…",
        receivedFormat: "%@ recebidos",
        done: "Recebido",
        showInFinder: "Mostrar no Finder",
        cancel: "Cancelar",
        cancelled: "Cancelado",
        receiveFailed: "Não foi possível receber.",
        alreadyExists: "A pasta de destino já tem um item com esse nome. Remova-o ou escolha outra pasta e tente de novo.",
        invalidCode: "Esse código não é válido.",
        engineMissing: "Este build não inclui o motor de transferência.",
        waiting: "Aguardando quem vai baixar",
        uploadingToFormat: "Enviando para %@",
        finishing: "Finalizando…",
        ofFormat: "%@ de %@",
        remainingFormat: "faltam %@",
        expiresFormat: "O código expira às %@",
        expired: "Código expirado",
        summaryIdle: "Nada em movimento agora",
        settingsButton: "Ajustes…",
        notifyDoneTitle: "Recebimento concluído",
        notifyFailedTitle: "Recebimento falhou",
        notifyUploadTitle: "Alguém está baixando",
        notifyUploadBodyFormat: "Outro computador começou a baixar %@.",
        settingsTitle: "Transferências",
        openWindowButton: "Abrir Transferir arquivos",
        sectionReceiving: "Recebimento",
        destinationCaption: "Onde os arquivos e pastas recebidos são salvos.",
        revealTitle: "Mostrar no Finder ao concluir",
        revealCaption: "Abre a pasta com o item recebido selecionado.",
        sectionSending: "Envio",
        autoCopyTitle: "Copiar o código automaticamente",
        autoCopyCaption: "Assim que o código fica pronto, ele vai para a área de transferência.",
        expiryTitle: "O código expira depois de",
        expiryCaption: "Passado o prazo, o código para de funcionar e o conteúdo deixa de ser oferecido.",
        expiryNever: "Nunca",
        expiry1h: "1 hora",
        expiry8h: "8 horas",
        expiry24h: "24 horas",
        expiry7d: "7 dias",
        sectionAlerts: "Notificações",
        alertReceivedTitle: "Quando um recebimento termina ou falha",
        alertReceivedCaption: "Uma notificação para cada item que você recebe.",
        alertUploadTitle: "Quando alguém começa a baixar",
        alertUploadCaption: "Avisa no momento em que um código seu é usado.",
        sectionSystem: "Barra de menus e energia",
        menuBarTitle: "Mostrar status na barra de menus",
        menuBarCaption: "Velocidade e progresso ao lado do elefante enquanto algo está em movimento. Clique para ver os detalhes.",
        keepAwakeTitle: "Manter o Mac acordado",
        keepAwakeCaption: "O Mac não entra em repouso enquanto houver conteúdo sendo oferecido ou recebido. A tela ainda pode apagar.",
        sectionSecurity: "Segurança e rede",
        connectionTitle: "Conexão",
        connectionAutomatic: "Automática",
        connectionAutomaticCaption: "Direta sempre que possível, com os relays públicos do iroh como alternativa. O relay não consegue ler o conteúdo.",
        connectionDirect: "Somente direta",
        connectionDirectCaption: "Sem relay nenhum. Funciona na mesma rede ou quando um dos lados é alcançável pela internet.",
        connectionCustom: "Meu próprio relay",
        connectionCustomCaption: "Usa o relay do endereço abaixo no lugar dos públicos. Os dois lados precisam dele.",
        relayPlaceholder: "https://relay.exemplo.com",
        relayInvalid: "Informe um endereço https. Enquanto isso, a conexão continua automática.",
        hideAddressesTitle: "Não incluir endereços IP no código",
        hideAddressesCaption: "O código passa a levar só o endereço do relay. Quem tiver o código não consegue ler nele os IPs deste Mac.",
        securityNote: "Toda transferência é criptografada de ponta a ponta entre os dois computadores e conferida bloco a bloco com BLAKE3. Nada fica guardado em servidor, e um código só funciona enquanto o Brastoo estiver oferecendo o conteúdo."
    )

    private static let italian = TransferStrings(
        windowTitle: "Trasferimento file",
        footerButton: "Trasferisci",
        menuItem: "Trasferisci file…",
        commandTitle: "Trasferisci file",
        intro: "Direttamente da un computer all’altro, con crittografia end-to-end e senza cloud di mezzo. Manda pure la roba pesante: un elefante ce la fa.",
        compatibility: "Chi riceve deve usare Brastoo, su Mac o su Windows.",
        shareHint: "Invia il link di download a chi deve ricevere.",
        shareButton: "Condividi",
        copyMacLink: "Copia link per Mac",
        copyWindowsLink: "Copia link per Windows",
        copyBothLinks: "Copia entrambi i link",
        linkCopied: "Link copiato",
        bothLinksFormat: "Brastoo per Mac: %@\nBrastoo per Windows: %@",
        sendTitle: "Invia",
        dropHint: "Trascina qui un file o una cartella",
        chooseButton: "Scegli…",
        preparing: "Preparazione…",
        readyHint: "Manda questo codice a chi deve ricevere. Lascia Brastoo aperto finché il download non è finito.",
        copyCode: "Copia codice",
        copied: "Copiato",
        stop: "Interrompi",
        remove: "Rimuovi",
        stopped: "Invio terminato",
        sendFailed: "Non è stato possibile preparare l’invio.",
        receiveTitle: "Ricevi",
        codePlaceholder: "Incolla qui il codice che hai ricevuto",
        receiveButton: "Ricevi",
        destinationLabel: "Salva in",
        changeButton: "Cambia…",
        connecting: "Connessione…",
        receiving: "Ricezione…",
        receivedFormat: "%@ ricevuti",
        done: "Ricevuto",
        showInFinder: "Mostra nel Finder",
        cancel: "Annulla",
        cancelled: "Annullato",
        receiveFailed: "Non è stato possibile ricevere.",
        alreadyExists: "La cartella di destinazione contiene già un elemento con questo nome. Rimuovilo o scegli un’altra cartella, poi riprova.",
        invalidCode: "Questo codice non è valido.",
        engineMissing: "Questa build non include il motore di trasferimento.",
        waiting: "In attesa di chi scarica",
        uploadingToFormat: "Invio a %@",
        finishing: "Completamento…",
        ofFormat: "%@ di %@",
        remainingFormat: "mancano %@",
        expiresFormat: "Il codice scade alle %@",
        expired: "Codice scaduto",
        summaryIdle: "Niente in movimento adesso",
        settingsButton: "Impostazioni…",
        notifyDoneTitle: "Ricezione completata",
        notifyFailedTitle: "Ricezione non riuscita",
        notifyUploadTitle: "Qualcuno sta scaricando",
        notifyUploadBodyFormat: "Un altro computer ha iniziato a scaricare %@.",
        settingsTitle: "Trasferimenti",
        openWindowButton: "Apri Trasferimento file",
        sectionReceiving: "Ricezione",
        destinationCaption: "Dove vengono salvati i file e le cartelle ricevuti.",
        revealTitle: "Mostra nel Finder al termine",
        revealCaption: "Apre la cartella con l’elemento ricevuto selezionato.",
        sectionSending: "Invio",
        autoCopyTitle: "Copia il codice automaticamente",
        autoCopyCaption: "Appena il codice è pronto finisce negli appunti.",
        expiryTitle: "Il codice scade dopo",
        expiryCaption: "Scaduto il tempo, il codice smette di funzionare e il contenuto non viene più offerto.",
        expiryNever: "Mai",
        expiry1h: "1 ora",
        expiry8h: "8 ore",
        expiry24h: "24 ore",
        expiry7d: "7 giorni",
        sectionAlerts: "Notifiche",
        alertReceivedTitle: "Quando una ricezione finisce o non riesce",
        alertReceivedCaption: "Una notifica per ogni elemento che ricevi.",
        alertUploadTitle: "Quando qualcuno inizia a scaricare",
        alertUploadCaption: "Ti avvisa nel momento in cui un tuo codice viene usato.",
        sectionSystem: "Barra dei menu ed energia",
        menuBarTitle: "Mostra lo stato nella barra dei menu",
        menuBarCaption: "Velocità e avanzamento accanto all’elefante mentre qualcosa è in movimento. Fai clic per i dettagli.",
        keepAwakeTitle: "Tieni attivo il Mac",
        keepAwakeCaption: "Il Mac non va in stop finché c’è contenuto offerto o in ricezione. Lo schermo può comunque spegnersi.",
        sectionSecurity: "Sicurezza e rete",
        connectionTitle: "Connessione",
        connectionAutomatic: "Automatica",
        connectionAutomaticCaption: "Diretta quando possibile, con i relay pubblici di iroh come alternativa. Il relay non può leggere il contenuto.",
        connectionDirect: "Solo diretta",
        connectionDirectCaption: "Nessun relay. Funziona sulla stessa rete o quando uno dei due è raggiungibile da internet.",
        connectionCustom: "Il mio relay",
        connectionCustomCaption: "Usa il relay all’indirizzo qui sotto al posto di quelli pubblici. Serve a entrambi i lati.",
        relayPlaceholder: "https://relay.esempio.com",
        relayInvalid: "Inserisci un indirizzo https. Nel frattempo la connessione resta automatica.",
        hideAddressesTitle: "Non includere gli indirizzi IP nel codice",
        hideAddressesCaption: "Il codice porta solo l’indirizzo del relay. Chi lo possiede non può leggervi gli IP di questo Mac.",
        securityNote: "Ogni trasferimento è cifrato end-to-end tra i due computer e verificato blocco per blocco con BLAKE3. Niente resta su un server, e un codice funziona solo finché Brastoo offre il contenuto."
    )

    private static let spanish = TransferStrings(
        windowTitle: "Transferir archivos",
        footerButton: "Transferir",
        menuItem: "Transferir archivos…",
        commandTitle: "Transferir archivos",
        intro: "Directo de un ordenador a otro, con cifrado de extremo a extremo y sin nube de por medio. Manda lo que pese: un elefante puede con ello.",
        compatibility: "Quien recibe necesita usar Brastoo, en Mac o en Windows.",
        shareHint: "Envía el enlace de descarga a quien va a recibir.",
        shareButton: "Compartir",
        copyMacLink: "Copiar enlace para Mac",
        copyWindowsLink: "Copiar enlace para Windows",
        copyBothLinks: "Copiar los dos enlaces",
        linkCopied: "Enlace copiado",
        bothLinksFormat: "Brastoo para Mac: %@\nBrastoo para Windows: %@",
        sendTitle: "Enviar",
        dropHint: "Arrastra aquí un archivo o una carpeta",
        chooseButton: "Elegir…",
        preparing: "Preparando…",
        readyHint: "Manda este código a quien va a recibir. Deja Brastoo abierto hasta que termine la descarga.",
        copyCode: "Copiar código",
        copied: "Copiado",
        stop: "Detener",
        remove: "Quitar",
        stopped: "Envío finalizado",
        sendFailed: "No se pudo preparar el envío.",
        receiveTitle: "Recibir",
        codePlaceholder: "Pega aquí el código que recibiste",
        receiveButton: "Recibir",
        destinationLabel: "Guardar en",
        changeButton: "Cambiar…",
        connecting: "Conectando…",
        receiving: "Recibiendo…",
        receivedFormat: "%@ recibidos",
        done: "Recibido",
        showInFinder: "Mostrar en el Finder",
        cancel: "Cancelar",
        cancelled: "Cancelado",
        receiveFailed: "No se pudo recibir.",
        alreadyExists: "La carpeta de destino ya tiene un elemento con este nombre. Quítalo o elige otra carpeta y vuelve a intentarlo.",
        invalidCode: "Ese código no es válido.",
        engineMissing: "Esta compilación no incluye el motor de transferencia.",
        waiting: "Esperando a quien va a descargar",
        uploadingToFormat: "Enviando a %@",
        finishing: "Finalizando…",
        ofFormat: "%@ de %@",
        remainingFormat: "faltan %@",
        expiresFormat: "El código caduca a las %@",
        expired: "Código caducado",
        summaryIdle: "Nada en movimiento ahora",
        settingsButton: "Ajustes…",
        notifyDoneTitle: "Recepción completada",
        notifyFailedTitle: "La recepción falló",
        notifyUploadTitle: "Alguien está descargando",
        notifyUploadBodyFormat: "Otro ordenador ha empezado a descargar %@.",
        settingsTitle: "Transferencias",
        openWindowButton: "Abrir Transferir archivos",
        sectionReceiving: "Recepción",
        destinationCaption: "Dónde se guardan los archivos y carpetas recibidos.",
        revealTitle: "Mostrar en el Finder al terminar",
        revealCaption: "Abre la carpeta con el elemento recibido seleccionado.",
        sectionSending: "Envío",
        autoCopyTitle: "Copiar el código automáticamente",
        autoCopyCaption: "En cuanto el código está listo pasa al portapapeles.",
        expiryTitle: "El código caduca después de",
        expiryCaption: "Pasado el plazo, el código deja de funcionar y el contenido ya no se ofrece.",
        expiryNever: "Nunca",
        expiry1h: "1 hora",
        expiry8h: "8 horas",
        expiry24h: "24 horas",
        expiry7d: "7 días",
        sectionAlerts: "Notificaciones",
        alertReceivedTitle: "Cuando una recepción termina o falla",
        alertReceivedCaption: "Una notificación por cada elemento que recibes.",
        alertUploadTitle: "Cuando alguien empieza a descargar",
        alertUploadCaption: "Te avisa en el momento en que se usa un código tuyo.",
        sectionSystem: "Barra de menús y energía",
        menuBarTitle: "Mostrar el estado en la barra de menús",
        menuBarCaption: "Velocidad y progreso junto al elefante mientras algo está en movimiento. Haz clic para ver los detalles.",
        keepAwakeTitle: "Mantener el Mac activo",
        keepAwakeCaption: "El Mac no entra en reposo mientras haya contenido ofrecido o en recepción. La pantalla puede apagarse igual.",
        sectionSecurity: "Seguridad y red",
        connectionTitle: "Conexión",
        connectionAutomatic: "Automática",
        connectionAutomaticCaption: "Directa siempre que se pueda, con los relays públicos de iroh como alternativa. El relay no puede leer el contenido.",
        connectionDirect: "Solo directa",
        connectionDirectCaption: "Sin ningún relay. Funciona en la misma red o cuando uno de los lados es accesible desde internet.",
        connectionCustom: "Mi propio relay",
        connectionCustomCaption: "Usa el relay de la dirección de abajo en lugar de los públicos. Lo necesitan los dos lados.",
        relayPlaceholder: "https://relay.ejemplo.com",
        relayInvalid: "Escribe una dirección https. Mientras tanto la conexión sigue en automática.",
        hideAddressesTitle: "No incluir direcciones IP en el código",
        hideAddressesCaption: "El código lleva solo la dirección del relay. Quien lo tenga no puede leer en él las IP de este Mac.",
        securityNote: "Cada transferencia va cifrada de extremo a extremo entre los dos ordenadores y se comprueba bloque a bloque con BLAKE3. Nada queda en un servidor, y un código solo funciona mientras Brastoo ofrece el contenido."
    )
}
