// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Vorssaint

import AppKit
import CoreGraphics
import Foundation

struct SwitcherScrollNavigation {
    static let gestureStep: Double = 30
    private var accumulated: Double = 0
    private var lastTimestamp: CGEventTimestamp?
    private var lastGesturePhaseTimestamp: CGEventTimestamp?
    private var wasMouseWheel: Bool?

    mutating func selectionDelta(for event: CGEvent) -> Int {
        guard event.getIntegerValueField(.eventSourceUserData) != ScrollWheelSupport.syntheticTag else {
            return 0
        }
        let traits = ScrollWheelEventTraits(
            isContinuous: event.getIntegerValueField(.scrollWheelEventIsContinuous) != 0,
            momentumPhase: event.getIntegerValueField(.scrollWheelEventMomentumPhase),
            scrollPhase: event.getIntegerValueField(.scrollWheelEventScrollPhase),
            scrollCount: event.getIntegerValueField(.scrollWheelEventScrollCount)
        )
        let phase = CGScrollPhase(rawValue: UInt32(truncatingIfNeeded: traits.scrollPhase))
        let isMouseWheel = ScrollWheelSupport.isMouseWheel(traits, secondsSinceLastGesturePhase:
            lastGesturePhaseTimestamp.map { Double(event.timestamp &- $0) / 1_000_000_000 })
        if traits.scrollPhase != 0 || traits.momentumPhase != 0 {
            lastGesturePhaseTimestamp = event.timestamp
        }
        // Wheel fractions survive pauses; only touch gestures have an idle timeout.
        if wasMouseWheel != isMouseWheel || phase == .began
            || (!isMouseWheel && lastTimestamp.map({ event.timestamp &- $0 > 250_000_000 }) == true) {
            accumulated = 0
        }
        wasMouseWheel = isMouseWheel
        lastTimestamp = event.timestamp
        guard traits.momentumPhase == 0,
              phase != .ended, phase != .cancelled else {
            accumulated = 0
            return 0
        }
        func movement(line: CGEventField, fixed: CGEventField, point: CGEventField) -> Double {
            guard isMouseWheel else { return event.getDoubleValueField(point) }
            let lines = event.getDoubleValueField(line)
            if lines != 0 { return lines }
            let fraction = event.getDoubleValueField(fixed)
            if fraction != 0 { return fraction }
            return traits.isContinuous ? event.getDoubleValueField(point) / ScrollWheelSupport.pointsPerLine : 0
        }
        let vertical = movement(line: .scrollWheelEventDeltaAxis1, fixed: .scrollWheelEventFixedPtDeltaAxis1,
                                point: .scrollWheelEventPointDeltaAxis1)
        let horizontal = movement(line: .scrollWheelEventDeltaAxis2, fixed: .scrollWheelEventFixedPtDeltaAxis2,
                                  point: .scrollWheelEventPointDeltaAxis2)
        let delta = abs(horizontal) > abs(vertical) ? horizontal : vertical
        guard delta.isFinite, delta != 0 else { return 0 }
        if accumulated * delta < 0 { accumulated = 0 }
        accumulated += delta
        let step = isMouseWheel ? 1 : Self.gestureStep
        guard abs(accumulated) >= step else { return 0 }
        // Each sample advances at most one item, without acceleration or momentum.
        accumulated = isMouseWheel ? accumulated.truncatingRemainder(dividingBy: step) : 0
        return delta < 0 ? 1 : -1
    }
}

struct SwitcherCloseState: Equatable {
    let remainingItemIDs: [String]
    let selectedIndex: Int
    let didRemove: Bool
    let shouldEndSession: Bool
}

struct SwitcherActivationPlan: Equatable {
    let activateAllWindows: Bool
    let makeAppFrontmostAfterActivation: Bool
    let restoreSourceWhenTargetMinimizes: Bool
}

/// How the owning app is brought forward. App-level activation can raise
/// sibling windows even without activateAllWindows, so a plan
/// scoped to one window asks the window server to front that window alone.
enum SwitcherAppActivationRoute: Equatable {
    case exactWindow(CGWindowID)
    case wholeApp
}

/// Shared by the bounded focus passes on the main thread. Once a pass sees
/// a newer user action, the remaining passes cannot reclaim the old target.
final class SwitcherWindowFocusRetryState {
    let targetStartedMinimized: Bool
    let knownWindowIDs: Set<CGWindowID>
    private(set) var targetWasObservedRestored: Bool
    private(set) var isActive = true

    init(targetWindowID: CGWindowID, targetStartedMinimized: Bool, knownWindowIDs: Set<CGWindowID>) {
        self.targetStartedMinimized = targetStartedMinimized
        // The selected target is already known even if the server's snapshot
        // missed it. An entirely unavailable snapshot still stays unavailable.
        self.knownWindowIDs = knownWindowIDs.isEmpty ? [] : knownWindowIDs.union([targetWindowID])
        self.targetWasObservedRestored = !targetStartedMinimized
    }

    func observe(targetMinimizedState: Bool?) {
        if targetMinimizedState == false {
            targetWasObservedRestored = true
        }
    }

    func shouldContinue(targetPID: pid_t,
                        sourcePID: pid_t?,
                        frontmostPID: @autoclosure () -> pid_t?,
                        targetMinimizedState: Bool?,
                        targetAppWindowIDs: @autoclosure () -> Set<CGWindowID>,
                        targetAppFocusedWindowID: @autoclosure () -> CGWindowID?,
                        targetWindowIsFocused: @autoclosure () -> Bool = false,
                        stopsWhenTargetFocused: Bool = false,
                        ignoresForeground: Bool = false,
                        ownPID: pid_t = ProcessInfo.processInfo.processIdentifier) -> Bool {
        guard isActive else { return false }
        let observedFrontmostPID = frontmostPID()
        if stopsWhenTargetFocused,
           !ignoresForeground,
           !targetStartedMinimized,
           observedFrontmostPID == targetPID,
           targetWindowIsFocused() {
            isActive = false
            return false
        }
        isActive = SwitcherSupport.shouldContinueFocusRetry(
            targetPID: targetPID,
            sourcePID: sourcePID,
            frontmostPID: frontmostPID(),
            targetIsMinimized: targetMinimizedState == true,
            targetStartedMinimized: targetStartedMinimized,
            targetWasObservedRestored: targetWasObservedRestored,
            knownWindowIDs: knownWindowIDs,
            targetAppWindowIDs: targetAppWindowIDs(),
            targetAppFocusedWindowID: targetAppFocusedWindowID(),
            ignoresForeground: ignoresForeground,
            ownPID: ownPID
        )
        observe(targetMinimizedState: targetMinimizedState)
        return isActive
    }
}

struct SwitcherSearchRecord: Equatable {
    let id: String
    let title: String
    let appName: String
}

/// What a letter typed with the panel open does. Anything else goes to search.
enum SwitcherLetterAction: Equatable {
    case closeWindow
    case quitApp
    case pinSearch
}

/// Whether a switcher session lists every app or only the frontmost app's windows.
enum SwitcherSessionScope: Equatable {
    case allApps
    case frontmostApp
}

/// How a key arriving before the asynchronous window list is ready is owned.
enum SwitcherPendingKeyDecision: Equatable {
    case handleActiveSession
    case routeShortcut
    case swallow
    case cancelAndSwallow
}

/// WindowServer identifiers for the app and window switcher actions. Read
/// them from the table, not from memory: 28 is "save picture of screen as a
/// file", and mapping the reverse window key there once let a switcher
/// shortcut on the 3 key switch the macOS screenshot key off.
enum SwitcherNativeSymbolicHotKey: Int32, CaseIterable, Hashable {
    case commandTab = 1
    case commandShiftTab = 2
    case nextWindow = 27
    case previousWindow = 220

    /// The ids the switcher ever asks the WindowServer about.
    static let ids = Set(allCases.map(\.rawValue))
}

/// Which running apps earn an entry of their own when they have no window the
/// switcher can show. The switcher lists windows, so an app that closed all of
/// them disappears from it while the system switcher still offers it.
enum SwitcherWindowlessApps: String, CaseIterable, Equatable {
    /// Windows only.
    case off
    /// The desktop app alone, which is always running and often has no window.
    case finder
    /// Every running app, the way the system switcher lists them.
    case all

    static let fallback = SwitcherWindowlessApps.finder

    /// Preferences are stored as plain strings, so an unknown or missing value
    /// resolves to the behavior the app shipped with instead of nothing.
    static func mode(storedValue: String?,
                     takeOverSystemShortcuts: Bool) -> SwitcherWindowlessApps {
        if takeOverSystemShortcuts { return .all }
        guard let storedValue, let mode = SwitcherWindowlessApps(rawValue: storedValue) else {
            return fallback
        }
        return mode
    }

    /// The value that carries the old on/off preference over unchanged: the
    /// desktop app kept its entry, anything else stayed windows only.
    static func migrated(showsWindowlessFinder: Bool) -> SwitcherWindowlessApps {
        showsWindowlessFinder ? .finder : .off
    }
}

/// Which display the switcher panel opens on. The pointer's screen is what
/// the app always did; the other two are the choices people arrive expecting
/// from the switchers they used before, and the menu bar one is the only way
/// to keep the panel on a fixed display when the pointer roams.
enum SwitcherScreenPlacement: String, CaseIterable, Equatable {
    /// The screen under the mouse pointer.
    case pointer
    /// The screen with the menu bar, the primary display in Displays settings.
    case menuBar
    /// The screen showing the window that was in front when the session began.
    case activeWindow

    static let fallback = SwitcherScreenPlacement.pointer

    /// Preferences are stored as plain strings, so an unknown or missing value
    /// resolves to the behavior the app shipped with instead of nothing.
    static func placement(storedValue: String?) -> SwitcherScreenPlacement {
        guard let storedValue, let placement = SwitcherScreenPlacement(rawValue: storedValue) else {
            return fallback
        }
        return placement
    }
}

/// A per-app override for the switcher's regular window and windowless-app
/// choices. Apps without an override keep following `SwitcherWindowlessApps`.
enum SwitcherAppRule: String, CaseIterable, Equatable {
    case showWithoutWindows
    case windowsOnly
    case hidden

    static func rules(storedValue: [String: Any]?) -> [String: SwitcherAppRule] {
        guard let storedValue else { return [:] }
        var rules: [String: SwitcherAppRule] = [:]
        for rawBundleID in storedValue.keys.sorted() {
            let bundleID = rawBundleID.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !bundleID.isEmpty,
                  let rawRule = storedValue[rawBundleID] as? String,
                  let rule = SwitcherAppRule(rawValue: rawRule)
            else { continue }
            rules[bundleID] = rule
        }
        return rules
    }

    static func storedValue(_ rules: [String: SwitcherAppRule]) -> [String: String] {
        var stored: [String: String] = [:]
        for (rawBundleID, rule) in rules {
            let bundleID = rawBundleID.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !bundleID.isEmpty else { continue }
            stored[bundleID] = rule.rawValue
        }
        return stored
    }
}

/// A running app considered for an entry of its own, with the identity the
/// choice above is decided on.
struct SwitcherAppCandidate: Equatable {
    let pid: pid_t
    let bundleIdentifier: String?
}

struct SwitcherAppGroup: Identifiable, Equatable {
    let pid: pid_t
    let appName: String
    let representativeIndex: Int
    let itemIDs: [String]

    var id: pid_t { pid }
    var windowCount: Int { itemIDs.count }
}

/// What one App Switcher grid card is made of.
///
/// The card scales with the preview size; its chrome does not, because the
/// chrome is two lines of text that are the same at every size. The thumbnail
/// takes whatever is left, derived from the parts rather than from one number
/// standing in for them — the number it used to be had drifted 16pt past what
/// it stood for, and the card spent the difference on nothing.
enum SwitcherGridCard {
    static var width: CGFloat { 288 * PreviewSizing.switcherScale }
    static var height: CGFloat { 214 * PreviewSizing.switcherScale }
    static let padding: CGFloat = 10
    static let titleSpacing: CGFloat = 7
    /// One 13pt line over one 10.5pt line, 2pt apart, descenders included.
    static let titleHeight: CGFloat = 31
    static var thumbnailWidth: CGFloat { width - padding * 2 }
    static var thumbnailHeight: CGFloat { height - padding * 2 - titleSpacing - titleHeight }
    /// The title band sits inside the thumbnail's width so a long name stops
    /// short of the card's rounded corners.
    static var titleWidth: CGFloat { thumbnailWidth - 8 }
    /// Stands in for a thumbnail that has not arrived, so it has to stay
    /// inside the thumbnail at every preview size (#793 gave it the scale;
    /// naming it is what lets a test hold it to the thumbnail it sits in).
    static var fallbackIconSize: CGFloat { 80 * PreviewSizing.switcherScale }
}

struct SwitcherIconRowLayout: Equatable {
    let visibleIconCount: Int
    let appRowContentWidth: CGFloat
    let appRowSurfaceWidth: CGFloat
    let previewContentWidth: CGFloat
    let previewSurfaceWidth: CGFloat
    let simpleTitleSurfaceWidth: CGFloat
    let panelSize: CGSize
    let showsShortcutHints: Bool

    static var scale: CGFloat { min(PreviewSizing.switcherScale, 1.15) }
    static var iconSize: CGFloat { 68 * scale }
    static var selectedIconSize: CGFloat { 78 * scale }
    static let iconTileSpacing: CGFloat = 5
    static let iconTitleHeight: CGFloat = 14
    static let iconTileVerticalPadding: CGFloat = 5
    static let iconTileVerticalMargin: CGFloat = 3
    static var iconLabelWidth: CGFloat { max(selectedIconSize + 12, 86 * scale) }
    /// Text and padding stay legible instead of shrinking with preview size, so
    /// the row follows the tile's real height and never clips its selection.
    static var rowHeight: CGFloat {
        selectedIconSize + iconTileSpacing + iconTitleHeight
            + 2 * (iconTileVerticalPadding + iconTileVerticalMargin)
    }
    static var appTileWidth: CGFloat { iconLabelWidth + 12 }
    static var windowLabelWidth: CGFloat { 120 * scale }
    static var windowTileWidth: CGFloat { windowLabelWidth + 12 }
    static var previewCardWidth: CGFloat { 220 * scale }
    static var previewCardHeight: CGFloat { 164 * scale }
    static var appEntryIconSize: CGFloat { 66 * scale }
    static var previewHeight: CGFloat { previewCardHeight + 76 * scale }
    static var hintHeight: CGFloat { 28 * scale }
    static var hintGap: CGFloat { 8 * scale }
    static var hintBarWidth: CGFloat { 300 * scale }
    static var rowHorizontalPadding: CGFloat { 8 * scale }
    static var previewPanelPadding: CGFloat { 12 * scale }
    static var padding: CGFloat { 20 * scale }
    static var spacing: CGFloat { 12 * scale }
    static var previewGap: CGFloat { 10 * scale }
    static var simpleTitleHeight: CGFloat { 66 * scale }
    static var simpleTitleGap: CGFloat { 10 * scale }
    static var simpleTitleChipMaxWidth: CGFloat { 180 * scale }
    static var simpleTitlePanelPadding: CGFloat { 10 * scale }
    static let simpleTitleSpacing: CGFloat = 6
    static let simpleTitleScrollPadding: CGFloat = 1

    /// The width `cardCount` preview cards lay out to, including the spacing
    /// the row puts between them. The preview viewport is sized from this and
    /// decides whether it has anything to scroll from it, so the two can never
    /// disagree about what fits.
    static func naturalPreviewWidth(cardCount: Int) -> CGFloat {
        let count = max(0, cardCount)
        return CGFloat(count) * previewCardWidth + CGFloat(max(0, count - 1)) * spacing
    }

    /// Whether every preview card is on screen at once, so the scroll view has
    /// nothing to scroll to.
    func previewFitsWithoutScrolling(cardCount: Int) -> Bool {
        Self.naturalPreviewWidth(cardCount: cardCount) <= previewContentWidth
    }

    /// The widest row the panel has to hold. Panel sizing and the rows
    /// themselves both measure against this one value, so a row can never come
    /// out wider than the window drawing it and get clipped (issues #710, #730).
    func contentWidth(simpleMode: Bool, windowRow: Bool) -> CGFloat {
        let hintWidth = showsShortcutHints ? Self.hintBarWidth : 0
        guard simpleMode else {
            return max(0, panelSize.width - Self.padding * 2)
        }
        return max(appRowSurfaceWidth,
                   windowRow ? 0 : simpleTitleSurfaceWidth,
                   hintWidth)
    }

    /// App-only mode keeps the same icon row and shortcut preference, but
    /// removes the entire preview area so no blank space remains where captures were.
    var simplePanelSize: CGSize {
        CGSize(width: contentWidth(simpleMode: true, windowRow: false) + Self.padding * 2,
               height: Self.simpleTitleHeight + Self.simpleTitleGap
                        + Self.rowHeight + shortcutHintHeight
                        + Self.padding * 2)
    }

    /// A flat window row names every entry under its icon, so it needs no
    /// separate title strip above the row.
    var simpleWindowPanelSize: CGSize {
        CGSize(width: contentWidth(simpleMode: true, windowRow: true) + Self.padding * 2,
               height: Self.rowHeight + shortcutHintHeight + Self.padding * 2)
    }

    private var shortcutHintHeight: CGFloat {
        showsShortcutHints ? Self.hintGap + Self.hintHeight : 0
    }

    static let empty = SwitcherIconRowLayout(visibleIconCount: 1,
                                             appRowContentWidth: 0,
                                             appRowSurfaceWidth: 0,
                                             previewContentWidth: 0,
                                             previewSurfaceWidth: 0,
                                             simpleTitleSurfaceWidth: 0,
                                             panelSize: .zero,
                                             showsShortcutHints: true)

    static func compute(appCount rawAppCount: Int,
                        selectedWindowCount rawWindowCount: Int,
                        maximumWindowCount: Int = 1,
                        sessionScope: SwitcherSessionScope = .allApps,
                        screenVisibleFrame: CGRect,
                        showsShortcutHints: Bool = true,
                        tileWidth: CGFloat = appTileWidth) -> SwitcherIconRowLayout {
        let appCount = max(1, rawAppCount)
        let windowCount = max(1, rawWindowCount)
        let usableWidth = max(320, screenVisibleFrame.width * 0.96)
        let maxContentWidth = max(tileWidth, usableWidth - padding * 2)
        let naturalAppRowWidth = CGFloat(appCount) * tileWidth + CGFloat(max(0, appCount - 1)) * spacing
        let naturalPreviewWidth = Self.naturalPreviewWidth(cardCount: windowCount)
        let maxAppContentWidth = max(tileWidth, maxContentWidth - rowHorizontalPadding * 2)
        let maxPreviewContentWidth = max(previewCardWidth, maxContentWidth - previewPanelPadding * 2)
        let appRowWidth = min(naturalAppRowWidth, maxAppContentWidth)
        let appRowSurfaceWidth = min(appRowWidth + rowHorizontalPadding * 2, maxContentWidth)
        // Reserve room for a pair whenever any app has multiple windows. Use
        // the whole list so selecting another app never moves the icon row.
        // A focused-app session has no other apps to keep stationary; let
        // its windows fill the available display before scrolling.
        let reservedCardCount = sessionScope == .frontmostApp
            ? max(windowCount, maximumWindowCount)
            : min(2, max(windowCount, maximumWindowCount))
        let previewCeiling = min(maxPreviewContentWidth,
                                 max(Self.naturalPreviewWidth(cardCount: reservedCardCount),
                                     appRowSurfaceWidth - previewPanelPadding * 2))
        let previewWidth = min(naturalPreviewWidth, previewCeiling)
        let previewSurfaceWidth = min(previewWidth + previewPanelPadding * 2, maxContentWidth)
        let naturalSimpleTitleWidth = CGFloat(windowCount) * simpleTitleChipMaxWidth
            + CGFloat(max(0, windowCount - 1)) * simpleTitleSpacing
            + simpleTitleScrollPadding * 2
            + simpleTitlePanelPadding * 2
        let simpleTitleSurfaceWidth = min(naturalSimpleTitleWidth, maxContentWidth)
        let hintWidth = showsShortcutHints ? min(hintBarWidth, maxContentWidth) : 0
        let contentWidth = min(max(appRowSurfaceWidth,
                                   previewCeiling + previewPanelPadding * 2,
                                   hintWidth), maxContentWidth)
        let visibleIconCount = max(1, min(appCount, Int((maxAppContentWidth + spacing) / (tileWidth + spacing))))
        let width = contentWidth + padding * 2
        let shortcutHintHeight = showsShortcutHints ? hintGap + hintHeight : 0
        let height = previewHeight + previewGap + rowHeight + shortcutHintHeight + padding * 2
        return SwitcherIconRowLayout(visibleIconCount: visibleIconCount,
                                     appRowContentWidth: appRowWidth,
                                     appRowSurfaceWidth: appRowSurfaceWidth,
                                     previewContentWidth: previewWidth,
                                     previewSurfaceWidth: previewSurfaceWidth,
                                     simpleTitleSurfaceWidth: simpleTitleSurfaceWidth,
                                     panelSize: CGSize(width: width, height: height),
                                     showsShortcutHints: showsShortcutHints)
    }

    static func compute(count rawCount: Int, screenVisibleFrame: CGRect) -> SwitcherIconRowLayout {
        compute(appCount: rawCount, selectedWindowCount: 1, screenVisibleFrame: screenVisibleFrame)
    }
}

struct SwitcherIconRowPreviewPlacement: Equatable {
    let contentWidth: CGFloat
    let leading: CGFloat
}

struct SwitcherShortcutHints: Equatable {
    let apps: String
    let windows: String
}

enum SwitcherSupport {
    /// How long the shortcut must be held before the panel appears. A quick
    /// press can still switch directly without flashing the panel, while zero
    /// gives users who prefer immediate visual feedback an instant surface.
    static let defaultAppearanceDelayMilliseconds = 100
    static let appearanceDelayMillisecondsRange: ClosedRange<Int> = 0 ... 500

    static func sanitizedAppearanceDelay(milliseconds: Int) -> Int {
        min(max(milliseconds, appearanceDelayMillisecondsRange.lowerBound),
            appearanceDelayMillisecondsRange.upperBound)
    }

    static func appearanceDelay(milliseconds: Int) -> TimeInterval {
        TimeInterval(sanitizedAppearanceDelay(milliseconds: milliseconds)) / 1000
    }

    /// How wide a window's name is in the font a card draws it in. Measured
    /// against the font rather than a layout pass, so a card can decide whether
    /// to scroll the name before the band has ever been on screen -- and a test
    /// can ask the same question without one.
    static func titleWidth(_ title: String,
                           fontSize: CGFloat = 13,
                           weight: NSFont.Weight = .regular) -> CGFloat {
        guard !title.isEmpty else { return 0 }
        let font = NSFont.systemFont(ofSize: fontSize, weight: weight)
        return (title as NSString).size(withAttributes: [.font: font]).width
    }

    static func titleOverflows(_ title: String,
                               width: CGFloat,
                               fontSize: CGFloat = 13,
                               weight: NSFont.Weight = .regular) -> Bool {
        guard width > 0 else { return false }
        return titleWidth(title, fontSize: fontSize, weight: weight) > width
    }

    /// Grid resolution used to classify window captures.
    static let captureAlphaGridSize = 8

    /// How long the pointer must stay on the last visible icon before the
    /// overflow row reveals the next one. Long enough that crossing the
    /// edge does not start a scroll, short enough that a parked pointer
    /// does not feel stuck.
    static let iconRowEdgeHoverInterval: TimeInterval = 0.24

    /// Cadence for later one-icon steps while the pointer stays parked.
    /// Kept just above the slide so the next icon appears as soon as the
    /// previous one has settled.
    static let iconRowEdgeHoverRepeatInterval: TimeInterval = 0.20

    /// Duration of the one-icon slide. Slightly slower than the previous
    /// 0.15s center jump so the newly revealed icon can still be aimed at.
    static let iconRowEdgeHoverAnimationDuration: TimeInterval = 0.18

    static func firstValuesByPID<Value>(_ pairs: [(pid_t, Value)]) -> [pid_t: Value] {
        Dictionary(pairs, uniquingKeysWith: { first, _ in first })
    }

    static func usesIconRowLayout(iconRowMode: Bool, simpleMode: Bool) -> Bool {
        iconRowMode || simpleMode
    }

    static func capturesPreviews(simpleMode: Bool) -> Bool {
        !simpleMode
    }

    /// The simple switcher follows the existing one-entry-per-app choice.
    /// With grouping off or a window-scoped session, its row represents windows directly.
    static func usesWindowRow(simpleMode: Bool,
                              mergeWindowsByApp: Bool,
                              sessionScope: SwitcherSessionScope) -> Bool {
        simpleMode && (!mergeWindowsByApp || sessionScope == .frontmostApp)
    }

    static func usesAppGroupsForMainShortcut(iconRowLayout: Bool,
                                              windowRow: Bool) -> Bool {
        iconRowLayout && !windowRow
    }

    /// The grouped simple row still needs every backing window for its title
    /// chips and window shortcut, while its visible app cap remains grouped.
    static func preservesGroupedWindowsDuringEnumeration(allApps: Bool,
                                                         mergeWindowsByApp: Bool,
                                                         simpleMode: Bool) -> Bool {
        allApps && mergeWindowsByApp && simpleMode
    }

    /// Expands only the app representatives that survived the grouped cap.
    /// Keeping each representative first preserves the legacy app order and
    /// activation target; its remaining windows follow in MRU order.
    static func expandGroupedWindows(orderedWindows: [SwitcherItem],
                                     representatives: [SwitcherItem]) -> [SwitcherItem] {
        let windowsByPID = Dictionary(grouping: orderedWindows, by: \.pid)
        return representatives.flatMap { representative in
            [representative] + (windowsByPID[representative.pid] ?? []).filter {
                $0.id != representative.id
            }
        }
    }

    static func shouldPausePreviewCapture(frontmostBundleIdentifier: String?,
                                          excludedBundleIdentifiers: [String]) -> Bool {
        guard let frontmostBundleIdentifier else { return false }
        return excludedBundleIdentifiers.contains(frontmostBundleIdentifier)
    }

    static func needsScreenRecording(switcherEnabled: Bool,
                                     simpleMode: Bool,
                                     dockPreviewEnabled: Bool) -> Bool {
        dockPreviewEnabled || (switcherEnabled && capturesPreviews(simpleMode: simpleMode))
    }

    /// Resolves the foreground surface a session is measured against: the
    /// window the user is looking at right now. It can legitimately not exist
    /// (the app in front was left with no windows, or all of them are
    /// minimized or parked on another Space), and nil says exactly that
    /// instead of mistaking an older off-screen window for the source. The
    /// session opens either way; `initialSelectionPosition` handles the
    /// sourceless case.
    static func sessionSourceItem(frontmostPID: pid_t?,
                                  focusedWindowID: CGWindowID?,
                                  items: [SwitcherItem]) -> SwitcherItem? {
        guard let frontmostPID else { return nil }
        let appPID = appPID(forFrontmost: frontmostPID, items: items)
        let candidates = items.filter { $0.pid == appPID }
        if let focusedWindowID,
           let focused = candidates.first(where: { $0.windowID == focusedWindowID }) {
            return focused
        }
        return candidates.first(where: { $0.isOnScreen && !$0.isMinimized })
            ?? candidates.first(where: { $0.windowID == nil })
    }

    /// Fresh focus can lead the independent use history. Promote only a source
    /// that survived the visibility rules; a source on another display stays out.
    static func orderedForSession(_ items: [SwitcherItem], currentID: String?) -> [SwitcherItem] {
        guard let currentID, let index = items.firstIndex(where: { $0.id == currentID }) else { return items }
        var ordered = items
        ordered.insert(ordered.remove(at: index), at: 0)
        return ordered
    }

    /// A focused-window Accessibility query is useful unless exactly one
    /// visible window already identifies the session source. With no visible
    /// windows, AX can still identify a minimized source window.
    static func needsFocusedWindowLookup(frontmostPID: pid_t,
                                         items: [SwitcherItem]) -> Bool {
        let appPID = appPID(forFrontmost: frontmostPID, items: items)
        return items.lazy.filter {
            $0.pid == appPID && $0.windowID != nil && $0.isOnScreen && !$0.isMinimized
        }.prefix(2).count != 1
    }

    /// The regular app behind the process holding the keyboard. Multi-process
    /// apps render their windows in an embedded helper, so the front process
    /// is not always the one the entries are filed under.
    static func appPID(forFrontmost frontmostPID: pid_t, items: [SwitcherItem]) -> pid_t {
        items.first(where: { $0.windowOwnerPID == frontmostPID })?.pid ?? frontmostPID
    }

    /// Keeps only the windows belonging to the app that owns the keyboard.
    static func frontmostAppWindows(allItems: [SwitcherItem], frontmostPID: pid_t) -> [SwitcherItem] {
        let appPID = appPID(forFrontmost: frontmostPID, items: allItems)
        return allItems.filter { $0.pid == appPID }
    }

    /// Where a window-scoped session starts. The foreground window sits first,
    /// so index 1 is the next window to switch to; a lone window stays at 0.
    static func initialWindowScopedSelectionIndex(itemCount: Int,
                                                  hasForegroundItem: Bool,
                                                  reversed: Bool) -> Int {
        guard itemCount > 0 else { return 0 }
        if reversed { return itemCount - 1 }
        guard hasForegroundItem else { return 0 }
        return itemCount > 1 ? 1 : 0
    }

    /// Shift means backward only for a physical-key match. Some keyboard
    /// layouts need Shift merely to type the shortcut's displayed character.
    static func windowNavigationDelta(positionalMatch: Bool,
                                      shiftIsNavigationModifier: Bool,
                                      shiftHeld: Bool) -> Int {
        positionalMatch && shiftIsNavigationModifier && shiftHeld ? -1 : 1
    }

    /// Whether a process looks like a compatibility layer hosting a program
    /// built for another platform. Those processes own real on-screen windows
    /// but run from a bare loader executable with no bundle identity: either
    /// the loader's own name, or a per-app "winetemp-" copy that bottle
    /// managers create so the process carries the hosted program's name and
    /// icon. They need special handling in the switcher because their windows
    /// expose no standard Accessibility subrole (issue #274).
    static func isCompatibilityLayerApp(bundleIdentifier: String?,
                                        executablePath: String?,
                                        localizedName: String?) -> Bool {
        guard bundleIdentifier == nil else { return false }
        if let executablePath, !executablePath.isEmpty {
            let components = executablePath.split(separator: "/")
            guard let leaf = components.last else { return false }
            return leaf.hasPrefix("wine")
                || components.contains { $0.hasPrefix("winetemp-") }
        }
        guard let localizedName else { return false }
        return localizedName.hasPrefix("wine")
    }

    /// Some professional media apps expose their main surface as a floating
    /// or undescribed Accessibility window instead of a standard macOS window.
    /// Match bundle prefixes case-insensitively because releases vary between
    /// lowercase, uppercase and versioned bundle identifiers.
    static func isSupportedMediaFloatingWindow(bundleIdentifier: String?, subrole: String?) -> Bool {
        guard let subrole, subrole == "AXFloatingWindow" || subrole == "AXUnknown",
              let bundleIdentifier else { return false }
        let lower = bundleIdentifier.lowercased()
        return lower.hasPrefix("com.adobe.audition")
            || lower.hasPrefix("com.adobe.aftereffects")
            || lower.hasPrefix("com.adobe.premiere")
            || lower.hasPrefix("com.adobe.mediaencoder")
            || lower.hasPrefix("com.adobe.characteranimator")
    }

    /// Whether a window whose Accessibility subrole is not a standard one is
    /// still a switch target.
    ///
    /// `AXUnknown` is the absence of a description, not a description of a
    /// utility surface: apps that draw their own title bar ship borderless
    /// windows, and macOS reports those as an undescribed `AXWindow`. The
    /// window server tells those apart from overlays for us — an ordinary
    /// window sits at the normal window level, while a HUD or panel floats
    /// above it — so a normal-level undescribed window is a real window
    /// whoever shipped it (issues #215, #512). Compatibility-hosted windows
    /// keep their own exception for the surfaces that resolve to no window
    /// server id at all (issue #274), and a screen-sized surface stays
    /// switchable so full-screen playback on another desktop is not lost.
    ///
    /// Every subrole the app did describe is left alone: a dialog, a sheet or
    /// a floating panel is filtered as before unless it fills the screen.
    /// The one exception is a normal-level `AXDialog` that can be minimized.
    /// AppKit gives that subrole to every window of a hidden app, and a window
    /// that still carries it after the app is shown again (reported on macOS 26,
    /// issue #2279) would otherwise drop out of the list. Alerts and panels read
    /// `AXDialog` too but have no working minimize button, unless the app made
    /// the panel miniaturizable; such a panel is listed like a window.
    ///
    /// A surface the app asked the window server to keep out of window cycling
    /// stays out of the switcher however it describes itself.
    static func isSwitchableNonstandardWindow(role: String?,
                                              subrole: String?,
                                              fillsScreen: Bool,
                                              hasNormalWindowLevel: Bool,
                                              acceptsUndescribedSubroles: Bool,
                                              canMinimize: Bool = false,
                                              isExcludedFromWindowCycle: Bool = false) -> Bool {
        guard role == "AXWindow", !isExcludedFromWindowCycle else { return false }
        if subrole == "AXUnknown" {
            return hasNormalWindowLevel || acceptsUndescribedSubroles || fillsScreen
        }
        if subrole == "AXDialog" {
            return hasNormalWindowLevel && canMinimize
        }
        return fillsScreen && subrole == "AXFloatingWindow"
    }

    /// Picks the entries that survive the visible cap, by index into `appPIDs`
    /// (the owning app of each entry, in the order the switcher will show them).
    ///
    /// The cap counts entries, not applications, so taking the first `limit` of
    /// them let a single app with many windows push whole other applications
    /// off the end: the switcher then looked like those apps were not running
    /// at all, and the only way to bring one back was to raise it by other
    /// means so its window rose in the use order. Issue #172 fixed the half of
    /// this that truncated before the use order was applied; this is the other
    /// half.
    ///
    /// Every app now gets its most recently used entry first, in app order, and
    /// only the slots left over are filled with further entries. With more apps
    /// than slots the apps compete with each other instead of one app's windows
    /// crowding the rest out.
    ///
    /// The incoming order is preserved: index 0 is the window the user is
    /// looking at and index 1 the toggle target, so the survivors must not be
    /// resorted into app groups.
    static func visibleSelectionIndices(appPIDs: [pid_t], limit: Int) -> [Int] {
        guard limit > 0 else { return [] }
        guard appPIDs.count > limit else { return Array(appPIDs.indices) }
        var chosen = Set<Int>()
        var representedApps = Set<pid_t>()
        // The window in front and the one before it lead the use order, and a
        // quick flick of the shortcut goes straight from the first to the
        // second. They stay whatever else a full list has to give up, as they
        // did under the plain leading slice, even when both belong to one app
        // and every other slot is needed for an app of its own.
        for index in appPIDs.indices.prefix(min(2, limit)) {
            chosen.insert(index)
            representedApps.insert(appPIDs[index])
        }
        for (index, pid) in appPIDs.enumerated() {
            guard chosen.count < limit else { break }
            guard representedApps.insert(pid).inserted else { continue }
            chosen.insert(index)
        }
        for index in appPIDs.indices {
            guard chosen.count < limit else { break }
            chosen.insert(index)
        }
        return chosen.sorted()
    }

    /// The entries a session keeps once its list is capped, by index into
    /// `items`. A session scoped to the front app's windows shows that app
    /// alone, so it caps that app's own list: other apps must not take places
    /// in a list that never shows them. `frontmostPID` is the process that
    /// owns the keyboard, resolved to its app the same way the session does.
    static func visibleSelectionIndices(items: [SwitcherItem],
                                        limit: Int,
                                        frontmostPID: pid_t?) -> [Int] {
        guard let frontmostPID else {
            return visibleSelectionIndices(appPIDs: items.map(\.pid), limit: limit)
        }
        let appPID = appPID(forFrontmost: frontmostPID, items: items)
        return Array(items.indices.filter { items[$0].pid == appPID }.prefix(max(0, limit)))
    }

    /// Finds the regular app that contains an accessory helper bundle.
    static func embeddedHostPID(helperBundlePath: String,
                                regularBundlePaths: [pid_t: String]) -> pid_t? {
        let helperPath = URL(fileURLWithPath: helperBundlePath).standardizedFileURL.path
        return regularBundlePaths
            .filter { _, hostPath in
                let normalizedHost = URL(fileURLWithPath: hostPath).standardizedFileURL.path
                return helperPath.hasPrefix(normalizedHost + "/")
            }
            .max { lhs, rhs in lhs.value.count < rhs.value.count }?
            .key
    }

    /// Picks the processes queried through Accessibility when the switcher
    /// opens. Every embedded helper stays eligible because Accessibility can be
    /// the only source for its fullscreen window on another desktop; the
    /// enumerator overlaps these remote queries so slow helpers do not stack.
    static func accessibilityPIDs(regularAppPIDs: Set<pid_t>,
                                  embeddedHostPIDs: [pid_t: pid_t],
                                  ownPID: pid_t,
                                  filterPID: pid_t?) -> Set<pid_t> {
        if let filterPID {
            let embeddedPIDs = embeddedHostPIDs.compactMap { ownerPID, hostPID in
                hostPID == filterPID ? ownerPID : nil
            }
            return Set([filterPID] + embeddedPIDs)
        }
        return regularAppPIDs.union(embeddedHostPIDs.keys).subtracting([ownPID])
    }

    /// Picks the running apps that earn an entry of their own because the
    /// window list has nothing for them.
    ///
    /// Only a total absence counts. An app whose windows exist but were left
    /// out on purpose keeps its absence: showing the app anyway would undo the
    /// choice the user just made, which is what the current-desktop option
    /// (issue #337) would suffer from otherwise. Order follows the candidate
    /// list, so the caller keeps ranking these entries the same way it ranks
    /// windows.
    static func windowlessAppPIDs(mode: SwitcherWindowlessApps,
                                  candidates: [SwitcherAppCandidate],
                                  pidsWithWindows: Set<pid_t>,
                                  pidsWithWithheldWindows: Set<pid_t>,
                                  desktopAppBundleIdentifier: String,
                                  appRules: [String: SwitcherAppRule] = [:]) -> [pid_t] {
        return candidates.compactMap { candidate in
            guard !pidsWithWindows.contains(candidate.pid),
                  !pidsWithWithheldWindows.contains(candidate.pid)
            else { return nil }
            if let bundleIdentifier = candidate.bundleIdentifier,
               let rule = appRules[bundleIdentifier] {
                switch rule {
                case .showWithoutWindows:
                    return candidate.pid
                case .windowsOnly, .hidden:
                    return nil
                }
            }
            switch mode {
            case .off:
                return nil
            case .finder:
                return candidate.bundleIdentifier == desktopAppBundleIdentifier ? candidate.pid : nil
            case .all:
                return candidate.pid
            }
        }
    }

    /// The display showing most of a window, as an index into `displayBounds`.
    /// Both rectangles share the window server's coordinate space (top-left
    /// origin), which is what `kCGWindowBounds` and `CGDisplayBounds` report,
    /// so no flipping is needed. A window straddling two displays belongs to
    /// the one holding the larger part. A window touching no display, or an
    /// entry with no frame at all (an app without windows), yields nil so the
    /// caller can fall back to another screen instead of guessing.
    static func displayIndex(showingMostOf windowFrame: CGRect, displayBounds: [CGRect]) -> Int? {
        guard !windowFrame.isNull, !windowFrame.isEmpty else { return nil }
        var best: (index: Int, area: CGFloat)?
        for (index, bounds) in displayBounds.enumerated() {
            let overlap = bounds.intersection(windowFrame)
            guard !overlap.isNull else { continue }
            let area = overlap.width * overlap.height
            guard area > 0, area > (best?.area ?? 0) else { continue }
            best = (index, area)
        }
        return best?.index
    }

    /// Collapses every window of an app into a single entry, so an app shows once
    /// in the switcher instead of once per window (or tab). Keeps one
    /// representative per app, preferring the on-screen, front window so its title
    /// and thumbnail are the one you would expect when switching to that app.
    static func groupWindowsByApp(_ windows: [SwitcherItem]) -> [SwitcherItem] {
        var indexByPid: [pid_t: Int] = [:]
        var grouped: [SwitcherItem] = []
        for window in windows {
            if let index = indexByPid[window.pid] {
                // Another window of the same app: prefer an on-screen window as
                // the representative when the one we kept is off-screen.
                if (window.isOnScreen && !grouped[index].isOnScreen)
                    || (window.isFullscreen && !grouped[index].isFullscreen) {
                    grouped[index] = window
                }
            } else {
                indexByPid[window.pid] = grouped.count
                grouped.append(window)
            }
        }
        return grouped
    }

    /// Windows belong to the display containing most of their frame.
    /// Windowless apps and off-display windows have no current display.
    static func itemsOnDisplay(_ items: [SwitcherItem],
                               displayBounds: [CGRect],
                               targetIndex: Int) -> [SwitcherItem] {
        guard displayBounds.indices.contains(targetIndex) else { return [] }
        return items.filter { item in
            guard !item.isAppEntry,
                  let index = displayIndex(showingMostOf: item.frame,
                                           displayBounds: displayBounds) else { return false }
            return index == targetIndex
        }
    }

    static func hidesApp(bundleIdentifier: String?,
                         appRules: [String: SwitcherAppRule]) -> Bool {
        guard let bundleIdentifier else { return false }
        return appRules[bundleIdentifier] == .hidden
    }

    /// When Accessibility does not match a hidden app's WindowServer surface,
    /// its Space assignment distinguishes a real window from a leftover.
    static func isConfirmedHiddenAppWindow(appIsHidden: Bool,
                                           windowSpaces: [UInt64]) -> Bool {
        appIsHidden && !windowSpaces.isEmpty
    }

    /// A partial Accessibility list cannot veto windows on another desktop.
    /// Still reject unmatched visible surfaces and helpers excluded from cycling.
    static func keepsUnmatchedWindow(isOnHiddenSpace: Bool,
                                     isConfirmedHiddenAppWindow: Bool,
                                     isExcludedFromWindowCycle: Bool,
                                     isOrderedIn: Bool?,
                                     allowsUnverifiedHiddenSpace: Bool) -> Bool {
        guard !isExcludedFromWindowCycle else { return false }
        // Hiding an app orders its windows out without closing them.
        if isConfirmedHiddenAppWindow { return true }
        guard isOnHiddenSpace else { return false }
        // Preserve the earlier empty-Accessibility and fullscreen exceptions:
        // ordering out can also mean minimized, not closed. Only broaden that
        // fallback when the native query positively witnesses a live window.
        return allowsUnverifiedHiddenSpace || isOrderedIn == true
    }

    /// Whether a WindowServer surface whose owner never answered Accessibility
    /// is a stale leftover instead of a real window (issue #807). The ghost
    /// veto normally comes from the Accessibility cross-check, but a busy or
    /// dying process answers with nothing, which used to let its closed
    /// windows keep appearing in the switcher. The window server itself tells
    /// the two apart: a real window off screen is still parked on at least one
    /// Space, while a leftover belongs to none. Anything on screen stays — a
    /// visible surface is real by definition — and when the Space queries are
    /// unavailable there is no evidence either way, so the surface keeps the
    /// pre-existing treatment.
    static func unwitnessedSurfaceIsLeftover(isOnScreen: Bool,
                                             canResolveSpaces: Bool,
                                             windowSpacesCount: Int) -> Bool {
        guard !isOnScreen, canResolveSpaces else { return false }
        return windowSpacesCount == 0
    }

    /// Downsamples a capture into a small alpha grid for classification.
    static func alphaGrid(of image: CGImage, gridSize: Int = captureAlphaGridSize) -> [Double]? {
        guard gridSize > 0 else { return nil }
        let bytesPerPixel = 4
        var data = [UInt8](repeating: 0, count: gridSize * gridSize * bytesPerPixel)
        let drawn = data.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress,
                                          width: gridSize,
                                          height: gridSize,
                                          bitsPerComponent: 8,
                                          bytesPerRow: gridSize * bytesPerPixel,
                                          space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
            else { return false }
            context.interpolationQuality = .low
            context.draw(image, in: CGRect(x: 0, y: 0, width: CGFloat(gridSize), height: CGFloat(gridSize)))
            return true
        }
        guard drawn else { return nil }
        return (0..<(gridSize * gridSize)).map { Double(data[$0 * bytesPerPixel + 3]) / 255.0 }
    }

    /// Whether a window capture looks like Stage Manager's strip rendering
    /// instead of real window content. Parked windows are captured as a sheared
    /// snapshot whose bounding box leaves fully transparent wedges in at least
    /// two corner/edge probes of the downsampled grid; a real window capture is
    /// opaque edge to edge (rounded corners only shave sub-cell slivers at this
    /// resolution, alpha stays well above the threshold).
    static func captureLooksTransformed(alphaGrid: [Double],
                                        gridSize: Int = captureAlphaGridSize) -> Bool {
        guard gridSize >= 4, alphaGrid.count == gridSize * gridSize else { return false }
        let last = gridSize - 1
        let mid = gridSize / 2
        let probes = [
            (0, 0), (0, last), (last, 0), (last, last),
            (0, mid), (last, mid), (mid, 0), (mid, last),
        ]
        let transparent = probes.filter { alphaGrid[$0.0 * gridSize + $0.1] < 0.05 }.count
        return transparent >= 2
    }

    /// How far the two axes of a capture may disagree before it counts as a
    /// slice of a window instead of the whole window.
    static let captureCoverageTolerance = 0.08

    /// Whether a capture holds the whole window or only the part of it that
    /// was inside a display. The window server clips a window capture to the
    /// visible region, so a window hanging over a screen edge comes back as a
    /// thin band of real content while still reporting its full size. Measured
    /// with a 620 by 452 point window: fully visible it captures 2.00 by 2.00
    /// pixels per point, hanging over the bottom edge 2.00 by 0.32, hanging
    /// past the side edge 0.19 by 2.00. Comparing the two axes catches that
    /// without caring about the display scale, so a plain screen and a Retina
    /// screen both score the same. A window with nothing to measure passes,
    /// because there is no evidence either way.
    static func captureCoversWindow(imageWidth: Int,
                                    imageHeight: Int,
                                    windowSize: CGSize,
                                    tolerance: Double = captureCoverageTolerance) -> Bool {
        guard windowSize.width.isFinite, windowSize.height.isFinite,
              windowSize.width > 1, windowSize.height > 1
        else { return true }
        let horizontal = Double(imageWidth) / Double(windowSize.width)
        let vertical = Double(imageHeight) / Double(windowSize.height)
        guard horizontal > 0, vertical > 0 else { return true }
        return max(horizontal, vertical) / min(horizontal, vertical) <= 1 + tolerance
    }

    /// Corners of the opaque quadrilateral in a capture, in top-left-origin
    /// pixel coordinates. Stage Manager's strip artwork is the real window
    /// content under a mild perspective transform; these corners feed the
    /// perspective correction that recovers an upright preview.
    struct CaptureQuadCorners: Equatable {
        var topLeft: CGPoint
        var topRight: CGPoint
        var bottomRight: CGPoint
        var bottomLeft: CGPoint
    }

    /// Finds the extreme opaque pixels of a capture's alpha channel (one byte
    /// per pixel, rows from the top). Returns nil when the opaque region is too
    /// small or degenerate to be window content.
    static func opaqueQuadCorners(alpha: [UInt8],
                                  width: Int,
                                  height: Int,
                                  threshold: UInt8 = 250) -> CaptureQuadCorners? {
        guard width > 16, height > 16, alpha.count == width * height else { return nil }
        var topLeft = (score: Int.max, x: 0, y: 0)
        var topRight = (score: Int.min, x: 0, y: 0)
        var bottomRight = (score: Int.min, x: 0, y: 0)
        var bottomLeft = (score: Int.max, x: 0, y: 0)
        var opaqueCount = 0
        for y in 0..<height {
            let row = y * width
            for x in 0..<width where alpha[row + x] >= threshold {
                opaqueCount += 1
                let sum = x + y
                let diff = x - y
                if sum < topLeft.score { topLeft = (sum, x, y) }
                if diff > topRight.score { topRight = (diff, x, y) }
                if sum > bottomRight.score { bottomRight = (sum, x, y) }
                if diff < bottomLeft.score { bottomLeft = (diff, x, y) }
            }
        }
        guard opaqueCount >= (width * height) / 10 else { return nil }
        let spanX = max(topRight.x, bottomRight.x) - min(topLeft.x, bottomLeft.x)
        let spanY = max(bottomLeft.y, bottomRight.y) - min(topLeft.y, topRight.y)
        guard spanX >= width / 2, spanY >= height / 2 else { return nil }
        return CaptureQuadCorners(topLeft: CGPoint(x: topLeft.x, y: topLeft.y),
                                  topRight: CGPoint(x: topRight.x, y: topRight.y),
                                  bottomRight: CGPoint(x: bottomRight.x, y: bottomRight.y),
                                  bottomLeft: CGPoint(x: bottomLeft.x, y: bottomLeft.y))
    }

    /// Least-recently-used cache entries beyond `limit`, never counting ids the
    /// caller is actively refreshing as victims.
    static func staleCacheVictims(ids: Set<CGWindowID>,
                                  active: Set<CGWindowID>,
                                  lastTouched: [CGWindowID: TimeInterval],
                                  limit: Int) -> [CGWindowID] {
        let overflow = ids.count - limit
        guard overflow > 0 else { return [] }
        return ids.filter { !active.contains($0) }
            .sorted { (lastTouched[$0] ?? 0) < (lastTouched[$1] ?? 0) }
            .prefix(overflow)
            .map { $0 }
    }

    /// Least-recently-used entries to evict until the cache's total bytes fit
    /// the budget, never counting ids the caller is actively refreshing. Big
    /// thumbnails (large windows on Retina screens) would otherwise let a
    /// count-limited cache hold far more memory than intended.
    static func cacheByteBudgetVictims(sizes: [CGWindowID: Int],
                                       active: Set<CGWindowID>,
                                       lastTouched: [CGWindowID: TimeInterval],
                                       budget: Int) -> [CGWindowID] {
        var total = sizes.values.reduce(0, +)
        guard total > budget else { return [] }
        var victims: [CGWindowID] = []
        let evictable = sizes.keys.filter { !active.contains($0) }
            .sorted { (lastTouched[$0] ?? 0) < (lastTouched[$1] ?? 0) }
        for id in evictable {
            guard total > budget else { break }
            total -= sizes[id] ?? 0
            victims.append(id)
        }
        return victims
    }

    static func shouldNavigateBackwardOnShiftPress(shiftIsNavigationModifier: Bool,
                                                   wasShiftHeld: Bool,
                                                   isShiftHeld: Bool) -> Bool {
        shiftIsNavigationModifier && isShiftHeld && !wasShiftHeld
    }

    /// Keeps the overflow icon row from scrolling past either end.
    static func clampedIconRowFirstVisibleIndex(itemCount: Int,
                                                visibleCount: Int,
                                                firstVisibleIndex: Int) -> Int {
        let visible = max(1, visibleCount)
        guard itemCount > visible else { return 0 }
        return min(max(0, firstVisibleIndex), itemCount - visible)
    }

    /// Slides the visible window just far enough for `selectedIndex` to stay
    /// on screen. Centering would yank several icons past the pointer at once.
    static func iconRowFirstVisibleIndex(revealing selectedIndex: Int,
                                         itemCount: Int,
                                         visibleCount: Int,
                                         currentFirstVisibleIndex: Int) -> Int {
        let visible = max(1, visibleCount)
        let first = clampedIconRowFirstVisibleIndex(itemCount: itemCount,
                                                    visibleCount: visible,
                                                    firstVisibleIndex: currentFirstVisibleIndex)
        guard itemCount > 0 else { return 0 }
        let selected = min(max(0, selectedIndex), itemCount - 1)
        if selected < first { return selected }
        let lastVisible = first + min(visible, itemCount) - 1
        if selected > lastVisible { return selected - min(visible, itemCount) + 1 }
        return first
    }

    /// Hovering a middle icon must not move the row. Only the last visible
    /// icon on a side, and only while more icons wait beyond it, may step.
    static func iconRowEdgeHoverDelta(hoveredIndex: Int,
                                      firstVisibleIndex: Int,
                                      visibleCount: Int,
                                      itemCount: Int) -> Int? {
        let visible = max(1, visibleCount)
        guard itemCount > visible else { return nil }
        let first = clampedIconRowFirstVisibleIndex(itemCount: itemCount,
                                                    visibleCount: visible,
                                                    firstVisibleIndex: firstVisibleIndex)
        let lastVisible = first + visible - 1
        let hovered = min(max(0, hoveredIndex), itemCount - 1)
        if hovered == lastVisible, lastVisible < itemCount - 1 { return 1 }
        if hovered == first, first > 0 { return -1 }
        return nil
    }

    /// After an edge-hover step, highlight the newly revealed icon so the
    /// pointer is still sitting on the last visible app of that side.
    static func iconRowIndexAfterEdgeHoverStep(firstVisibleIndex: Int,
                                               visibleCount: Int,
                                               itemCount: Int,
                                               delta: Int) -> Int {
        let visible = max(1, visibleCount)
        let first = clampedIconRowFirstVisibleIndex(itemCount: itemCount,
                                                    visibleCount: visible,
                                                    firstVisibleIndex: firstVisibleIndex)
        guard itemCount > 0 else { return 0 }
        if delta < 0 { return first }
        return min(itemCount - 1, first + min(visible, itemCount) - 1)
    }

    /// A Tab this close behind a Shift-press step is the same physical chord
    /// and must not step again; later Tabs during the Shift hold keep walking
    /// the list (issue #784).
    static let shiftBackChordWindow: TimeInterval = 0.35

    static func selectedPreviewPlacement(appCount rawAppCount: Int,
                                         selectedAppIndex rawSelectedAppIndex: Int,
                                         selectedWindowIndex _: Int,
                                         selectedWindowCount _: Int,
                                         visibleIconCount rawVisibleIconCount: Int,
                                         appRowContentWidth: CGFloat,
                                         appRowSurfaceWidth: CGFloat,
                                         previewContentWidth _: CGFloat,
                                         previewSurfaceWidth: CGFloat) -> SwitcherIconRowPreviewPlacement {
        let appCount = max(1, rawAppCount)
        let visibleIconCount = max(1, rawVisibleIconCount)
        let selectedAppIndex = min(max(0, rawSelectedAppIndex), appCount - 1)
        let contentWidth = max(appRowSurfaceWidth, previewSurfaceWidth)
        guard previewSurfaceWidth < contentWidth else {
            return SwitcherIconRowPreviewPlacement(contentWidth: contentWidth, leading: 0)
        }

        let rowLeading = max(0, (contentWidth - appRowSurfaceWidth) / 2) + SwitcherIconRowLayout.rowHorizontalPadding
        let selectedCenterInRow: CGFloat
        if appCount > visibleIconCount {
            selectedCenterInRow = rowLeading + appRowContentWidth / 2
        } else {
            selectedCenterInRow = rowLeading + SwitcherIconRowLayout.appTileWidth / 2
                + CGFloat(selectedAppIndex) * (SwitcherIconRowLayout.appTileWidth + SwitcherIconRowLayout.spacing)
        }

        let rawLeading = selectedCenterInRow - previewSurfaceWidth / 2
        let clampedLeading = min(max(0, rawLeading), contentWidth - previewSurfaceWidth)
        return SwitcherIconRowPreviewPlacement(contentWidth: contentWidth, leading: clampedLeading)
    }

    static func shortcutHints(for switcherShortcut: GlobalShortcut,
                              windowShortcut: GlobalShortcut) -> SwitcherShortcutHints {
        return SwitcherShortcutHints(apps: switcherShortcut.displayString,
                                     windows: windowShortcut.displayString)
    }

    static func appGroups(items: [SwitcherItem]) -> [SwitcherAppGroup] {
        var seen: Set<pid_t> = []
        var groups: [SwitcherAppGroup] = []
        for (index, item) in items.enumerated() where !seen.contains(item.pid) {
            seen.insert(item.pid)
            groups.append(SwitcherAppGroup(pid: item.pid,
                                           appName: item.appName,
                                           representativeIndex: index,
                                           itemIDs: items.filter { $0.pid == item.pid }.map(\.id)))
        }
        return groups
    }

    static func windowlessAppDividerPIDs(items: [SwitcherItem]) -> Set<pid_t> {
        let groups = appGroups(items: items)
        let windowedPIDs = Set(items.filter { !$0.isAppEntry }.map(\.pid))
        var dividers: Set<pid_t> = []
        for (previous, current) in zip(groups, groups.dropFirst()) {
            if windowedPIDs.contains(previous.pid) != windowedPIDs.contains(current.pid) {
                dividers.insert(current.pid)
            }
        }
        return dividers
    }

    /// Where a session starts. `pids` is the list in display order, one entry
    /// per position the shortcut steps through: one per window in the grid,
    /// one per app in the icon row.
    ///
    /// The foreground window always sits first, so the selection starts one
    /// step past it and a single press already switches. When there is no
    /// foreground window the list holds nothing the user is looking at, except
    /// windows the front app left minimized or on another Space; those are
    /// skipped for the same reason, so one press still lands somewhere else.
    static func initialSelectionPosition(pids: [pid_t],
                                         hasForegroundEntry: Bool,
                                         frontmostPID: pid_t?,
                                         reversed: Bool) -> Int {
        guard !pids.isEmpty else { return 0 }
        if reversed { return pids.count - 1 }
        guard hasForegroundEntry else {
            return pids.firstIndex { $0 != frontmostPID } ?? 0
        }
        return pids.count > 1 ? 1 : 0
    }

    /// Column count for a wrapping card grid: keep the same number of rows
    /// the screen already requires, but do not stretch to a full first row
    /// when the leftover items would sit almost empty on the next one.
    static func gridColumnCount(itemCount: Int, maxColumns: Int) -> Int {
        let count = max(itemCount, 1)
        let packed = min(count, max(maxColumns, 1))
        let rows = (count + packed - 1) / packed
        return min(packed, (count + rows - 1) / rows)
    }

    /// Moves between rows without wrapping. When the row below is shorter,
    /// Down lands on that row's last item instead of leaving the selection in
    /// place because the same column is missing.
    static func gridSelectionIndex(after selectedIndex: Int,
                                   itemCount: Int,
                                   columns: Int,
                                   movingDown: Bool) -> Int {
        guard itemCount > 0 else { return 0 }
        let current = min(max(0, selectedIndex), itemCount - 1)
        let safeColumns = max(1, columns)

        guard movingDown else {
            let target = current - safeColumns
            return target >= 0 ? target : current
        }

        let nextRowStart = (current / safeColumns + 1) * safeColumns
        guard nextRowStart < itemCount else { return current }
        return min(current + safeColumns, itemCount - 1)
    }

    /// With wrapping off (key held on autorepeat, like the system switcher)
    /// the selection stops at either end instead of cycling around.
    static func nextAppSelectionIndex(items: [SwitcherItem],
                                      selectedIndex: Int,
                                      delta: Int,
                                      wrapping: Bool = true) -> Int {
        let groups = appGroups(items: items)
        guard !groups.isEmpty else { return 0 }
        guard items.indices.contains(selectedIndex) else {
            return groups[0].representativeIndex
        }

        let selectedID = items[selectedIndex].id
        let currentGroupIndex = groups.firstIndex { $0.itemIDs.contains(selectedID) } ?? 0
        let unwrapped = currentGroupIndex + delta
        if !wrapping, !groups.indices.contains(unwrapped) {
            return groups[currentGroupIndex].representativeIndex
        }
        let targetGroupIndex = (unwrapped + groups.count) % groups.count
        return groups[targetGroupIndex].representativeIndex
    }

    static func nextWindowSelectionIndexWithinApp(items: [SwitcherItem],
                                                  selectedIndex: Int,
                                                  delta: Int) -> Int {
        guard items.indices.contains(selectedIndex) else { return 0 }
        let pid = items[selectedIndex].pid
        let indices = items.indices.filter { items[$0].pid == pid }
        guard !indices.isEmpty,
              let current = indices.firstIndex(of: selectedIndex)
        else { return selectedIndex }

        let target = (current + delta + indices.count) % indices.count
        return indices[target]
    }

    static func activationPlan(targetsSpecificWindow: Bool) -> SwitcherActivationPlan {
        SwitcherActivationPlan(
            activateAllWindows: !targetsSpecificWindow,
            makeAppFrontmostAfterActivation: !targetsSpecificWindow,
            restoreSourceWhenTargetMinimizes: targetsSpecificWindow
        )
    }

    static func shouldActivateAllWindows(targetsSpecificWindow: Bool) -> Bool {
        activationPlan(targetsSpecificWindow: targetsSpecificWindow).activateAllWindows
    }

    static func appActivationRoute(plan: SwitcherActivationPlan,
                                   windowID: CGWindowID?) -> SwitcherAppActivationRoute {
        if !plan.activateAllWindows, let windowID {
            return .exactWindow(windowID)
        }
        return .wholeApp
    }

    static func shouldRestoreSourceAfterTargetMinimize(targetPID: pid_t,
                                                       sourcePID: pid_t?,
                                                       frontmostPID: pid_t?,
                                                       targetIsMinimized: Bool,
                                                       ownPID: pid_t = ProcessInfo.processInfo.processIdentifier,
                                                       frontmostMatchesTargetBundle: Bool = false,
                                                       frontmostCanBeSystemPromotion: Bool = false) -> Bool {
        guard targetIsMinimized,
              let sourcePID,
              let frontmostPID,
              sourcePID != targetPID else { return false }
        if frontmostPID == sourcePID { return false }
        return frontmostPID == targetPID
            || frontmostPID == ownPID
            || frontmostMatchesTargetBundle
            || frontmostCanBeSystemPromotion
    }

    /// The three Accessibility-backed inputs are autoclosures because the
    /// minimize restore fires this on every pulse of a dense timer and most
    /// pulses stop at the frontmost checks below. Taking them as values let a
    /// caller pay a `kAXWindows` copy and two AX reads per pulse for an answer
    /// the cheap comparisons had already given; taking them as closures means
    /// a caller cannot pay that cost early even by accident.
    static func shouldRestoreSourceAfterTargetMinimizeIntent(targetPID: pid_t,
                                                             sourcePID: pid_t?,
                                                             frontmostPID: pid_t?,
                                                             focusedWindowID: @autoclosure () -> UInt32?,
                                                             targetWindowID: UInt32,
                                                             targetIsMinimized: @autoclosure () -> Bool,
                                                             ownPID: pid_t = ProcessInfo.processInfo.processIdentifier,
                                                             frontmostMatchesTargetBundle: @autoclosure () -> Bool = false,
                                                             frontmostCanBeSystemPromotion: Bool = false) -> Bool {
        guard let sourcePID,
              sourcePID != targetPID else { return false }
        if frontmostPID == sourcePID { return false }
        let frontmostIsForeign = frontmostPID != nil
            && frontmostPID != targetPID
            && frontmostPID != ownPID
            && !frontmostMatchesTargetBundle()
        if frontmostIsForeign, !frontmostCanBeSystemPromotion { return false }
        let targetIsMinimized = targetIsMinimized()
        if frontmostIsForeign, !targetIsMinimized { return false }
        if targetIsMinimized { return true }
        guard let focusedWindowID = focusedWindowID() else { return false }
        return focusedWindowID != targetWindowID
    }

    static func shouldStageSourceBehindTarget(targetPID: pid_t,
                                              sourcePID: pid_t?,
                                              sourceWindowID: UInt32?,
                                              ownPID: pid_t = ProcessInfo.processInfo.processIdentifier) -> Bool {
        guard let sourcePID,
              sourcePID != targetPID,
              sourcePID != ownPID,
              sourceWindowID != nil else { return false }
        return true
    }

    /// Window identities, not a list of focusable windows: keeping every layer
    /// prevents an existing dialog or auxiliary surface from appearing new.
    static func focusRetryWindowIDs(in windows: [[String: Any]], ownerPID: pid_t) -> Set<CGWindowID> {
        Set(windows.compactMap { info -> CGWindowID? in
            guard (info[kCGWindowOwnerPID as String] as? NSNumber)?.int32Value == ownerPID else { return nil }
            return (info[kCGWindowNumber as String] as? NSNumber)?.uint32Value
        })
    }

    /// Source app for the delayed focus guards only. A session source wins;
    /// otherwise the app a caller saw in front when the activation began keeps
    /// the handoff retry settling, without reclaiming focus after a later
    /// unrelated activation. The target and this process are never a handoff.
    static func focusRetrySourcePID(sessionSourcePID: pid_t?,
                                    handoffSourcePID: pid_t?,
                                    targetPID: pid_t,
                                    ownPID: pid_t = ProcessInfo.processInfo.processIdentifier) -> pid_t? {
        if let sessionSourcePID { return sessionSourcePID }
        guard let handoffSourcePID,
              handoffSourcePID != targetPID,
              handoffSourcePID != ownPID else { return nil }
        return handoffSourcePID
    }

    static func shouldContinueFocusRetry(targetPID: pid_t,
                                         sourcePID: pid_t?,
                                         frontmostPID: @autoclosure () -> pid_t?,
                                         targetIsMinimized: Bool,
                                         targetStartedMinimized: Bool,
                                         targetWasObservedRestored: Bool = false,
                                         knownWindowIDs: Set<CGWindowID> = [],
                                         targetAppWindowIDs: @autoclosure () -> Set<CGWindowID> = [],
                                         targetAppFocusedWindowID: @autoclosure () -> CGWindowID? = nil,
                                         ignoresForeground: Bool = false,
                                         ownPID: pid_t = ProcessInfo.processInfo.processIdentifier) -> Bool {
        guard !targetIsMinimized
                || (targetStartedMinimized && !targetWasObservedRestored)
        else { return false }
        let initialFrontmostPID = frontmostPID()
        // A hop travels across desktops, and the system fronts whatever sits
        // on top of each one it passes. Which app is in front while that runs
        // says nothing about where the user wants to be, so hop passes opt out
        // of this check and use the app's own focus below. Ordinary retries
        // must never reclaim a window after an unrelated app is frontmost.
        // The source app is allowed while the handoff is settling, because
        // the target may still need its delayed pass.
        let waitingForInitialMinimizedRestore = targetStartedMinimized
            && targetIsMinimized
            && (sourcePID == nil || initialFrontmostPID == sourcePID)
        if !ignoresForeground,
           let initialFrontmostPID,
           initialFrontmostPID != targetPID,
           initialFrontmostPID != ownPID,
           initialFrontmostPID != sourcePID,
           !waitingForInitialMinimizedRestore {
            return false
        }
        // Z-order cannot identify keyboard focus: a new transparent helper
        // may sit above a real window. Only query Accessibility when this app
        // is active and the cheap window-server list contains something new.
        // An unavailable focus reading preserves the previous retry behavior.
        guard ignoresForeground || initialFrontmostPID == targetPID,
              !knownWindowIDs.isEmpty,
              !targetAppWindowIDs().isSubset(of: knownWindowIDs) else { return true }
        let focusedWindowID = targetAppFocusedWindowID()
        // Accessibility can wait on the other process. Do not act on the old
        // foreground observation if the user left the app during that wait.
        if !ignoresForeground, frontmostPID() != targetPID { return false }
        guard let focusedWindowID else { return true }
        return knownWindowIDs.contains(focusedWindowID)
    }

    /// Async results belong only to the still-pending shortcut press. A key
    /// release may turn that pending start into an immediate commit, while a
    /// teardown or a newer press clears/replaces the generation entirely.
    static func isCurrentSessionStart(generation: UInt64,
                                      pendingGeneration: UInt64?) -> Bool {
        pendingGeneration == generation
    }

    static func pendingKeyDecision(sessionIsActive: Bool,
                                   hasPendingStart: Bool,
                                   commitWhenReady: Bool,
                                   matchesShortcut: Bool) -> SwitcherPendingKeyDecision {
        if sessionIsActive { return .handleActiveSession }
        guard hasPendingStart, !matchesShortcut else { return .routeShortcut }
        return commitWhenReady ? .cancelAndSwallow : .swallow
    }

    /// The explicit takeover setting is the authority to change WindowServer's
    /// shared symbolic-hotkey state. Shortcut matching alone is never enough.
    static func nativeHotkeysToSuppress(takeOverSystemShortcuts: Bool,
                                        appsShortcut: GlobalShortcut,
                                        windowShortcut: GlobalShortcut,
                                        nativeShortcuts: [SwitcherNativeSymbolicHotKey: GlobalShortcut])
        -> Set<SwitcherNativeSymbolicHotKey> {
        guard takeOverSystemShortcuts else { return [] }
        let ownedShortcuts = [appsShortcut, windowShortcut]
        return Set(nativeShortcuts.compactMap { id, nativeShortcut in
            ownedShortcuts.contains { switcherShortcut($0, owns: nativeShortcut) } ? id : nil
        })
    }

    /// The raw ids the switcher wants switched off, resolved against the live
    /// table: the shared take-over speaks WindowServer ids, and reading the
    /// shortcut of each id from the table is what keeps a remapped key — or a
    /// neighbour such as the screenshot key — from being taken over by guess.
    static func nativeHotkeyIDs(takeOverSystemShortcuts: Bool,
                                appsShortcut: GlobalShortcut,
                                windowShortcut: GlobalShortcut,
                                liveEntries: [LiveSystemShortcut]) -> Set<Int32> {
        let nativeShortcuts = Dictionary(
            liveEntries.compactMap { entry -> (SwitcherNativeSymbolicHotKey, GlobalShortcut)? in
                SwitcherNativeSymbolicHotKey(rawValue: entry.id).map { ($0, entry.shortcut) }
            },
            uniquingKeysWith: { first, _ in first })
        return Set(nativeHotkeysToSuppress(takeOverSystemShortcuts: takeOverSystemShortcuts,
                                           appsShortcut: appsShortcut,
                                           windowShortcut: windowShortcut,
                                           nativeShortcuts: nativeShortcuts).map(\.rawValue))
    }

    /// Mirrors the event tap's `allowingExtraShift` match: Shift reverses a
    /// shortcut that does not already require it, and WindowServer registers
    /// the forward and reverse directions as separate symbolic hotkeys.
    private static func switcherShortcut(_ shortcut: GlobalShortcut,
                                         owns nativeShortcut: GlobalShortcut) -> Bool {
        guard shortcut.keyCode == nativeShortcut.keyCode else { return false }
        if shortcut.modifiers.contains(.shift) {
            return shortcut.modifiers == nativeShortcut.modifiers
        }
        return nativeShortcut.modifiers.subtracting(.shift) == shortcut.modifiers
    }

    static func isCurrentActivationGeneration(_ scheduled: UInt64,
                                              current: UInt64) -> Bool {
        scheduled == current
    }

    static func shouldRestoreHiddenApp(revealGeneration: UInt64,
                                       currentGeneration: UInt64,
                                       appWasReactivated: Bool) -> Bool {
        revealGeneration == currentGeneration && !appWasReactivated
    }

    static func shouldContinueAppActivationRetry(targetPID: pid_t,
                                                 sourcePID: pid_t?,
                                                 frontmostPID: pid_t?,
                                                 targetWasObservedFrontmost: Bool,
                                                 ownPID: pid_t = ProcessInfo.processInfo.processIdentifier) -> Bool {
        if frontmostPID == targetPID { return true }
        guard !targetWasObservedFrontmost else { return false }
        guard let frontmostPID else { return true }
        return frontmostPID == sourcePID || frontmostPID == ownPID
    }

    static func shouldKeepMinimizeRestoreObserver(targetPID: pid_t,
                                                  sourcePID: pid_t,
                                                  activatedPID: pid_t,
                                                  ownPID: pid_t = ProcessInfo.processInfo.processIdentifier,
                                                  activatedMatchesTargetBundle: Bool = false) -> Bool {
        activatedPID == targetPID || activatedPID == sourcePID || activatedPID == ownPID || activatedMatchesTargetBundle
    }

    static func closeState(afterRemoving closedItemID: String,
                           itemIDs: [String],
                           selectedIndex: Int) -> SwitcherCloseState {
        guard let removedIndex = itemIDs.firstIndex(of: closedItemID) else {
            return SwitcherCloseState(
                remainingItemIDs: itemIDs,
                selectedIndex: clampedSelection(selectedIndex, count: itemIDs.count),
                didRemove: false,
                shouldEndSession: itemIDs.isEmpty
            )
        }

        let currentIndex = clampedSelection(selectedIndex, count: itemIDs.count)
        let remaining = itemIDs.filter { $0 != closedItemID }
        guard !remaining.isEmpty else {
            return SwitcherCloseState(remainingItemIDs: [],
                                      selectedIndex: 0,
                                      didRemove: true,
                                      shouldEndSession: true)
        }

        let nextIndex: Int
        if removedIndex < currentIndex {
            nextIndex = currentIndex - 1
        } else if removedIndex == currentIndex {
            nextIndex = min(currentIndex, remaining.count - 1)
        } else {
            nextIndex = currentIndex
        }

        return SwitcherCloseState(remainingItemIDs: remaining,
                                  selectedIndex: clampedSelection(nextIndex, count: remaining.count),
                                  didRemove: true,
                                  shouldEndSession: false)
    }

    /// Which entry a release should raise while windows are already closing:
    /// the highlight lands where the grid settles once they are gone, so
    /// letting go right after closing one never raises it again. With nothing
    /// left to raise, the release only dismisses the panel.
    static func commitTargetID(itemIDs: [String],
                               selectedIndex: Int,
                               closingItemIDs: Set<String>) -> String? {
        guard itemIDs.indices.contains(selectedIndex) else { return nil }
        let selected = itemIDs[selectedIndex]
        guard closingItemIDs.contains(selected) else { return selected }
        let remaining = itemIDs.filter { !closingItemIDs.contains($0) }
        guard !remaining.isEmpty else { return nil }
        let position = itemIDs[..<selectedIndex].filter { !closingItemIDs.contains($0) }.count
        return remaining[clampedSelection(position, count: remaining.count)]
    }

    /// Whether a click ends the session. The panel floats above everything and
    /// never takes the keyboard from the app in front, so clicking another
    /// window is what most people try when they want it gone, and a session
    /// opened with no key held down has no release coming to close it either
    /// (issue #384). Anything on the panel still belongs to the panel.
    static func shouldDismissForClick(panelIsVisible: Bool,
                                      panelFrame: CGRect,
                                      location: CGPoint) -> Bool {
        panelIsVisible && !panelFrame.contains(location)
    }

    /// Whether a mouse click is a middle click on a hovered switcher card.
    static func isMiddleClickInsidePanel(eventType: CGEventType,
                                         buttonNumber: Int64,
                                         panelIsVisible: Bool,
                                         panelFrame: CGRect,
                                         location: CGPoint,
                                         itemIsHovered: Bool) -> Bool {
        eventType == .otherMouseDown
            && buttonNumber == 2
            && panelIsVisible
            && panelFrame.contains(location)
            && itemIsHovered
    }

    /// A release is swallowed only when its matching press closed a card.
    static func shouldSwallowMiddleMouseUp(eventType: CGEventType,
                                           buttonNumber: Int64,
                                           swallowedMouseDown: Bool) -> Bool {
        eventType == .otherMouseUp
            && buttonNumber == 2
            && swallowedMouseDown
    }

    /// The letters the panel acts on: W closes the highlighted window, Q quits
    /// its app, and, when `pinSearchEnabled`, S pins the search field open so
    /// it no longer needs the session's modifier held to stay on screen — that
    /// modifier is what turns some keys into special characters instead of
    /// plain letters, e.g. ⌥S types "ß". S is opt-in: existing users who type it as
    /// the first letter of a search keep filtering by "s" until they turn the
    /// preference on. A keyboard answers by the letter it types, so all three
    /// keys stay where they are printed even on layouts that move them
    /// (measured: French and Italian put W elsewhere, Turkish moves both).
    /// Layouts that type no Latin letter at all, like Cyrillic and Greek, go
    /// by the key's position instead, which is exactly where macOS resolves
    /// their command shortcuts (measured: with Command held both translate
    /// that key to "w").
    static func letterAction(typedCharacter: String?, keyCode: Int64, pinSearchEnabled: Bool) -> SwitcherLetterAction? {
        guard let letter = latinLetter(in: typedCharacter) else {
            switch keyCode {
            case USKeyPosition.w: return .closeWindow
            case USKeyPosition.q: return .quitApp
            case USKeyPosition.s where pinSearchEnabled: return .pinSearch
            default: return nil
            }
        }
        switch letter {
        case "w": return .closeWindow
        case "q": return .quitApp
        case "s" where pinSearchEnabled: return .pinSearch
        default:
            // ⌥ turns S into "ß", and adding Caps Lock on top turns it into
            // "Í" instead — a real, differently-accented letter that folds to
            // an unrelated "i" rather than failing to fold at all, so the S
            // case above never sees it. Fall back to the key position only when
            // the original typed character is non-ASCII, to avoid triggering on
            // remapped Latin layouts where the US-S key types another ASCII letter.
            if pinSearchEnabled,
               keyCode == USKeyPosition.s,
               let typed = typedCharacter,
               !typed.unicodeScalars.allSatisfy({ $0.isASCII }) {
                return .pinSearch
            }
            return nil
        }
    }

    /// Key positions on the US keyboard, the fallback for layouts with no
    /// Latin letters of their own.
    private enum USKeyPosition {
        static let q: Int64 = 12
        static let w: Int64 = 13
        static let s: Int64 = 1
    }

    /// The plain letter a keystroke typed, when it typed one. Accents fold
    /// away, so a letter of a Latin alphabet is never mistaken for one of the
    /// keys above.
    private static func latinLetter(in text: String?) -> Character? {
        // No locale: in Turkish a dotted I folds to a dotless one, which is
        // not ASCII, so the guard below would throw the keystroke away and
        // that letter would simply stop searching.
        guard let folded = text?.folding(options: [.diacriticInsensitive, .caseInsensitive],
                                         locale: nil),
              folded.count == 1,
              let letter = folded.first,
              letter.isASCII,
              letter.isLetter
        else { return nil }
        return letter
    }

    static func filteredSearchIDs(records: [SwitcherSearchRecord], query: String) -> [String] {
        let tokens = normalizedSearchTokens(query)
        guard !tokens.isEmpty else { return records.map(\.id) }
        return records.compactMap { record in
            let haystack = normalizedSearchText([record.title, record.appName])
            return tokens.allSatisfy { haystack.contains($0) } ? record.id : nil
        }
    }

    static func searchSelectionIndex(itemIDs: [String],
                                     preferredID: String?,
                                     previousIndex: Int) -> Int {
        guard !itemIDs.isEmpty else { return 0 }
        if let preferredID,
           let index = itemIDs.firstIndex(of: preferredID) {
            return index
        }
        return clampedSelection(previousIndex, count: itemIDs.count)
    }

    private static func clampedSelection(_ index: Int, count: Int) -> Int {
        guard count > 0 else { return 0 }
        return min(max(0, index), count - 1)
    }

    private static func normalizedSearchTokens(_ query: String) -> [String] {
        normalizedSearchText([query])
            .split(whereSeparator: \.isWhitespace)
            .map(String.init)
    }

    private static func normalizedSearchText(_ parts: [String]) -> String {
        parts.joined(separator: " ")
            .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: nil)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
