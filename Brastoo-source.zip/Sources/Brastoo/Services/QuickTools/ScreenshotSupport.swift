// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Vorssaint

import Accelerate
import Carbon.HIToolbox
import CoreGraphics
import Foundation

/// The actions that share the screen-selection surface. Availability is read
/// when the chooser opens, so an uninstalled feature never leaves a dead mode
/// behind.
enum ScreenCaptureTool: String, CaseIterable {
    case screenshot
    case recording
    case text
    case color

    var shortcutKey: String {
        switch self {
        case .screenshot: return "1"
        case .recording: return "2"
        case .text: return "3"
        case .color: return "4"
        }
    }

    static func matchingShortcut(_ characters: String?) -> ScreenCaptureTool? {
        guard let characters else { return nil }
        return allCases.first { $0.shortcutKey == characters }
    }

    var feature: AppFeature {
        switch self {
        case .screenshot: return .screenshot
        case .recording: return .screenRecorder
        case .text: return .screenOCR
        case .color: return .colorPicker
        }
    }

    /// A tool's own global shortcut, which opens the chooser already on that
    /// mode. The screenshot tool's entry keeps the storage keys of the old
    /// general capture shortcut, so an existing combination keeps working
    /// unchanged under its new per-tool name.
    ///
    /// Every case must have a hotkey registered for it. `ScreenCaptureService`
    /// builds exactly one per case from this list, so a tool cannot gain a
    /// settings row whose key nothing registers, which is what left three of
    /// them doing nothing (issue #708).
    struct DedicatedShortcut {
        let role: GlobalShortcutRole
        let enabledKey: String
    }

    var dedicatedShortcut: DedicatedShortcut {
        switch self {
        case .screenshot:
            return DedicatedShortcut(role: .screenshot,
                                     enabledKey: DefaultsKey.screenshotShortcutEnabled)
        case .recording:
            return DedicatedShortcut(role: .screenRecorder,
                                     enabledKey: DefaultsKey.recorderShortcutEnabled)
        case .text:
            return DedicatedShortcut(role: .screenOCR,
                                     enabledKey: DefaultsKey.screenOCRShortcutEnabled)
        case .color:
            return DedicatedShortcut(role: .colorPicker,
                                     enabledKey: DefaultsKey.colorPickerShortcutEnabled)
        }
    }

    var showCaptureMenuOnShortcutKey: String {
        switch self {
        case .screenshot: return DefaultsKey.screenshotShowCaptureMenuOnShortcut
        case .recording: return DefaultsKey.recorderShowCaptureMenuOnShortcut
        case .text: return DefaultsKey.screenOCRShowCaptureMenuOnShortcut
        case .color: return DefaultsKey.colorPickerShowCaptureMenuOnShortcut
        }
    }

    func showsCaptureMenu(fromShortcut: Bool, defaults: UserDefaults = .standard) -> Bool {
        !fromShortcut || (defaults.object(forKey: showCaptureMenuOnShortcutKey) as? Bool ?? true)
    }

    /// A running recording blocks the capture menu, because picking recording
    /// from it would stop the take. A shortcut that skips the menu can only
    /// reach its own tool, so it may run on top of the recording.
    func opensDuringRecording(fromShortcut: Bool, defaults: UserDefaults = .standard) -> Bool {
        self != .recording && !showsCaptureMenu(fromShortcut: fromShortcut, defaults: defaults)
    }

    var systemImageName: String {
        switch self {
        case .screenshot: return "camera.viewfinder"
        case .recording: return "record.circle"
        case .text: return "text.viewfinder"
        case .color: return "eyedropper"
        }
    }

    /// Only the recorder writes sound, so its microphone and system-audio
    /// choices are the only tool controls that belong under the chooser.
    /// Every other mode leaves them out entirely, reserving no space for them.
    var capturesAudio: Bool { self == .recording }

    func settingsTitle(_ strings: Strings, language: AppLanguage) -> String {
        switch self {
        case .screenshot: return FeatureStrings.screenshot(language).pageTitle
        case .recording: return FeatureStrings.recorder(language).pageTitle
        case .text: return strings.ocrName
        case .color: return strings.colorPickerName
        }
    }

    static func available(isAvailable: (AppFeature) -> Bool = { $0.isAvailable })
        -> [ScreenCaptureTool] {
        allCases.filter { isAvailable($0.feature) }
    }
}

/// Pure logic for the screenshot tool: capture routing, selection geometry,
/// coordinate conversions between the window server, screens and image
/// pixels, the annotation model and file naming. No AppKit so the unit test
/// harness compiles it standalone.
enum ScreenshotSupport {

    struct UnifiedCapturePolicy: Equatable {
        let freeze: Bool
        let includePointer: Bool
        let hideBrastooWindows: Bool
        /// Whether editors and pinned captures stay out of the picture and the
        /// pickable windows. Recording keeps them out even while "Hide
        /// Brastoo windows" is off, which that flag alone cannot tell apart.
        let keepsContentWindowsOut: Bool
        let usesGeometry: Bool

        /// Two tools can want the same photograph and still do different
        /// things with it, so only the fields that decide which pixels are
        /// taken, and which windows can be picked, force a new one.
        func sharesSource(with other: UnifiedCapturePolicy) -> Bool {
            freeze == other.freeze
                && includePointer == other.includePointer
                && hideBrastooWindows == other.hideBrastooWindows
                && keepsContentWindowsOut == other.keepsContentWindowsOut
        }
    }

    static func unifiedCapturePolicy(for tool: ScreenCaptureTool,
                                     screenshotFreeze: Bool,
                                     screenshotIncludePointer: Bool,
                                     screenshotHideBrastooWindows: Bool)
        -> UnifiedCapturePolicy {
        UnifiedCapturePolicy(
            freeze: tool == .screenshot ? screenshotFreeze : true,
            includePointer: tool == .screenshot && screenshotIncludePointer,
            hideBrastooWindows: tool != .recording && screenshotHideBrastooWindows,
            keepsContentWindowsOut: tool == .recording || screenshotHideBrastooWindows,
            usesGeometry: tool == .recording)
    }

    static func captureAvailabilityChanged(activeTools: [ScreenCaptureTool],
                                           availableTools: [ScreenCaptureTool]) -> Bool {
        activeTools != availableTools
    }

    static func captureRouteIsAuthorized(
        selected: ScreenCaptureTool,
        isAvailable: (AppFeature) -> Bool = { $0.isAvailable }
    ) -> Bool {
        isAvailable(selected.feature)
    }

    static func selectionDimAlpha(notchControls: Bool, isFrozen: Bool, isDragging: Bool) -> CGFloat {
        if notchControls { return isDragging ? 0.18 : 0 }
        return isFrozen ? 0.22 : 0.18
    }

    static func captureGuideIsVisible(pointerOnDisplay: Bool,
                                      selectionInProgress: Bool,
                                      capturePending: Bool) -> Bool {
        pointerOnDisplay && !selectionInProgress && !capturePending
    }

    static func fullScreenCaptureControlIsAvailable(selectedTool: ScreenCaptureTool?,
                                                    standaloneScreenshot: Bool,
                                                    requiresDraggedRegion: Bool,
                                                    scrollingCaptureEnabled: Bool) -> Bool {
        let isScreenshot = standaloneScreenshot || selectedTool == .screenshot
        return isScreenshot && !requiresDraggedRegion && !scrollingCaptureEnabled
    }

    static func fullScreenCaptureControlIsVisible(isAvailable: Bool,
                                                  pointerOnDisplay: Bool,
                                                  selectionInProgress: Bool,
                                                  capturePending: Bool) -> Bool {
        isAvailable && pointerOnDisplay && !selectionInProgress && !capturePending
    }

    static func fullScreenCaptureControlTopInset(screenChromeHeight: CGFloat,
                                                 notchControlsHeight: CGFloat?) -> CGFloat {
        let chrome = screenChromeHeight.isFinite ? max(0, screenChromeHeight) : 0
        let controls = notchControlsHeight.flatMap { $0.isFinite ? max(0, $0) : nil } ?? 0
        return max(chrome, controls) + 12
    }

    /// Whether the guide should advertise repeating the last capture region.
    /// The region is remembered for this app session only and belongs to one
    /// display, so the hint stays hidden until pressing the key would really
    /// capture something.
    static func offersRepeatLastRegion(isPickingColor: Bool,
                                       storedRegionDisplayIsAvailable: Bool) -> Bool {
        !isPickingColor && storedRegionDisplayIsAvailable
    }

    // MARK: - Preferences

    static let recentCaptureLimit = 12
    static let recentCaptureMaximumBytes: Int64 = 256 * 1024 * 1024

    static func isRecentCaptureCacheFileName(_ name: String) -> Bool {
        guard name == URL(fileURLWithPath: name).lastPathComponent,
              name.lowercased().hasSuffix(".png") else { return false }
        let stem = String(name.dropLast(4))
        if UUID(uuidString: stem) != nil { return true }
        let suffix = "-thumbnail"
        return stem.hasSuffix(suffix)
            && UUID(uuidString: String(stem.dropLast(suffix.count))) != nil
    }

    static func cappedRecentCaptureIDs(_ ids: [UUID],
                                       screenshotBytes: [UUID: Int64] = [:]) -> [UUID] {
        var kept: [UUID] = []
        var bytes: Int64 = 0
        var keptScreenshot = false
        for id in ids.prefix(recentCaptureLimit) {
            guard let size = screenshotBytes[id] else {
                kept.append(id)
                continue
            }
            let safeSize = max(0, size)
            if keptScreenshot, bytes + safeSize > recentCaptureMaximumBytes { continue }
            kept.append(id)
            keptScreenshot = true
            bytes += safeSize
        }
        return kept
    }

    /// Optional countdown before the capture starts, so menus, tooltips and
    /// hover states can be staged first.
    static let allowedDelays = [0, 3, 5, 10]

    static func sanitizedDelay(_ raw: Int) -> Int {
        allowedDelays.contains(raw) ? raw : 0
    }

    static let confirmationPreviewDurations = [1, 2, 3, 5, 10, 0]
    static let defaultConfirmationPreviewDuration = 3
    static let recoveryPreviewDismissInterval: TimeInterval = 12

    struct ConfirmationPreviewPresentationPolicy: Equatable {
        let takesFocus: Bool
        let closesOnCollapse: Bool
        let showsDismissButton: Bool
    }

    static func sanitizedConfirmationPreviewDuration(_ raw: Int) -> Int {
        confirmationPreviewDurations.contains(raw) ? raw : defaultConfirmationPreviewDuration
    }

    static func confirmationPreviewDismissInterval(_ raw: Int) -> TimeInterval? {
        let duration = sanitizedConfirmationPreviewDuration(raw)
        return duration == 0 ? nil : TimeInterval(duration)
    }

    static func sharedPreviewDismissInterval(base: TimeInterval?) -> TimeInterval? {
        base == nil ? nil : 30
    }

    static func confirmationPreviewPresentationPolicy(
        dismissInterval: TimeInterval?,
        prefersFocus: Bool
    ) -> ConfirmationPreviewPresentationPolicy {
        let persistent = dismissInterval == nil
        return ConfirmationPreviewPresentationPolicy(
            takesFocus: !persistent && prefersFocus,
            closesOnCollapse: persistent,
            showsDismissButton: persistent)
    }

    static func confirmationPreviewPresentationPolicy(
        dismissInterval: TimeInterval?,
        defaults: UserDefaults
    ) -> ConfirmationPreviewPresentationPolicy {
        confirmationPreviewPresentationPolicy(
            dismissInterval: dismissInterval,
            prefersFocus: defaults.bool(forKey: DefaultsKey.screenshotPreviewTakesFocus))
    }

    static func automaticActionSucceeded(_ action: ScreenshotDefaultAction,
                                         saved: Bool,
                                         copied: Bool) -> Bool {
        switch action {
        case .none, .edit: return false
        case .save: return saved
        case .saveAndCopy: return saved && copied
        case .copy: return copied
        }
    }

    static func shouldShowQuickPreview(defaultAction: ScreenshotDefaultAction,
                                       saved: Bool,
                                       copied: Bool,
                                       confirmationEnabled: Bool) -> Bool {
        switch defaultAction {
        case .none: return true
        case .edit: return false
        case .save, .saveAndCopy, .copy:
            return confirmationEnabled
                || !automaticActionSucceeded(defaultAction, saved: saved, copied: copied)
        }
    }

    /// What a finished capture shows once its after-capture action ran.
    enum QuickPreviewPresentation: Equatable {
        case hidden
        /// A nil interval keeps the preview until it is dismissed.
        case shown(dismissInterval: TimeInterval?)
    }

    /// The whole decision `route` makes, read from the person's settings: a
    /// successful action shows the confirmation for its chosen duration or
    /// nothing at all, while a failed or partial action, or no action, gets
    /// the recovery preview with its longer timer.
    static func quickPreviewPresentation(defaultAction: ScreenshotDefaultAction,
                                         saved: Bool,
                                         copied: Bool,
                                         defaults: UserDefaults) -> QuickPreviewPresentation {
        guard shouldShowQuickPreview(
            defaultAction: defaultAction, saved: saved, copied: copied,
            confirmationEnabled: defaults.bool(forKey: DefaultsKey.screenshotPreviewEnabled))
        else { return .hidden }
        guard automaticActionSucceeded(defaultAction, saved: saved, copied: copied) else {
            return .shown(dismissInterval: recoveryPreviewDismissInterval)
        }
        // A stored value that is not a number reads as the default duration,
        // not as 0, which would keep every confirmation until dismissed.
        let duration = (defaults.object(forKey: DefaultsKey.screenshotPreviewDuration) as? NSNumber)?
            .intValue ?? defaultConfirmationPreviewDuration
        return .shown(dismissInterval: confirmationPreviewDismissInterval(duration))
    }

    /// Remaining stroke for the one-second countdown ring. Time drives the
    /// value directly so a delayed frame catches up instead of restarting the
    /// animation or leaving the ring frozen.
    static func countdownRingProgress(elapsed: TimeInterval,
                                      duration: TimeInterval = 0.92) -> CGFloat {
        guard elapsed.isFinite, duration.isFinite, duration > 0 else { return 0 }
        let fraction = min(max(elapsed / duration, 0), 1)
        return CGFloat(1 - fraction)
    }

    // MARK: - Scrolling capture

    /// A failed scroll target must never keep the capture alive forever or
    /// exhaust memory. Reaching a guard keeps the valid portion and explains
    /// why the capture stopped.
    static let scrollingCaptureMaximumDuration: TimeInterval = 120
    static let scrollingCaptureMaximumFrames = 512
    static let scrollingCaptureMaximumRetainedPixels = 60_000_000
    static let scrollingCaptureMaximumPixels = 60_000_000

    struct ScrollingSample: Equatable {
        let width: Int
        let height: Int
        let pixels: [UInt8]

        var isValid: Bool {
            width > 0 && height > 0 && pixels.count == width * height
        }
    }

    enum ScrollingDirection: Equatable {
        case forward
        case backward
    }

    enum ScrollingTransition: Equatable {
        case end
        case advanced(overlap: Int,
                      direction: ScrollingDirection,
                      contentColumns: Range<Int>)
        case unmatched
    }

    static func scrollingSamplesAreStable(_ previous: ScrollingSample,
                                          _ current: ScrollingSample,
                                          contentColumns: Range<Int>? = nil) -> Bool {
        previous.isValid && current.isValid
            && previous.width == current.width
            && previous.height == current.height
            && scrollingDifference(previous,
                                   current,
                                   columns: contentColumns ?? 0..<previous.width) <= 1.5
    }

    /// Finds how many rows two successive views share. The calculation is
    /// deliberately pure: captures only provide small grayscale samples and
    /// the exact same matching policy is exercised by the test harness.
    static func scrollingTransition(previous: ScrollingSample,
                                    current: ScrollingSample,
                                    contentColumns: Range<Int>? = nil) -> ScrollingTransition {
        guard previous.isValid, current.isValid,
              previous.width == current.width,
              previous.height == current.height,
              previous.height >= 24
        else { return .unmatched }

        let columns = contentColumns ?? 0..<previous.width
        guard columns.lowerBound >= 0,
              columns.upperBound <= previous.width,
              !columns.isEmpty
        else { return .unmatched }

        if scrollingSamplesAreStable(previous,
                                     current,
                                     contentColumns: columns) {
            return .end
        }

        let height = previous.height
        // The final scroll at the bottom of a page is often only a few rows.
        // Treating every advance below 18% as a mismatch discarded an otherwise
        // valid capture on short pages just before it could detect the end.
        let minimumAdvance = max(2, Int((Double(height) * 0.01).rounded()))
        let maximumAdvance = min(height - 8, Int((Double(height) * 0.88).rounded()))
        guard minimumAdvance <= maximumAdvance else { return .unmatched }

        struct Match {
            let advance: Int
            let reversed: Bool
            let contentColumns: Range<Int>
            let supportingTiles: Int
            let longestRun: Int
            let matchingRows: Int
            let difference: Double
        }

        let tiles = scrollingColumnTiles(in: columns, sampleWidth: previous.width)
        let movingTiles = tiles.filter {
            scrollingDifference(previous, current, columns: $0) > 1.5
        }
        guard !movingTiles.isEmpty else { return .unmatched }

        // Compute pixel differences in Accelerate, once per offset. The old
        // nested Swift pixel loops repeated the work for each tile and candidate
        // and took seconds per Retina frame in unoptimized Developer builds.
        let previousPixels = previous.pixels.map(Float.init)
        let currentPixels = current.pixels.map(Float.init)
        var differences = [Float](repeating: 0, count: previous.pixels.count)
        var matches: [Match] = []
        for advance in minimumAdvance...maximumAdvance {
            if Task.isCancelled { return .unmatched }
            for reversed in [false, true] {
                let count = (height - advance) * previous.width
                previousPixels.withUnsafeBufferPointer { lhs in
                    currentPixels.withUnsafeBufferPointer { rhs in
                        vDSP_vsub(rhs.baseAddress! + (reversed ? advance * previous.width : 0), 1,
                                  lhs.baseAddress! + (reversed ? 0 : advance * previous.width), 1,
                                  &differences, 1, vDSP_Length(count))
                    }
                }
                vDSP_vabs(differences, 1, &differences, 1, vDSP_Length(count))
                guard let match = scrollingCandidate(previous: previous,
                                                     advance: advance,
                                                     tiles: movingTiles,
                                                     differences: differences) else { continue }
                matches.append(Match(advance: advance,
                                     reversed: reversed,
                                     contentColumns: match.contentColumns,
                                     supportingTiles: match.supportingTiles,
                                     longestRun: match.longestRun,
                                     matchingRows: match.matchingRows,
                                     difference: match.difference))
            }
        }
        guard !matches.isEmpty else { return .unmatched }
        matches.sort {
            if $0.contentColumns.count != $1.contentColumns.count {
                return $0.contentColumns.count > $1.contentColumns.count
            }
            if $0.supportingTiles != $1.supportingTiles {
                return $0.supportingTiles > $1.supportingTiles
            }
            if $0.longestRun != $1.longestRun { return $0.longestRun > $1.longestRun }
            if $0.matchingRows != $1.matchingRows { return $0.matchingRows > $1.matchingRows }
            return $0.difference < $1.difference
        }

        let best = matches[0]
        let requiredRun = max(8, min(28, height / 12))
        guard best.longestRun >= requiredRun else {
            return .unmatched
        }

        // Repeated blank bands can look equally good at several offsets. A
        // unique match is required instead of guessing and creating a seam.
        if let rival = matches.dropFirst().first(where: {
            $0.reversed != best.reversed || abs($0.advance - best.advance) > 2
        }),
           rival.contentColumns.count >= best.contentColumns.count - 1,
           rival.supportingTiles >= best.supportingTiles - 1,
           rival.longestRun >= best.longestRun - 2,
           rival.matchingRows >= best.matchingRows - max(3, best.supportingTiles * 3),
           rival.difference <= best.difference + 0.75 {
            return .unmatched
        }
        return .advanced(overlap: height - best.advance,
                         direction: best.reversed ? .backward : .forward,
                         contentColumns: best.contentColumns)
    }

    /// A fixed footer stays at the same viewport rows while the page behind it
    /// advances. Keeping that suffix in every new strip repeats it throughout
    /// the final image, so identify it separately from the moving overlap.
    static func scrollingFixedBottomRows(previous: ScrollingSample,
                                         current: ScrollingSample,
                                         overlap: Int,
                                         contentColumns: Range<Int>) -> Int {
        guard previous.isValid, current.isValid,
              previous.width == current.width,
              previous.height == current.height,
              overlap > 0, overlap < previous.height,
              contentColumns.lowerBound >= 0,
              contentColumns.upperBound <= previous.width,
              !contentColumns.isEmpty
        else { return 0 }

        var rows = 0
        for row in stride(from: previous.height - 1, through: 0, by: -1) {
            let start = row * previous.width
            var difference = 0
            for column in contentColumns {
                difference += abs(Int(previous.pixels[start + column])
                    - Int(current.pixels[start + column]))
            }
            let average = Double(difference) / Double(contentColumns.count)
            guard average <= 2 else { break }
            rows += 1
        }

        let minimumRows = max(4, min(12, previous.height / 100))
        guard rows >= minimumRows, rows < overlap else { return 0 }
        return rows
    }

    /// Rows newly revealed by a forward scroll. A fixed footer shifts this
    /// range upward by its own height; its pixels are appended once at the end.
    static func scrollingNewContentRows(imageHeight: Int,
                                        overlap: Int,
                                        fixedBottomRows: Int) -> Range<Int>? {
        guard imageHeight > 0,
              overlap > 0, overlap < imageHeight,
              fixedBottomRows >= 0, fixedBottomRows < overlap
        else { return nil }
        return (overlap - fixedBottomRows)..<(imageHeight - fixedBottomRows)
    }

    private static func scrollingDifference(_ lhs: ScrollingSample,
                                            _ rhs: ScrollingSample,
                                            columns: Range<Int>) -> Double {
        guard columns.lowerBound >= 0,
              columns.upperBound <= lhs.width,
              !columns.isEmpty else { return .infinity }
        let topInset = max(0, lhs.height / 24)
        var difference = 0
        var count = 0
        for row in topInset..<(lhs.height - topInset) {
            let start = row * lhs.width
            for column in columns {
                difference += abs(Int(lhs.pixels[start + column])
                    - Int(rhs.pixels[start + column]))
                count += 1
            }
        }
        return count > 0 ? Double(difference) / Double(count) : .infinity
    }

    private struct ScrollingCandidate {
        let contentColumns: Range<Int>
        let supportingTiles: Int
        let longestRun: Int
        let matchingRows: Int
        let difference: Double
    }

    private static func scrollingColumnTiles(in columns: Range<Int>,
                                             sampleWidth: Int) -> [Range<Int>] {
        let tileWidth = max(2, sampleWidth / 8)
        var tiles: [Range<Int>] = []
        var lower = columns.lowerBound
        while lower < columns.upperBound {
            let upper = min(columns.upperBound, lower + tileWidth)
            if upper - lower >= 2 || tiles.isEmpty {
                tiles.append(lower..<upper)
            }
            lower = upper
        }
        return tiles
    }

    private static func scrollingCandidate(previous: ScrollingSample,
                                           advance: Int,
                                           tiles: [Range<Int>],
                                           differences: [Float]) -> ScrollingCandidate? {
        let requiredRun = max(8, min(28, previous.height / 12))
        let matches = tiles.map { tile -> (Range<Int>, ScrollingRowMatch?) in
            guard let match = scrollingMatch(previous: previous,
                                              advance: advance,
                                              columns: tile,
                                              differences: differences),
                  match.longestRun >= requiredRun,
                  match.matchingRows >= max(requiredRun, match.comparedRows / 3)
            else { return (tile, nil) }
            return (tile, match)
        }

        let minimumTiles = matches.count >= 3 ? 2 : 1
        var runs: [[(Range<Int>, ScrollingRowMatch)]] = []
        var run: [(Range<Int>, ScrollingRowMatch)] = []
        var skippedOneTile = false
        for (tile, match) in matches {
            if let match {
                run.append((tile, match))
            } else if !run.isEmpty, !skippedOneTile {
                skippedOneTile = true
            } else {
                if !run.isEmpty { runs.append(run) }
                run = []
                skippedOneTile = false
            }
        }
        if !run.isEmpty { runs.append(run) }

        return runs.compactMap { supported -> ScrollingCandidate? in
            guard supported.count >= minimumTiles,
                  let first = supported.first,
                  let last = supported.last else { return nil }
            let contentColumns = first.0.lowerBound..<last.0.upperBound
            guard let combined = scrollingMatch(previous: previous,
                                                 advance: advance,
                                                 columns: contentColumns,
                                                 differences: differences),
                  combined.longestRun >= requiredRun,
                  combined.matchingRows >= max(requiredRun, combined.comparedRows / 3)
            else { return nil }
            return ScrollingCandidate(contentColumns: contentColumns,
                                      supportingTiles: supported.count,
                                      longestRun: combined.longestRun,
                                      matchingRows: combined.matchingRows,
                                      difference: combined.difference)
        }.max {
            if $0.contentColumns.count != $1.contentColumns.count {
                return $0.contentColumns.count < $1.contentColumns.count
            }
            if $0.matchingRows != $1.matchingRows {
                return $0.matchingRows < $1.matchingRows
            }
            return $0.difference > $1.difference
        }
    }

    private struct ScrollingRowMatch {
        let longestRun: Int
        let matchingRows: Int
        let comparedRows: Int
        let difference: Double
    }

    private static func scrollingMatch(previous: ScrollingSample,
                                       advance: Int,
                                       columns: Range<Int>,
                                       differences: [Float]) -> ScrollingRowMatch? {
        let width = previous.width
        let edgeInset = max(2, previous.height / 10)
        let lastRow = previous.height - advance - edgeInset
        guard lastRow > edgeInset,
              columns.lowerBound >= 0,
              columns.upperBound <= width,
              !columns.isEmpty else { return nil }

        let rowCount = lastRow - edgeInset
        var rowDifferences = [Float](repeating: 0, count: rowCount)
        let weights = [Float](repeating: 1, count: columns.count)
        differences.withUnsafeBufferPointer { buffer in
            vDSP_desamp(buffer.baseAddress! + edgeInset * width + columns.lowerBound,
                        vDSP_Stride(width), weights, &rowDifferences,
                        vDSP_Length(rowCount), vDSP_Length(columns.count))
        }
        var longestRun = 0
        var run = 0
        var matchingRows = 0
        let threshold = Float(columns.count * 8)
        rowDifferences.withUnsafeBufferPointer { rows in
            var row = 0
            while row < rowCount {
                if rows[row] <= threshold {
                    run += 1
                    matchingRows += 1
                    if run > longestRun { longestRun = run }
                } else {
                    run = 0
                }
                row += 1
            }
        }
        var totalDifference: Float = 0
        vDSP_sve(rowDifferences, 1, &totalDifference, vDSP_Length(rowCount))
        return ScrollingRowMatch(longestRun: longestRun,
                                 matchingRows: matchingRows,
                                 comparedRows: rowCount,
                                 difference: Double(totalDifference) / Double(rowCount * columns.count))
    }

    static func scrollingPixelRange(sampleColumns: Range<Int>,
                                    sampleWidth: Int,
                                    imageWidth: Int) -> Range<Int>? {
        guard sampleWidth > 0, imageWidth > 0,
              sampleColumns.lowerBound >= 0,
              sampleColumns.upperBound <= sampleWidth,
              !sampleColumns.isEmpty else { return nil }
        let lower = sampleColumns.lowerBound * imageWidth / sampleWidth
        let upper = (sampleColumns.upperBound * imageWidth + sampleWidth - 1) / sampleWidth
        guard lower >= 0, upper <= imageWidth, lower < upper else { return nil }
        return lower..<upper
    }

    /// Restores the pixels-per-point scale stored as standard PNG DPI.
    static func captureScale(fromDPI dpi: Double?) -> CGFloat? {
        guard let dpi, dpi.isFinite else { return nil }
        let scale = dpi / 72
        guard (0.5...4).contains(scale) else { return nil }
        return CGFloat(scale)
    }

    /// Uses the logical size carried by a copied image when it describes one
    /// consistent display scale. Imported files without that metadata edit at 1x.
    static func clipboardImageScale(pixelSize: CGSize, pointSize: CGSize) -> CGFloat {
        guard pixelSize.width > 0, pixelSize.height > 0,
              pointSize.width > 0, pointSize.height > 0
        else { return 1 }
        let horizontal = pixelSize.width / pointSize.width
        let vertical = pixelSize.height / pointSize.height
        guard horizontal.isFinite, vertical.isFinite,
              abs(horizontal - vertical) <= max(horizontal, vertical) * 0.05
        else { return 1 }
        return captureScale(fromDPI: Double((horizontal + vertical) / 2) * 72) ?? 1
    }

    // MARK: - Selection geometry

    /// Rectangle between two drag points. `square` constrains to the largest
    /// square that fits the drag; `fromCenter` treats the origin as the
    /// center when Option is held.
    static func selectionRect(from origin: CGPoint,
                              to current: CGPoint,
                              square: Bool = false,
                              fromCenter: Bool = false) -> CGRect {
        var dx = current.x - origin.x
        var dy = current.y - origin.y
        if square {
            let side = max(abs(dx), abs(dy))
            dx = dx < 0 ? -side : side
            dy = dy < 0 ? -side : side
        }
        if fromCenter {
            return CGRect(x: origin.x - abs(dx), y: origin.y - abs(dy),
                          width: abs(dx) * 2, height: abs(dy) * 2)
        }
        return CGRect(x: min(origin.x, origin.x + dx),
                      y: min(origin.y, origin.y + dy),
                      width: abs(dx), height: abs(dy))
    }

    /// A full-image crop cannot move, so an interior drag must start a new
    /// selection. Dragging outside an existing crop replaces it as well.
    static func startsNewCropSelection(at point: CGPoint,
                                       draft: CGRect,
                                       within bounds: CGRect) -> Bool {
        bounds.contains(point)
            && (draft.standardized == bounds.standardized || !draft.contains(point))
    }

    /// A captured image's alpha, top row first.
    struct AlphaCoverage {
        let alpha: [UInt8]
        let width: Int
        let height: Int

        /// Total alpha inside `rect`, in image pixels from the top left.
        func sum(in rect: CGRect) -> Int {
            let area = rect.integral.intersection(CGRect(x: 0, y: 0, width: width, height: height))
            guard !area.isNull, !area.isEmpty else { return 0 }
            var total = 0
            for row in Int(area.minY)..<Int(area.maxY) {
                let start = row * width
                for column in Int(area.minX)..<Int(area.maxX) { total += Int(alpha[start + column]) }
            }
            return total
        }
    }

    /// Where a display capture of only some windows put them. Older systems
    /// draw each window where it sits on the display. macOS 27 packs the
    /// included windows into the image's top-left corner, keeping their
    /// relative layout, so cropping at the window's place on screen kept only
    /// its lower-right part beside empty space. Everything but those windows
    /// is transparent, so
    /// the placement that holds more of them is the one the system used.
    static func attachedCaptureCrop(placed: CGRect, packed: CGRect,
                                    coverage: AlphaCoverage) -> CGRect {
        coverage.sum(in: packed) > coverage.sum(in: placed) ? packed : placed
    }

    static func clamp(_ rect: CGRect, to bounds: CGRect) -> CGRect {
        var result = rect.intersection(bounds)
        if result.isNull { result = .zero }
        return result
    }

    /// A press that never travelled beyond this is a click, which captures
    /// the window under the cursor instead of a region.
    static let clickDragThreshold: CGFloat = 4

    static func isClick(from origin: CGPoint, to end: CGPoint) -> Bool {
        abs(end.x - origin.x) < clickDragThreshold && abs(end.y - origin.y) < clickDragThreshold
    }

    /// Whether the selection surface should still answer the pointer. Once a
    /// capture is on its way, or the session is over, every remaining event
    /// has to do nothing: the surface has already left the screen and the
    /// picture is being taken. Gestures that end with more than one release,
    /// like a drag made with three fingers, deliver exactly those late events.
    static func selectionAcceptsPointerInput(sessionIsOver: Bool, capturePending: Bool) -> Bool {
        !sessionIsOver && !capturePending
    }

    // MARK: - Coordinate conversions

    /// Window-server rectangles (top-left origin, global) into Cocoa global
    /// coordinates (bottom-left origin). `mainScreenHeight` is the height of
    /// the primary screen, which anchors both systems.
    static func cocoaRect(fromWindowServer rect: CGRect, mainScreenHeight: CGFloat) -> CGRect {
        CGRect(x: rect.origin.x,
               y: mainScreenHeight - rect.maxY,
               width: rect.width,
               height: rect.height)
    }

    /// A Cocoa global rectangle into the coordinates of a top-left-origin
    /// (flipped) view that covers `screenFrame` exactly.
    static func flippedViewRect(fromCocoa rect: CGRect, screenFrame: CGRect) -> CGRect {
        CGRect(x: rect.minX - screenFrame.minX,
               y: screenFrame.maxY - rect.maxY,
               width: rect.width,
               height: rect.height)
    }

    /// A rectangle in a flipped screen overlay back into Cocoa global
    /// coordinates. This anchors transient controls beside the captured area.
    static func cocoaRect(fromFlippedView rect: CGRect, screenFrame: CGRect) -> CGRect {
        CGRect(x: screenFrame.minX + rect.minX,
               y: screenFrame.maxY - rect.maxY,
               width: rect.width,
               height: rect.height)
    }

    /// A rectangle in a flipped view of `viewSize` points mapped onto an
    /// image of `imageSize` pixels covering the same area, rounded outward to
    /// whole pixels and clamped to the image.
    static func imagePixelRect(fromView rect: CGRect,
                               viewSize: CGSize,
                               imageSize: CGSize) -> CGRect {
        guard viewSize.width > 0, viewSize.height > 0 else { return .zero }
        let scaleX = imageSize.width / viewSize.width
        let scaleY = imageSize.height / viewSize.height
        let scaled = CGRect(x: rect.minX * scaleX,
                            y: rect.minY * scaleY,
                            width: rect.width * scaleX,
                            height: rect.height * scaleY).integral
        return clamp(scaled, to: CGRect(origin: .zero, size: imageSize))
    }

    /// A point in the flipped full-screen overlay mapped to the source
    /// image. Keeping this separate from rectangle rounding lets a pixel
    /// loupe follow the pointer without jumping by whole selections.
    static func imagePixelPoint(fromView point: CGPoint,
                                viewSize: CGSize,
                                imageSize: CGSize) -> CGPoint {
        guard viewSize.width > 0, viewSize.height > 0 else { return .zero }
        return CGPoint(x: min(max(point.x / viewSize.width * imageSize.width, 0),
                              imageSize.width),
                       y: min(max(point.y / viewSize.height * imageSize.height, 0),
                              imageSize.height))
    }

    // MARK: - Quick preview placement

    enum QuickPreviewPosition: String, CaseIterable {
        case automatic = ""
        case topLeft
        case topRight
        case bottomLeft
        case bottomRight
    }

    /// Picks the display containing most of the capture. The pointer breaks
    /// an exact tie and is also the fallback when a display was disconnected
    /// or rearranged before the preview appears.
    static func quickPreviewVisibleFrame(
        anchor: CGRect,
        pointer: CGPoint,
        screens: [(frame: CGRect, visibleFrame: CGRect)],
        fallback: CGRect
    ) -> CGRect {
        var selected: (frame: CGRect, visibleFrame: CGRect)?
        var selectedArea: CGFloat = 0
        for screen in screens {
            let overlap = anchor.intersection(screen.frame)
            let area = overlap.isNull ? 0 : max(0, overlap.width) * max(0, overlap.height)
            let winsTie = area == selectedArea
                && area > 0
                && NSMouseInRect(pointer, screen.frame, false)
                && !(selected.map { NSMouseInRect(pointer, $0.frame, false) } ?? false)
            if area > selectedArea || winsTie {
                selected = screen
                selectedArea = area
            }
        }
        if let selected { return selected.visibleFrame }
        return screens.first { NSMouseInRect(pointer, $0.frame, false) }?.visibleFrame ?? fallback
    }

    /// Places the capture preview beside the selection in automatic mode, or
    /// in the selected display corner, and clamps it to the visible frame.
    static func quickPreviewFrame(size: CGSize,
                                  anchor: CGRect,
                                  pointer: CGPoint,
                                  visibleFrame: CGRect,
                                  position: QuickPreviewPosition = .automatic) -> CGRect {
        let inset: CGFloat = position == .automatic ? 10 : 16
        let usable = visibleFrame.insetBy(dx: inset, dy: inset)

        if position != .automatic {
            let x: CGFloat
            let y: CGFloat
            switch position {
            case .automatic, .bottomRight:
                x = max(usable.minX, usable.maxX - size.width)
                y = usable.minY
            case .topLeft:
                x = usable.minX
                y = max(usable.minY, usable.maxY - size.height)
            case .topRight:
                x = max(usable.minX, usable.maxX - size.width)
                y = max(usable.minY, usable.maxY - size.height)
            case .bottomLeft:
                x = usable.minX
                y = usable.minY
            }
            return CGRect(origin: CGPoint(x: x, y: y), size: size)
        }

        let gap: CGFloat = 14
        var x = anchor.maxX + gap
        if x + size.width > usable.maxX {
            x = anchor.minX - size.width - gap
        }
        if x < usable.minX || x + size.width > usable.maxX {
            x = pointer.x + gap
        }

        var y = anchor.midY - size.height / 2
        if y < usable.minY || y + size.height > usable.maxY {
            let below = anchor.minY - size.height - gap
            let above = anchor.maxY + gap
            if below >= usable.minY {
                y = below
            } else if above + size.height <= usable.maxY {
                y = above
            } else {
                y = pointer.y - size.height / 2
            }
        }

        x = min(max(x, usable.minX), max(usable.minX, usable.maxX - size.width))
        y = min(max(y, usable.minY), max(usable.minY, usable.maxY - size.height))
        return CGRect(origin: CGPoint(x: x, y: y), size: size)
    }

    // MARK: - Editor layout

    /// A fresh editor should be large enough for its controls and canvas,
    /// while still fitting compact or rotated displays.
    static func editorMinimumContentSize(visibleSize: CGSize) -> CGSize {
        CGSize(width: min(visibleSize.width,
                          min(980, max(760, visibleSize.width * 0.76))),
               height: min(visibleSize.height,
                           min(680, max(560, visibleSize.height * 0.72))))
    }

    /// Initial content size for an editor window. Large captures fit inside
    /// the display and small captures still open on a comfortable canvas.
    static func editorContentSize(imagePointSize: CGSize,
                                  visibleSize: CGSize) -> CGSize {
        let chrome = CGSize(width: 96, height: 140)
        let minimum = editorMinimumContentSize(visibleSize: visibleSize)
        let maximum = CGSize(width: max(minimum.width, visibleSize.width * 0.90),
                             height: max(minimum.height, visibleSize.height * 0.88))
        let fit = min(1,
                      min((maximum.width - chrome.width) / max(imagePointSize.width, 1),
                          (maximum.height - chrome.height) / max(imagePointSize.height, 1)))
        let preferred = CGSize(width: imagePointSize.width * fit + chrome.width,
                               height: imagePointSize.height * fit + chrome.height)
        return CGSize(width: min(maximum.width, max(minimum.width, preferred.width)),
                      height: min(maximum.height, max(minimum.height, preferred.height)))
    }

    /// Local key monitors normally receive the editor's window number, but
    /// AppKit can clear it while resolving a main-menu key equivalent such as
    /// Command-Z. In that case the key window still owns the event. Never use
    /// the fallback for an event that explicitly belongs to another window.
    static func editorOwnsKeyEvent(eventWindowNumber: Int,
                                   editorWindowNumber: Int,
                                   editorIsKey: Bool) -> Bool {
        guard editorWindowNumber != 0 else { return false }
        if eventWindowNumber == editorWindowNumber { return true }
        return eventWindowNumber == 0 && editorIsKey
    }

    // MARK: - Window picking

    struct PickableWindow: Equatable {
        let windowID: UInt32
        /// Frame in the flipped coordinates of the overlay's own view.
        let frame: CGRect
    }

    /// First window whose frame contains the point; the list keeps the window
    /// server's front-to-back order, so the visible window wins.
    static func window(at point: CGPoint, in windows: [PickableWindow]) -> PickableWindow? {
        windows.first { $0.frame.contains(point) }
    }

    // MARK: - File naming

    /// Stable local file name with a localizable prefix and colon-free time.
    static func fileName(prefix: String, date: Date, fileExtension: String = "png") -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd 'at' HH.mm.ss"
        return "\(prefix) \(formatter.string(from: date)).\(fileExtension)"
    }

    /// Marks a saved capture the way macOS marks its own screenshots, so
    /// Spotlight and the Cleaner's forgotten screenshots treat both alike.
    /// Best effort: an unmarked file is only never offered for cleaning.
    static func markAsScreenCapture(_ url: URL) {
        guard let data = try? PropertyListSerialization.data(fromPropertyList: true,
                                                             format: .binary,
                                                             options: 0) else { return }
        url.withUnsafeFileSystemRepresentation { path in
            guard let path else { return }
            _ = data.withUnsafeBytes {
                setxattr(path, "com.apple.metadata:kMDItemIsScreenCapture",
                         $0.baseAddress, data.count, 0, XATTR_NOFOLLOW)
            }
        }
    }

    /// Writes one drag payload into its own temporary directory. Separate
    /// directories keep captures made in the same second from replacing each
    /// other while either drag is still in flight.
    static func temporaryDragFile(data: Data, name: String,
                                  directory: URL = FileManager.default.temporaryDirectory) throws -> URL {
        let folder = directory.appendingPathComponent("ScreenshotDrag-\(UUID().uuidString)",
                                                       isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let url = folder.appendingPathComponent((name as NSString).lastPathComponent)
        try data.write(to: url, options: .atomic)
        return url
    }

    /// Keeps copied captures available long enough for paste targets that read
    /// the file after accepting its URL from the pasteboard.
    static func copiedFile(data: Data, name: String, directory: URL) throws -> URL {
        guard Int64(data.count) <= copiedFileMaximumBytes else {
            throw CocoaError(.fileWriteOutOfSpace)
        }
        return try copiedFileLock.withLock {
            let manager = FileManager.default
            try preparePrivateCacheDirectory(directory, manager: manager)
            let safeName = (name as NSString).lastPathComponent
            let uniqueName = uniqueFileName(safeName) { candidate in
                manager.fileExists(atPath: directory.appendingPathComponent(candidate).path)
            }
            let url = directory.appendingPathComponent(uniqueName)
            try data.write(to: url, options: .atomic)
            try manager.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
            return url
        }
    }

    static func copiedFilesDirectory(fileManager: FileManager = .default,
                                     bundle: Bundle = .main) -> URL? {
        guard let base = fileManager.urls(for: .cachesDirectory, in: .userDomainMask).first,
              let bundleID = bundle.bundleIdentifier else { return nil }
        return base.appendingPathComponent(bundleID, isDirectory: true)
            .appendingPathComponent("Copied Screenshots", isDirectory: true)
    }

    static func isCopiedScreenshot(_ url: URL, in directory: URL) -> Bool {
        let file = url.standardizedFileURL
        let root = directory.standardizedFileURL
        guard file.deletingLastPathComponent().path == root.path,
              file.pathExtension.lowercased() == "png",
              let rootValues = try? root.resourceValues(
                forKeys: [.isDirectoryKey, .isSymbolicLinkKey]),
              rootValues.isDirectory == true,
              rootValues.isSymbolicLink != true,
              let values = try? file.resourceValues(
                forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
        else { return false }
        return values.isRegularFile == true && values.isSymbolicLink != true
    }

    struct CopiedFilePruneCandidate: Equatable {
        let url: URL
        let date: Date
        let bytes: Int64
    }

    private static let copiedFileLock = NSLock()
    private static let copiedFileMaximumCount = 100
    private static let copiedFileMaximumBytes: Int64 = 256 * 1024 * 1024

    private static func preparePrivateCacheDirectory(_ directory: URL,
                                                     manager: FileManager) throws {
        try manager.createDirectory(at: directory, withIntermediateDirectories: true)
        let values = try directory.resourceValues(
            forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        guard values.isDirectory == true, values.isSymbolicLink != true else {
            throw CocoaError(.fileWriteInvalidFileName)
        }
        try manager.setAttributes([.posixPermissions: 0o700], ofItemAtPath: directory.path)
    }

    static func copiedFilePruneVictims(_ files: [CopiedFilePruneCandidate],
                                       preserving current: URL,
                                       maximumCount: Int,
                                       maximumBytes: Int64) -> [URL] {
        let currentPath = current.standardizedFileURL.path
        guard let currentFile = files.first(where: {
            $0.url.standardizedFileURL.path == currentPath
        }) else { return [] }
        var count = 1
        var bytes = max(0, currentFile.bytes)
        var victims: [URL] = []
        for file in files.sorted(by: {
            $0.date == $1.date
                ? $0.url.standardizedFileURL.path < $1.url.standardizedFileURL.path
                : $0.date > $1.date
        })
            where file.url.standardizedFileURL.path != currentPath {
            if count < maximumCount
                && file.bytes >= 0
                && bytes <= maximumBytes
                && file.bytes <= maximumBytes - bytes {
                count += 1
                bytes += file.bytes
            } else {
                victims.append(file.url)
            }
        }
        return victims
    }

    /// Applies the cache bounds only after `current` has reached the pasteboard.
    /// A stale render may finish later, but it can never evict the published URL.
    static func pruneCopiedFiles(in directory: URL, preserving current: URL,
                                 now: Date = Date()) {
        copiedFileLock.withLock {
            let manager = FileManager.default
            guard isCopiedScreenshot(current, in: directory) else { return }
            let keys: Set<URLResourceKey> = [
                .contentModificationDateKey, .fileSizeKey, .isRegularFileKey, .isSymbolicLinkKey,
            ]
            guard let children = try? manager.contentsOfDirectory(
                at: directory, includingPropertiesForKeys: Array(keys)) else { return }
            let files = children.compactMap { url -> CopiedFilePruneCandidate? in
                guard url.pathExtension.lowercased() == "png",
                      let values = try? url.resourceValues(forKeys: keys),
                      values.isRegularFile == true,
                      values.isSymbolicLink != true else { return nil }
                return CopiedFilePruneCandidate(
                    url: url,
                    date: values.contentModificationDate ?? .distantPast,
                    bytes: Int64(values.fileSize ?? 0))
            }
            let currentPath = current.standardizedFileURL.path
            let cutoff = now.addingTimeInterval(-24 * 3600)
            let expired = files.filter {
                $0.url.standardizedFileURL.path != currentPath && $0.date < cutoff
            }
            let expiredURLs = Set(expired.map(\.url))
            let currentFiles = files.filter { !expiredURLs.contains($0.url) }
            let budgetVictims = copiedFilePruneVictims(
                currentFiles,
                preserving: current,
                maximumCount: copiedFileMaximumCount,
                maximumBytes: copiedFileMaximumBytes
            )
            for victim in expired.map(\.url) + budgetVictims {
                try? manager.removeItem(at: victim)
            }
        }
    }

    static func removeTemporaryDragDirectories(
        directory: URL = FileManager.default.temporaryDirectory
    ) {
        let manager = FileManager.default
        guard let children = try? manager.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles]
        ) else { return }
        let prefix = "ScreenshotDrag-"
        for child in children {
            let name = child.lastPathComponent
            guard name.hasPrefix(prefix),
                  UUID(uuidString: String(name.dropFirst(prefix.count))) != nil,
                  let values = try? child.resourceValues(
                    forKeys: [.isDirectoryKey, .isSymbolicLinkKey]),
                  values.isDirectory == true,
                  values.isSymbolicLink != true else { continue }
            try? manager.removeItem(at: child)
        }
    }

    /// Expands a date-token pattern into a relative subfolder path, e.g.
    /// "%y-%mo" becomes "24-03" and "%year/%month" becomes "2024/March".
    /// Slashes in the pattern become nested folders. The result never
    /// escapes the base folder: empty, "." and ".." components are dropped.
    /// An empty pattern expands to an empty string, meaning no subfolder.
    static func expandSaveSubfolder(_ pattern: String, date: Date) -> String {
        guard !pattern.isEmpty else { return "" }
        return applyingDateTokens(pattern, date: date)
            .split(separator: "/")
            .map(String.init)
            .filter { !$0.isEmpty && $0 != "." && $0 != ".." }
            .joined(separator: "/")
    }
    /// Expands a non-empty file name pattern with the same date tokens as
    /// `expandSaveSubfolder`, plus "%#" (and "%##", "%###", …) for an
    /// auto-incrementing, zero-padded number. Slashes and colons would nest
    /// folders or fail the write, so they become dashes. Callers are
    /// responsible for falling back to the default name when the pattern is
    /// blank, and for appending the file extension.
    static func expandFileNamePattern(_ pattern: String, date: Date, number: Int) -> String {
        let withDate = applyingDateTokens(pattern, date: date)
        return applyingNumberTokens(withDate, number: number)
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
    }
    /// Whether a file name pattern actually uses the number sequence, so
    /// callers know whether to advance and persist it.
    static func fileNamePatternUsesNumber(_ pattern: String) -> Bool {
        pattern.contains("%#")
    }
    private static func applyingDateTokens(_ pattern: String, date: Date) -> String {
        let calendar = Calendar(identifier: .gregorian)
        let parts = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)
        let year = parts.year ?? 0
        // Longer tokens are substituted first so "%year"/"%month" don't get
        // clobbered by their short prefixes "%y"/"%mo" during replacement.
        let tokens: [(String, String)] = [
            ("%year", String(format: "%04d", year)),
            ("%month", monthName(parts.month ?? 1)),
            ("%y", String(format: "%02d", year % 100)),
            ("%mo", String(format: "%02d", parts.month ?? 0)),
            ("%d", String(format: "%02d", parts.day ?? 0)),
            ("%h", String(format: "%02d", parts.hour ?? 0)),
            ("%mi", String(format: "%02d", parts.minute ?? 0)),
            ("%s", String(format: "%02d", parts.second ?? 0))
        ]
        var result = pattern
        for (token, value) in tokens {
            result = result.replacingOccurrences(of: token, with: value)
        }
        return result
    }
    /// Replaces runs like "%#", "%##", "%###" with `number`, zero-padded to
    /// the run's length (minus the leading "%"). Matches are expanded from
    /// the end of the string backwards so earlier ranges stay valid.
    private static func applyingNumberTokens(_ pattern: String, number: Int) -> String {
        guard let regex = try? NSRegularExpression(pattern: "%#+") else { return pattern }
        let fullRange = NSRange(pattern.startIndex..<pattern.endIndex, in: pattern)
        var result = pattern
        let matches = regex.matches(in: pattern, range: fullRange)
        for match in matches.reversed() {
            guard let range = Range(match.range, in: result) else { continue }
            let padding = max(match.range.length - 1, 1)
            result.replaceSubrange(range, with: String(format: "%0\(padding)d", number))
        }
        return result
    }

    private static func monthName(_ month: Int) -> String {
        var components = DateComponents()
        components.year = 2000
        components.month = month
        components.day = 1
        guard let date = Calendar(identifier: .gregorian).date(from: components) else { return "" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "LLLL"
        return formatter.string(from: date)
    }

    /// First free variant of a file name: "name.png", "name 2.png", ….
    static func uniqueFileName(_ name: String, exists: (String) -> Bool) -> String {
        guard exists(name) else { return name }
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        for index in 2...9999 {
            let candidate = ext.isEmpty ? "\(base) \(index)" : "\(base) \(index).\(ext)"
            if !exists(candidate) { return candidate }
        }
        return name
    }

    // MARK: - Annotation model

    enum Tool: String, CaseIterable {
        // Case order is the default rail order and therefore the default
        // mapping for keys 1 through 9. Put the common actions first.
        case select, arrow, pixelate, crop, text, sticker, rect, highlight,
             freehand, line, ellipse, counter, redact

        static let shortcutLimit = 9

        static var defaultOrderStorage: String {
            allCases.map(\.rawValue).joined(separator: ",")
        }

        /// Tools that create an annotation by dragging a rectangle.
        var dragsRect: Bool {
            switch self {
            case .rect, .ellipse, .highlight, .pixelate, .redact: return true
            case .select, .arrow, .line, .freehand, .text, .sticker, .counter, .crop:
                return false
            }
        }

        /// Existing rectangular marks with visible resize grips.
        var resizesWithHandles: Bool {
            dragsRect || self == .sticker
        }

        /// Saved ids first, then any tools added by a later version in the
        /// canonical order. Invalid and duplicate ids never reach the UI.
        static func ordered(from raw: String?) -> [Tool] {
            var seen = Set<Tool>()
            var result: [Tool] = []
            for id in (raw ?? "").split(separator: ",") {
                guard let tool = Tool(rawValue: String(id)),
                      seen.insert(tool).inserted
                else { continue }
                result.append(tool)
            }
            for tool in allCases where seen.insert(tool).inserted {
                result.append(tool)
            }
            return result
        }

        static func shortcutTool(number: Int,
                                 orderRaw: String?,
                                 enabled: Bool) -> Tool? {
            guard enabled, (1...shortcutLimit).contains(number) else { return nil }
            let order = ordered(from: orderRaw)
            let index = number - 1
            return order.indices.contains(index) ? order[index] : nil
        }

        static func shortcutNumber(for tool: Tool,
                                   orderRaw: String?,
                                   enabled: Bool) -> Int? {
            guard enabled,
                  let index = ordered(from: orderRaw).firstIndex(of: tool),
                  index < shortcutLimit
            else { return nil }
            return index + 1
        }

        static func bindings(from raw: String?) -> [Tool: GlobalShortcut] {
            var result: [Tool: GlobalShortcut] = [:]
            for entry in (raw ?? "").split(separator: ",") {
                let pair = entry.split(separator: "=", maxSplits: 1)
                guard pair.count == 2, let tool = Tool(rawValue: String(pair[0])),
                      let shortcut = GlobalShortcut(storageValue: String(pair[1]), requiringModifier: false),
                      !isReservedEditorKey(shortcut) else { continue }
                result[tool] = shortcut
            }
            // Edited backups can contain duplicate bindings. Keep one owner,
            // in rail-default order, so routing and the displayed keys agree.
            var seen = Set<GlobalShortcut>()
            for tool in allCases {
                if let shortcut = result[tool], !seen.insert(shortcut).inserted {
                    result[tool] = nil
                }
            }
            return result
        }

        /// A layout or Caps Lock change can make a saved symbol type a rail
        /// digit. Suspend it in that context without erasing the saved choice.
        static func activeBindings(from raw: String?, capsLockOn: Bool = false) -> [Tool: GlobalShortcut] {
            bindings(from: raw).filter { shortcutDigit($0.value, capsLockOn: capsLockOn) == nil }
        }

        static func bindingsStorage(_ bindings: [Tool: GlobalShortcut]) -> String {
            allCases.compactMap { tool in
                bindings[tool].map { "\(tool.rawValue)=\($0.storageValue)" }
            }.joined(separator: ",")
        }

        static func isReservedEditorKey(_ shortcut: GlobalShortcut) -> Bool {
            let key = Int(shortcut.keyCode)
            if shortcut.modifiers.contains(.command) {
                // The editor's Command branch also accepts extra modifiers.
                return [kVK_ANSI_C, kVK_ANSI_S, kVK_ANSI_Z, kVK_ANSI_P,
                        kVK_ANSI_0, kVK_ANSI_1, kVK_ANSI_Equal, kVK_ANSI_Minus,
                        kVK_Delete, kVK_ForwardDelete, kVK_ANSI_W, kVK_ANSI_Q].contains(key)
            }
            return !shortcut.modifiers.hasPrimaryModifier
                && [kVK_Escape, kVK_Return, kVK_ANSI_KeypadEnter,
                    kVK_Delete, kVK_ForwardDelete].contains(key)
        }

        static func shortcutTool(keyCode: Int64, modifiers: GlobalShortcutModifiers,
                                 number: Int? = nil, orderRaw: String?,
                                 bindingsRaw: String?, enabled: Bool, capsLockOn: Bool = false) -> Tool? {
            guard enabled else { return nil }
            let bindings = activeBindings(from: bindingsRaw, capsLockOn: capsLockOn)
            // The event's printed digit is authoritative, including input
            // methods whose output differs from the underlying keycap table.
            if !modifiers.hasPrimaryModifier, let number, (1...shortcutLimit).contains(number) {
                guard let tool = shortcutTool(number: number, orderRaw: orderRaw, enabled: true),
                      bindings[tool] == nil else { return nil }
                return tool
            }
            let shortcut = GlobalShortcut(keyCode: keyCode, modifiers: modifiers)
            return allCases.first(where: { bindings[$0] == shortcut })
        }

        /// The rail slot a recorded key names, read from what the key types
        /// on the active layout rather than from its position: AZERTY's 1 is
        /// Shift on the & key, and the numerical variant also reaches it
        /// through Caps Lock. Recording carries the actual lock state rather
        /// than trying to recover it from the stored shortcut's modifiers.
        static func shortcutDigit(_ shortcut: GlobalShortcut, capsLockOn: Bool = false) -> Int? {
            guard !shortcut.modifiers.hasPrimaryModifier else { return nil }
            let shifted = shortcut.modifiers.contains(.shift)
            let typed = GlobalShortcut.layoutKeyLabel(for: shortcut.keyCode, usesCommand: false,
                                                      usesShift: shifted, capsLockOn: capsLockOn)
                ?? (shifted || capsLockOn ? nil : shortcut.displayString)
            guard let typed, let digit = Int(typed), (1...shortcutLimit).contains(digit)
            else { return nil }
            return digit
        }

        /// What the rail badge and the recorder show for a tool: its own
        /// binding's caps, or the position digit of an unbound tool in the
        /// first nine.
        static func shortcutLabel(for tool: Tool, orderRaw: String?,
                                  bindingsRaw: String?, enabled: Bool, capsLockOn: Bool = false) -> String? {
            guard enabled else { return nil }
            if let binding = activeBindings(from: bindingsRaw, capsLockOn: capsLockOn)[tool] {
                return binding.displayString
            }
            return shortcutNumber(for: tool, orderRaw: orderRaw, enabled: true).map(String.init)
        }

        /// Why a recorded key cannot become a binding, or nil when it can.
        /// Digits never get here: they move the tool instead. The outside
        /// checks are the same three every shortcut field runs, passed in by
        /// the field so the order and the early return are testable without
        /// defaults or the WindowServer. Recording silences those owners, so
        /// the key records fine and then fires them once the field lets go:
        /// macOS and the app's global taps answer before the editor's window
        /// monitor ever sees the press. The system table is asked last
        /// because it is the one read that leaves the process.
        enum BindingRejection: Equatable {
            case reserved
            case tool(Tool)
            case role(GlobalShortcutRole)
            case windowLayout(String)
            case system
        }

        static func bindingRejection(
            for shortcut: GlobalShortcut, excluding tool: Tool, bindingsRaw: String?,
            roleConflict: (GlobalShortcut) -> GlobalShortcutRole?,
            windowLayoutConflict: (GlobalShortcut) -> String?,
            systemConflict: (GlobalShortcut) -> Bool
        ) -> BindingRejection? {
            if isReservedEditorKey(shortcut) { return .reserved }
            let bindings = bindings(from: bindingsRaw)
            if let other = allCases.first(where: { $0 != tool && bindings[$0] == shortcut }) {
                return .tool(other)
            }
            if let role = roleConflict(shortcut) { return .role(role) }
            if let title = windowLayoutConflict(shortcut) { return .windowLayout(title) }
            return systemConflict(shortcut) ? .system : nil
        }

        /// A recorded digit moves the tool; clearing moves it below the first
        /// nine. Other bindings stay attached to their tools through reorders.
        static func assigningBinding(_ shortcut: GlobalShortcut?, digit: Int? = nil,
                                     to tool: Tool, orderRaw: String?, bindingsRaw: String?)
            -> (orderRaw: String, bindingsRaw: String) {
            var bindings = bindings(from: bindingsRaw)
            bindings[tool] = digit == nil ? shortcut : nil
            let order = shortcut == nil || digit != nil
                ? assigningShortcut(digit, to: tool, orderRaw: orderRaw)
                : ordered(from: orderRaw)
            return (order.map(\.rawValue).joined(separator: ","), bindingsStorage(bindings))
        }

        /// Assigning a number is the same operation as moving the tool into
        /// that numbered rail slot. Choosing no shortcut moves it just below
        /// the first nine, where it remains available without a key.
        static func assigningShortcut(_ number: Int?,
                                      to tool: Tool,
                                      orderRaw: String?) -> [Tool] {
            var order = ordered(from: orderRaw)
            guard let current = order.firstIndex(of: tool) else { return order }
            if number == nil, current >= shortcutLimit { return order }
            order.remove(at: current)
            let destination: Int
            if let number, (1...shortcutLimit).contains(number) {
                destination = min(number - 1, order.count)
            } else {
                destination = min(shortcutLimit, order.count)
            }
            order.insert(tool, at: destination)
            return order
        }
    }

    enum ColorID: String, CaseIterable {
        case red, orange, yellow, green, blue, purple, black, white

        /// sRGB components, shared by live rendering and export.
        var components: (red: Double, green: Double, blue: Double) {
            switch self {
            case .red: return (0.93, 0.26, 0.21)
            case .orange: return (1.00, 0.58, 0.00)
            case .yellow: return (1.00, 0.80, 0.00)
            case .green: return (0.20, 0.78, 0.35)
            case .blue: return (0.04, 0.52, 1.00)
            case .purple: return (0.69, 0.32, 0.87)
            case .black: return (0.09, 0.09, 0.11)
            case .white: return (1.00, 1.00, 1.00)
            }
        }

        static func sanitized(_ raw: String?) -> ColorID {
            ColorID(rawValue: raw ?? "") ?? .red
        }
    }

    enum StrokeID: String, CaseIterable {
        case small, medium, large

        /// Line width in image points at 1x; export multiplies by the image
        /// scale so marks keep their weight on Retina captures.
        var width: CGFloat {
            switch self {
            case .small: return 2
            case .medium: return 4
            case .large: return 7
            }
        }

        static func sanitized(_ raw: String?) -> StrokeID {
            StrokeID(rawValue: raw ?? "") ?? .medium
        }
    }

    /// Text point sizes at 1x, offered as presets. Text has its own size
    /// instead of borrowing the shape thickness, so a thin arrow can sit
    /// beside a large label.
    static let textSizes: [Int] = [10, 12, 14, 16, 19, 24, 28, 36, 48, 64, 72, 96]
    static let defaultTextSize = 19

    static func sanitizedTextSize(_ size: Int) -> Int {
        guard let first = textSizes.first, let last = textSizes.last else { return defaultTextSize }
        return size == 0 ? defaultTextSize : min(max(size, first), last)
    }

    /// The preset one step away from `size`, or nil at either end.
    static func steppedTextSize(from size: Int, up: Bool) -> Int? {
        up ? textSizes.first(where: { $0 > size }) : textSizes.last(where: { $0 < size })
    }

    /// How hard a blur hides what is under it, from 1 (lightest) to 5
    /// (heaviest). Level 3 is the strength blurs always had. The screenshot
    /// pixelate tool and video blurs share the scale so a level means the
    /// same thing in both editors.
    enum BlurStrength {
        static let levels = 1...5
        static let defaultLevel = 3

        static func sanitized(_ level: Int) -> Int {
            min(max(level, levels.lowerBound), levels.upperBound)
        }

        /// Where a new capture's pixelate tool starts: the remembered level,
        /// but never a light one. Levels 1 and 2 make blocks smaller than a
        /// line of text, which can stay readable, so they are picked area by
        /// area instead of carried into the next redaction.
        static func startingLevel(remembered: Int) -> Int {
            max(sanitized(remembered), defaultLevel)
        }

        /// What the level does to the mosaic block, relative to level 3.
        static func blockFactor(for level: Int) -> CGFloat {
            switch sanitized(level) {
            case 1: return 0.4
            case 2: return 0.65
            case 4: return 1.5
            case 5: return 2.2
            default: return 1
            }
        }
    }

    enum ArrowStyleID: String, CaseIterable {
        case filled, outline, open, doubleEnded, scribbly

        static func sanitized(_ raw: String?) -> ArrowStyleID {
            ArrowStyleID(rawValue: raw ?? "") ?? .filled
        }
    }

    static func randomScribbleSeed() -> UInt64 {
        UInt64.random(in: UInt64.min...UInt64.max)
    }

    enum StickerID: String, CaseIterable {
        case check, cross, star, heart, thumbsUp, thumbsDown,
             smile, laugh, party, fire, warning, eyes

        var glyph: String {
            switch self {
            case .check: return "✅"
            case .cross: return "❌"
            case .star: return "⭐️"
            case .heart: return "❤️"
            case .thumbsUp: return "👍"
            case .thumbsDown: return "👎"
            case .smile: return "😀"
            case .laugh: return "😂"
            case .party: return "🎉"
            case .fire: return "🔥"
            case .warning: return "⚠️"
            case .eyes: return "👀"
            }
        }

        static func sanitized(_ raw: String?) -> StickerID {
            StickerID(rawValue: raw ?? "") ?? .check
        }
    }

    static func stickerSide(for imageSize: CGSize, scale: CGFloat) -> CGFloat {
        let shortSide = min(imageSize.width, imageSize.height)
        let minimum = min(52 * scale, shortSide * 0.45)
        return max(1, max(minimum, min(shortSide * 0.16, 128 * scale)))
    }

    static func stickerRect(centeredAt point: CGPoint,
                            side: CGFloat,
                            within bounds: CGRect) -> CGRect {
        let fittedSide = min(max(1, side), min(bounds.width, bounds.height))
        let rect = CGRect(x: point.x - fittedSide / 2,
                          y: point.y - fittedSide / 2,
                          width: fittedSide,
                          height: fittedSide)
        return movedRect(rect, by: .zero, within: bounds)
    }

    /// One annotation on the canvas. Geometry lives in image-point
    /// coordinates (top-left origin), so export is resolution-exact and the
    /// view only scales for display.
    struct Annotation: Identifiable, Equatable {
        let id: UUID
        var tool: Tool
        var rect: CGRect
        var points: [CGPoint]
        var text: String
        var color: ColorID
        var stroke: StrokeID
        var textSize: Int
        var blurLevel: Int
        var arrowStyle: ArrowStyleID
        var scribbleSeed: UInt64
        var number: Int

        init(id: UUID = UUID(),
             tool: Tool,
             rect: CGRect = .zero,
             points: [CGPoint] = [],
             text: String = "",
             color: ColorID = .red,
             stroke: StrokeID = .medium,
             textSize: Int = ScreenshotSupport.defaultTextSize,
             blurLevel: Int = BlurStrength.defaultLevel,
             arrowStyle: ArrowStyleID = .filled,
             scribbleSeed: UInt64? = nil,
             number: Int = 0) {
            self.id = id
            self.tool = tool
            self.rect = rect
            self.points = points
            self.text = text
            self.color = color
            self.stroke = stroke
            self.textSize = textSize
            self.blurLevel = blurLevel
            self.arrowStyle = arrowStyle
            self.scribbleSeed = scribbleSeed
                ?? (arrowStyle == .scribbly
                    ? ScreenshotSupport.randomScribbleSeed()
                    : 0)
            self.number = number
        }
    }

    /// The style values the editor controls should show for a picked mark.
    struct SelectionStyle: Equatable {
        let color: ColorID?
        let stroke: StrokeID?
        let arrowStyle: ArrowStyleID?
        var textSize: Int? = nil
        var blurLevel: Int? = nil
    }

    static func selectionStyle(for annotation: Annotation) -> SelectionStyle {
        switch annotation.tool {
        case .arrow:
            return SelectionStyle(color: annotation.color,
                                  stroke: annotation.stroke,
                                  arrowStyle: annotation.arrowStyle)
        case .line, .rect, .ellipse, .freehand:
            return SelectionStyle(color: annotation.color,
                                  stroke: annotation.stroke,
                                  arrowStyle: nil)
        case .text:
            return SelectionStyle(color: annotation.color,
                                  stroke: nil,
                                  arrowStyle: nil,
                                  textSize: annotation.textSize)
        case .highlight, .counter, .redact:
            return SelectionStyle(color: annotation.color,
                                  stroke: nil,
                                  arrowStyle: nil)
        case .pixelate:
            return SelectionStyle(color: nil,
                                  stroke: nil,
                                  arrowStyle: nil,
                                  blurLevel: annotation.blurLevel)
        case .sticker, .select, .crop:
            return SelectionStyle(color: nil,
                                  stroke: nil,
                                  arrowStyle: nil)
        }
    }

    /// Which way a selected annotation moves through the drawing order.
    enum LayerMove {
        case forward, backward
    }

    /// Whether the annotation has somewhere to go: false at the end it is
    /// already heading for, and for an id that is not in the array.
    static func canReorder(_ annotations: [Annotation],
                           moving id: UUID,
                           _ move: LayerMove) -> Bool {
        guard let index = annotations.firstIndex(where: { $0.id == id }) else { return false }
        return annotations.indices.contains(move == .forward ? index + 1 : index - 1)
    }

    /// Moves one annotation a single step through the array the renderer draws
    /// in order, so a shape can go behind text that was written first. An
    /// annotation already at the end it is heading for stays put, and an
    /// unknown id leaves the array alone.
    static func reordering(_ annotations: [Annotation],
                           moving id: UUID,
                           _ move: LayerMove) -> [Annotation] {
        guard let index = annotations.firstIndex(where: { $0.id == id }) else { return annotations }
        let target = move == .forward ? index + 1 : index - 1
        guard annotations.indices.contains(target) else { return annotations }
        var reordered = annotations
        reordered.swapAt(index, target)
        return reordered
    }

    /// Counters stay 1…n in creation order; deleting one renumbers the rest
    /// so a sequence never shows a hole.
    static func renumberingCounters(_ annotations: [Annotation]) -> [Annotation] {
        var next = 1
        return annotations.map { annotation in
            guard annotation.tool == .counter else { return annotation }
            var updated = annotation
            updated.number = next
            next += 1
            return updated
        }
    }

    /// Counter badge diameter for an image, scaling with capture resolution
    /// so badges stay readable without swallowing small screenshots.
    static func counterDiameter(for imageSize: CGSize, scale: CGFloat) -> CGFloat {
        max(22, min(imageSize.width, imageSize.height) / 24) * scale
    }

    // MARK: - Selection handles

    enum Handle: CaseIterable {
        case topLeft, top, topRight, right, bottomRight, bottom, bottomLeft, left

        func position(in rect: CGRect) -> CGPoint {
            switch self {
            case .topLeft: return CGPoint(x: rect.minX, y: rect.minY)
            case .top: return CGPoint(x: rect.midX, y: rect.minY)
            case .topRight: return CGPoint(x: rect.maxX, y: rect.minY)
            case .right: return CGPoint(x: rect.maxX, y: rect.midY)
            case .bottomRight: return CGPoint(x: rect.maxX, y: rect.maxY)
            case .bottom: return CGPoint(x: rect.midX, y: rect.maxY)
            case .bottomLeft: return CGPoint(x: rect.minX, y: rect.maxY)
            case .left: return CGPoint(x: rect.minX, y: rect.midY)
            }
        }
    }

    static func handle(at point: CGPoint, rect: CGRect, tolerance: CGFloat) -> Handle? {
        Handle.allCases.first { handle in
            let position = handle.position(in: rect)
            return abs(position.x - point.x) <= tolerance && abs(position.y - point.y) <= tolerance
        }
    }

    /// The rectangle after dragging `handle` to `point`. Width and height are
    /// kept non-negative by swapping edges when a drag crosses over.
    static func resizedRect(_ rect: CGRect, dragging handle: Handle, to point: CGPoint) -> CGRect {
        var minX = rect.minX, minY = rect.minY, maxX = rect.maxX, maxY = rect.maxY
        switch handle {
        case .topLeft: minX = point.x; minY = point.y
        case .top: minY = point.y
        case .topRight: maxX = point.x; minY = point.y
        case .right: maxX = point.x
        case .bottomRight: maxX = point.x; maxY = point.y
        case .bottom: maxY = point.y
        case .bottomLeft: minX = point.x; maxY = point.y
        case .left: minX = point.x
        }
        return CGRect(x: min(minX, maxX), y: min(minY, maxY),
                      width: abs(maxX - minX), height: abs(maxY - minY))
    }

    /// Moves an existing crop without resizing it, stopping cleanly at the
    /// image edges instead of shrinking the rectangle through intersection.
    static func movedRect(_ rect: CGRect,
                          by delta: CGPoint,
                          within bounds: CGRect) -> CGRect {
        guard rect.width <= bounds.width, rect.height <= bounds.height else {
            return rect.intersection(bounds)
        }
        let x = min(max(rect.minX + delta.x, bounds.minX), bounds.maxX - rect.width)
        let y = min(max(rect.minY + delta.y, bounds.minY), bounds.maxY - rect.height)
        return CGRect(x: x, y: y, width: rect.width, height: rect.height)
    }

    /// The pixel rectangle a crop draft stands for. A crop cuts on pixel
    /// boundaries, so the chrome, the loupe cross and `applyCrop` all read the
    /// draft through here and mark the same edge. Rounding both edges to the
    /// nearest boundary leaves an already snapped rectangle the same size under
    /// a move, because the two edges carry the same fraction.
    static func pixelSnappedCropRect(_ rect: CGRect, within bounds: CGRect) -> CGRect {
        let minX = (rect.minX).rounded()
        let minY = (rect.minY).rounded()
        let maxX = (rect.maxX).rounded()
        let maxY = (rect.maxY).rounded()
        return clamp(CGRect(x: minX, y: minY, width: maxX - minX, height: maxY - minY),
                     to: bounds)
    }

    /// A stable square of source pixels for the crop loupe. Near an image
    /// edge the sample slides inward instead of shrinking, and the loupe's
    /// reticle still marks the exact adjusted pixel.
    static let captureLoupeBaseSampleSide: CGFloat = 13
    static let captureLoupeMinSampleSide: CGFloat = 3
    static let captureLoupeMinZoom: CGFloat = 0.5
    static var captureLoupeMaxZoom: CGFloat {
        captureLoupeBaseSampleSide / captureLoupeMinSampleSide
    }
    static let captureLoupeDefaultZooms: [Double] = [0.5, 1, 2, 4]
    /// The magnifier square on screen, in view points. Big enough that each
    /// sampled pixel becomes a readable grid cell at every zoom level.
    static let captureLoupeFrameSide: CGFloat = 132

    static func captureLoupeInitialZoom(rememberLast: Bool,
                                        defaultZoom: CGFloat,
                                        lastZoom: CGFloat) -> CGFloat {
        let requested = rememberLast ? lastZoom : defaultZoom
        guard requested.isFinite else { return 1 }
        return min(max(requested, captureLoupeMinZoom), captureLoupeMaxZoom)
    }

    static func captureLoupeUsesSteppedZoom(steppedByDefault: Bool,
                                             optionPressed: Bool) -> Bool {
        steppedByDefault != optionPressed
    }

    /// A few high-resolution mouse drivers put sub-notch movement only in
    /// the fixed-point wheel field. `NSEvent.scrollingDeltaY` rounds those
    /// packets to zero, which would make apparently random notches disappear.
    static func captureLoupeWheelDelta(scrollingDelta: CGFloat,
                                       lineDelta: Int64,
                                       fixedPointDelta: Double) -> CGFloat {
        if fixedPointDelta.isFinite, fixedPointDelta != 0 {
            return CGFloat(fixedPointDelta)
        }
        if lineDelta != 0 { return CGFloat(lineDelta) }
        return scrollingDelta.isFinite ? scrollingDelta : 0
    }

    /// Fast mode preserves the original one-step-per-event behavior.
    static func captureLoupeZoom(_ zoom: CGFloat,
                                 adjustedBy scrollDelta: CGFloat) -> CGFloat {
        guard scrollDelta.isFinite, scrollDelta != 0 else {
            return min(max(zoom, captureLoupeMinZoom), captureLoupeMaxZoom)
        }
        let factor: CGFloat = scrollDelta > 0 ? 1.15 : 1 / 1.15
        return min(max(zoom * factor, captureLoupeMinZoom), captureLoupeMaxZoom)
    }

    /// Step mode advances by exactly one drawable pixel-grid level. A fixed
    /// percentage cannot promise that: at the wide end it can skip two odd
    /// sample sizes, while at the narrow end it can round back to the same
    /// size and appear to do nothing.
    static func captureLoupeSteppedZoom(_ zoom: CGFloat,
                                        adjustedBy scrollDelta: CGFloat) -> CGFloat {
        let clamped = min(max(zoom, captureLoupeMinZoom), captureLoupeMaxZoom)
        guard scrollDelta.isFinite, scrollDelta != 0 else { return clamped }

        let currentSide = captureLoupeSampleSide(zoom: clamped)
        let widestSide = captureLoupeSampleSide(zoom: captureLoupeMinZoom)
        let targetSide = scrollDelta > 0
            ? max(captureLoupeMinSampleSide, currentSide - 2)
            : min(widestSide, currentSide + 2)
        guard targetSide != currentSide else { return clamped }

        // The widest level lies just below the numeric minimum when expressed
        // as base / side, so it deliberately resolves to the public boundary.
        if targetSide == widestSide { return captureLoupeMinZoom }
        return min(max(captureLoupeBaseSampleSide / targetSide,
                       captureLoupeMinZoom), captureLoupeMaxZoom)
    }

    /// Sampled source pixels per side. Always an odd whole number, never
    /// below three, so the pixel under the pointer is a real middle cell
    /// that the grid can outline instead of a boundary between two cells.
    static func captureLoupeSampleSide(zoom: CGFloat) -> CGFloat {
        let clamped = min(max(zoom, captureLoupeMinZoom), captureLoupeMaxZoom)
        let raw = captureLoupeBaseSampleSide / clamped
        let odd = 2 * (raw / 2).rounded(.down) + 1
        return max(captureLoupeMinSampleSide, odd)
    }

    /// The pixel grid earns its ink only once a cell is big enough that the
    /// lines separate pixels instead of shading the whole image.
    static func captureLoupeGridVisible(frameSide: CGFloat, sampleSide: CGFloat) -> Bool {
        sampleSide > 0 && frameSide / sampleSide >= 6
    }

    /// Arrow keys move the pointer by whole device pixels of the screen it is
    /// on, in points, so one press always lands on the neighbouring pixel
    /// even on Retina displays. Shift covers ten pixels per press.
    static func captureLoupeNudge(dx: CGFloat,
                                  dy: CGFloat,
                                  fast: Bool,
                                  scale: CGFloat) -> CGPoint {
        let step = (fast ? 10 : 1) / max(scale, 1)
        return CGPoint(x: dx * step, y: dy * step)
    }

    /// The square of source pixels a loupe magnifies. The two loupes centre on
    /// different things and therefore need opposite parities.
    ///
    /// The capture loupe reads a color, so it centres on a whole *pixel*
    /// (`centredOnPixel`): the side is forced odd because an even one has no
    /// middle cell, which left the sampled pixel half a cell right of and below
    /// the frame's centre, and the ring drawn around it followed. Centring on
    /// the floored coordinate keeps the pointer's sub-pixel position out of it.
    ///
    /// The editor's crop loupe marks a crop *edge*, which runs between pixels.
    /// An edge lands in the middle of the frame only when the side is even and
    /// the coordinate is whole, so that caller passes `centredOnPixel: false`
    /// and reads a draft `pixelSnappedCropRect` has put on a boundary.
    static func cropLoupeSampleRect(around point: CGPoint,
                                    imageSize: CGSize,
                                    sideLength: CGFloat = 13,
                                    centredOnPixel: Bool = true) -> CGRect {
        let imageWidth = max(1, floor(imageSize.width))
        let imageHeight = max(1, floor(imageSize.height))
        var side = max(1, floor(sideLength))
        let isEven = side.truncatingRemainder(dividingBy: 2) == 0
        if centredOnPixel, isEven {
            side = max(1, side - 1)
        } else if !centredOnPixel, !isEven {
            side += 1
        }
        let width = min(side, imageWidth)
        let height = min(side, imageHeight)
        let x = centredOnPixel ? floor(point.x) - floor(width / 2) : floor(point.x - width / 2)
        let y = centredOnPixel ? floor(point.y) - floor(height / 2) : floor(point.y - height / 2)
        return CGRect(x: min(max(x, 0), imageWidth - width),
                      y: min(max(y, 0), imageHeight - height),
                      width: width,
                      height: height)
    }

    /// Where the one source pixel under `point` lands inside a loupe frame.
    /// It floors the coordinate exactly like the color read does, so a
    /// highlight built from this rect can never mark a neighbour of the pixel
    /// that gets copied, and the pointer's sub-pixel position stops leaking
    /// into the drawing.
    static func captureLoupeTargetPixelRect(around point: CGPoint,
                                            source: CGRect,
                                            frame: CGRect) -> CGRect {
        guard source.width >= 1, source.height >= 1 else { return frame }
        let column = min(max(floor(point.x), source.minX), source.maxX - 1)
        let row = min(max(floor(point.y), source.minY), source.maxY - 1)
        let width = frame.width / source.width
        let height = frame.height / source.height
        return CGRect(x: frame.minX + (column - source.minX) * width,
                      y: frame.minY + (row - source.minY) * height,
                      width: width,
                      height: height)
    }

    // MARK: - Shape geometry

    /// Arrow head as two wing points for a line ending at `tip`. The head
    /// grows with the stroke so thick arrows stay proportionate.
    static func arrowHead(from tail: CGPoint,
                          to tip: CGPoint,
                          strokeWidth: CGFloat) -> (left: CGPoint, right: CGPoint) {
        let angle = atan2(tip.y - tail.y, tip.x - tail.x)
        let distance = hypot(tip.x - tail.x, tip.y - tail.y)
        let preferred = max(10, strokeWidth * 3.4)
        let proportional = max(distance * 0.72, min(strokeWidth * 1.2, distance))
        let length = min(preferred, proportional)
        let spread: CGFloat = .pi / 7
        let left = CGPoint(x: tip.x - length * cos(angle - spread),
                           y: tip.y - length * sin(angle - spread))
        let right = CGPoint(x: tip.x - length * cos(angle + spread),
                            y: tip.y - length * sin(angle + spread))
        return (left, right)
    }

    /// One continuous outline for the complete arrow. Keeping the shaft,
    /// round tail and head on the same contour avoids winding-rule cutouts
    /// where independently filled shapes would overlap.
    static func arrowSilhouette(from tail: CGPoint,
                                to tip: CGPoint,
                                strokeWidth: CGFloat) -> CGPath {
        let angle = atan2(tip.y - tail.y, tip.x - tail.x)
        let head = arrowHead(from: tail, to: tip, strokeWidth: strokeWidth)
        let baseMid = CGPoint(x: (head.left.x + head.right.x) / 2,
                              y: (head.left.y + head.right.y) / 2)
        let half = strokeWidth / 2
        let perpendicular = CGPoint(x: -sin(angle) * half,
                                    y: cos(angle) * half)

        let path = CGMutablePath()
        path.move(to: CGPoint(x: tail.x + perpendicular.x,
                              y: tail.y + perpendicular.y))
        path.addLine(to: CGPoint(x: baseMid.x + perpendicular.x,
                                 y: baseMid.y + perpendicular.y))
        path.addLine(to: head.left)
        path.addLine(to: tip)
        path.addLine(to: head.right)
        path.addLine(to: CGPoint(x: baseMid.x - perpendicular.x,
                                 y: baseMid.y - perpendicular.y))
        path.addLine(to: CGPoint(x: tail.x - perpendicular.x,
                                 y: tail.y - perpendicular.y))
        path.addArc(center: tail,
                    radius: half,
                    startAngle: angle - .pi / 2,
                    endAngle: angle + .pi / 2,
                    clockwise: true)
        path.closeSubpath()
        return path
    }

    /// Shaft and heads of a stroked arrow style as one path, so a single
    /// stroke draws the whole arrow and casts one shadow. The solid style is a
    /// filled silhouette rather than a stroke and answers nil.
    static func arrowStrokePath(from tail: CGPoint,
                                to tip: CGPoint,
                                strokeWidth: CGFloat,
                                style: ArrowStyleID,
                                seed: UInt64) -> CGPath? {
        let head = arrowHead(from: tail, to: tip, strokeWidth: strokeWidth)
        let path = CGMutablePath()
        switch style {
        case .filled:
            return nil
        case .outline:
            path.addLines(between: [tail, CGPoint(x: (head.left.x + head.right.x) / 2,
                                                  y: (head.left.y + head.right.y) / 2)])
            path.addLines(between: [head.left, tip, head.right])
            path.closeSubpath()
        case .open:
            path.addLines(between: [tail, tip])
            path.addLines(between: [head.left, tip, head.right])
        case .doubleEnded:
            let tailHead = arrowHead(from: tip, to: tail, strokeWidth: strokeWidth)
            path.addLines(between: [tail, tip])
            path.addLines(between: [head.left, tip, head.right])
            path.addLines(between: [tailHead.left, tail, tailHead.right])
        case .scribbly:
            let geometry = scribblyArrowGeometry(from: tail,
                                                 to: tip,
                                                 strokeWidth: strokeWidth,
                                                 seed: seed)
            path.addLines(between: geometry.shaft)
            path.addLines(between: geometry.leftWing)
            path.addLines(between: geometry.rightWing)
        }
        return path
    }

    /// A lightly hand-drawn arrow made from stable, seeded wobble. The seed
    /// belongs to the annotation so a redraw or export keeps the same sketch,
    /// while each newly created scribbly arrow gets its own variation.
    struct ScribblyArrowGeometry: Equatable {
        let shaft: [CGPoint]
        let leftWing: [CGPoint]
        let rightWing: [CGPoint]
    }

    static func scribblyArrowGeometry(from tail: CGPoint,
                                      to tip: CGPoint,
                                      strokeWidth: CGFloat,
                                      seed: UInt64) -> ScribblyArrowGeometry {
        let dx = tip.x - tail.x
        let dy = tip.y - tail.y
        let distance = hypot(dx, dy)
        let angle = atan2(dy, dx)
        let direction = CGPoint(x: cos(angle), y: sin(angle))
        let perpendicular = CGPoint(x: -direction.y, y: direction.x)
        let head = arrowHead(from: tail, to: tip, strokeWidth: strokeWidth)
        let base = CGPoint(x: (head.left.x + head.right.x) / 2,
                           y: (head.left.y + head.right.y) / 2)
        var randomizer = ScribbleRandomizer(seed: seed)
        let shaftSegments = max(4, min(24, Int(ceil(distance / max(10, strokeWidth * 3)))))
        let shaftWobble = min(max(1, strokeWidth * 0.35), distance * 0.025)
        let shaft = roughPath(from: tail,
                              to: base,
                              segments: shaftSegments,
                              direction: direction,
                              perpendicular: perpendicular,
                              wobble: shaftWobble,
                              randomizer: &randomizer)
        let wingWobble = min(max(0.8, strokeWidth * 0.22), distance * 0.035)
        let leftWing = roughPath(from: head.left,
                                 to: tip,
                                 segments: 3,
                                 wobble: wingWobble,
                                 randomizer: &randomizer)
        let rightWing = roughPath(from: head.right,
                                  to: tip,
                                  segments: 3,
                                  wobble: wingWobble,
                                  randomizer: &randomizer)
        return ScribblyArrowGeometry(shaft: shaft,
                                     leftWing: leftWing,
                                     rightWing: rightWing)
    }

    private struct ScribbleRandomizer {
        private var state: UInt64

        init(seed: UInt64) {
            state = seed == 0 ? 0x9E3779B97F4A7C15 : seed
        }

        mutating func signedUnit() -> CGFloat {
            state = state &* 2862933555777941757 &+ 3037000493
            let normalized = Double(state) / Double(UInt64.max)
            return CGFloat(normalized * 2 - 1)
        }
    }

    private static func roughPath(from start: CGPoint,
                                  to end: CGPoint,
                                  segments: Int,
                                  direction: CGPoint? = nil,
                                  perpendicular: CGPoint? = nil,
                                  wobble: CGFloat,
                                  randomizer: inout ScribbleRandomizer) -> [CGPoint] {
        let lineX = end.x - start.x
        let lineY = end.y - start.y
        let length = hypot(lineX, lineY)
        let pathDirection = direction
            ?? CGPoint(x: lineX / max(length, 0.001), y: lineY / max(length, 0.001))
        let pathPerpendicular = perpendicular
            ?? CGPoint(x: -pathDirection.y, y: pathDirection.x)
        let count = max(1, segments)
        return (0...count).map { index in
            let progress = CGFloat(index) / CGFloat(count)
            guard index != 0, index != count else {
                return CGPoint(x: start.x + lineX * progress,
                               y: start.y + lineY * progress)
            }
            let envelope = CGFloat(sin(Double.pi * Double(progress)))
            let sideOffset = randomizer.signedUnit() * wobble * envelope
            let forwardOffset = randomizer.signedUnit() * wobble * 0.28 * envelope
            return CGPoint(x: start.x + lineX * progress
                                + pathPerpendicular.x * sideOffset
                                + pathDirection.x * forwardOffset,
                           y: start.y + lineY * progress
                                + pathPerpendicular.y * sideOffset
                                + pathDirection.y * forwardOffset)
        }
    }

    /// Distance from a point to a segment, for hit-testing lines and arrows.
    static func distance(from point: CGPoint, toSegment start: CGPoint, _ end: CGPoint) -> CGFloat {
        let dx = end.x - start.x
        let dy = end.y - start.y
        let lengthSquared = dx * dx + dy * dy
        guard lengthSquared > 0 else {
            return hypot(point.x - start.x, point.y - start.y)
        }
        let t = max(0, min(1, ((point.x - start.x) * dx + (point.y - start.y) * dy) / lengthSquared))
        let projection = CGPoint(x: start.x + t * dx, y: start.y + t * dy)
        return hypot(point.x - projection.x, point.y - projection.y)
    }

    // MARK: - Redaction

    /// Pixelation block size in image pixels, scaled to the capture so small
    /// crops and full screens redact equally well. From the default level up
    /// the mosaic carries no legible detail; levels 1 and 2 are lighter and
    /// can leave large text readable.
    static func pixelBlockSize(for imageSize: CGSize,
                               level: Int = BlurStrength.defaultLevel) -> Int {
        let base = max(10, Int(min(imageSize.width, imageSize.height) / 55))
        return max(2, Int((CGFloat(base) * BlurStrength.blockFactor(for: level)).rounded()))
    }

    /// The blur levels the pixelate marks use. Keep only their sampled mosaics;
    /// drawing expands each one to the capture size when needed.
    static func mosaicLevels(for annotations: [Annotation]) -> Set<Int> {
        Set(annotations.filter { $0.tool == .pixelate }.map(\.blurLevel))
    }

    // MARK: - Export

    /// Pixel size after the optional 1x downscale of a Retina capture.
    static func downscaledSize(pixelSize: CGSize, scale: CGFloat) -> CGSize {
        guard scale > 1 else { return pixelSize }
        return CGSize(width: (pixelSize.width / scale).rounded(),
                      height: (pixelSize.height / scale).rounded())
    }

    // MARK: - Backdrop

    /// Padded background, corner rounding and shadow applied during export.
    enum BackdropID: String, CaseIterable {
        case none, ocean, sunset, forest, candy, graphite

        /// Gradient stops as sRGB components, top-left to bottom-right.
        var stops: [(red: Double, green: Double, blue: Double)] {
            switch self {
            case .none: return []
            case .ocean: return [(0.20, 0.47, 0.96), (0.45, 0.83, 0.98)]
            case .sunset: return [(0.99, 0.36, 0.42), (1.00, 0.75, 0.35)]
            case .forest: return [(0.07, 0.56, 0.43), (0.62, 0.87, 0.50)]
            case .candy: return [(0.66, 0.32, 0.95), (0.99, 0.56, 0.65)]
            case .graphite: return [(0.23, 0.25, 0.31), (0.55, 0.60, 0.70)]
            }
        }

    }

    /// Padding around the image for a backdrop. `factor` is the user's margin
    /// slider (0…1); even 0 keeps a small frame so the gradient always shows,
    /// and a floor keeps a visible margin around small captures.
    static func backdropPadding(for imageSize: CGSize, factor: CGFloat) -> CGFloat {
        let clamped = max(0, min(1, factor))
        let side = min(imageSize.width, imageSize.height)
        let proportional = side * (0.035 + 0.14 * clamped)
        return max(24, proportional).rounded()
    }

    /// Corner rounding of the capture card in image pixels. Factor 0 keeps
    /// the capture square; 1 is a generous fifth of the short side.
    static func cardCornerRadius(for imageSize: CGSize, factor: CGFloat) -> CGFloat {
        let clamped = max(0, min(1, factor))
        return (clamped * min(imageSize.width, imageSize.height) * 0.2).rounded()
    }

    /// Gaussian blur radius in output pixels. Keeping it proportional makes
    /// the same slider look consistent on small screenshots and 4K video.
    static func backdropBlurRadius(for size: CGSize, factor: CGFloat) -> CGFloat {
        let clamped = max(0, min(1, factor))
        return clamped * min(size.width, size.height) * 0.035
    }

    /// The full backdrop configuration behind a capture, persisted as JSON
    /// (one style in use, plus the user's saved presets). Colors are sRGB
    /// components so the codec stays pure and testable.
    struct BackdropStyle: Codable, Equatable {
        enum Kind: String, Codable {
            case none, preset, solid, gradient, image
        }

        var kind: Kind
        /// BackdropID raw value when kind == .preset.
        var presetID: String?
        /// 1 color (solid) or 2 colors (gradient), each [r, g, b] in 0…1.
        var colors: [[Double]]?
        /// Absolute path when kind == .image (user image or a wallpaper).
        var imagePath: String?
        var padding: Double
        var cornerRadius: Double
        var blur: Double

        init(kind: Kind = .none,
             presetID: String? = nil,
             colors: [[Double]]? = nil,
             imagePath: String? = nil,
             padding: Double = 0.5,
             cornerRadius: Double = 0,
             blur: Double = 0) {
            self.kind = kind
            self.presetID = presetID
            self.colors = colors
            self.imagePath = imagePath
            self.padding = padding
            self.cornerRadius = cornerRadius
            self.blur = blur
        }

        private enum CodingKeys: String, CodingKey {
            case kind, presetID, colors, imagePath, padding, cornerRadius, blur
        }

        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            kind = try values.decode(Kind.self, forKey: .kind)
            presetID = try values.decodeIfPresent(String.self, forKey: .presetID)
            colors = try values.decodeIfPresent([[Double]].self, forKey: .colors)
            imagePath = try values.decodeIfPresent(String.self, forKey: .imagePath)
            padding = try values.decode(Double.self, forKey: .padding)
            cornerRadius = try values.decode(Double.self, forKey: .cornerRadius)
            blur = try values.decodeIfPresent(Double.self, forKey: .blur) ?? 0
        }

        func encode(to encoder: Encoder) throws {
            var values = encoder.container(keyedBy: CodingKeys.self)
            try values.encode(kind, forKey: .kind)
            try values.encodeIfPresent(presetID, forKey: .presetID)
            try values.encodeIfPresent(colors, forKey: .colors)
            try values.encodeIfPresent(imagePath, forKey: .imagePath)
            try values.encode(padding, forKey: .padding)
            try values.encode(cornerRadius, forKey: .cornerRadius)
            try values.encode(blur, forKey: .blur)
        }

        /// Clamps sliders, validates colors and drops broken configurations
        /// back to .none, so a damaged persisted value can never wedge the
        /// editor.
        func sanitized() -> BackdropStyle {
            var style = self
            style.padding = style.padding.isFinite ? max(0, min(1, style.padding)) : 0.5
            style.cornerRadius = style.cornerRadius.isFinite
                ? max(0, min(1, style.cornerRadius)) : 0.1
            style.blur = style.blur.isFinite ? max(0, min(1, style.blur)) : 0
            switch style.kind {
            case .none:
                break
            case .preset:
                guard let id = style.presetID, BackdropID(rawValue: id) != nil,
                      BackdropID(rawValue: id) != BackdropID.none
                else { return style.demoted() }
            case .solid:
                guard let colors = style.colors, colors.count == 1,
                      colors.allSatisfy({ $0.count == 3 && $0.allSatisfy(\.isFinite) })
                else { return style.demoted() }
                style.colors = colors.map { $0.map { max(0, min(1, $0)) } }
            case .gradient:
                guard let colors = style.colors, colors.count == 2,
                      colors.allSatisfy({ $0.count == 3 && $0.allSatisfy(\.isFinite) })
                else { return style.demoted() }
                style.colors = colors.map { $0.map { max(0, min(1, $0)) } }
            case .image:
                guard let path = style.imagePath, !path.isEmpty
                else { return style.demoted() }
            }
            return style
        }

        private func demoted() -> BackdropStyle {
            var style = self
            style.kind = .none
            style.presetID = nil
            style.colors = nil
            style.imagePath = nil
            return style
        }

        func encoded() -> String {
            guard let data = try? JSONEncoder().encode(self) else { return "" }
            return String(data: data, encoding: .utf8) ?? ""
        }

        static func decoded(_ raw: String?) -> BackdropStyle {
            guard let raw, !raw.isEmpty,
                  let data = raw.data(using: .utf8),
                  let style = try? JSONDecoder().decode(BackdropStyle.self, from: data)
            else { return BackdropStyle() }
            return style.sanitized()
        }
    }

    // MARK: - Recognized text (selectable on the canvas)

    /// One word of recognized text, in image-pixel coordinates.
    struct RecognizedWord: Equatable {
        let text: String
        let rect: CGRect
        /// Line index, so copied selections keep their line breaks.
        let line: Int
    }

    /// Words a selection drag touches, in reading order. A hairline drag
    /// still selects what it crosses.
    static func wordSelection(anchor: CGPoint,
                              current: CGPoint,
                              boxes: [CGRect]) -> [Int] {
        let rect = selectionRect(from: anchor, to: current)
            .insetBy(dx: -1, dy: -1)
        return boxes.indices.filter { boxes[$0].intersects(rect) }
    }

    /// Joins selected words with spaces inside a line and newlines between
    /// lines, whatever order the indexes arrive in.
    static func joinedWords(_ words: [RecognizedWord], selected: [Int]) -> String {
        let picked = selected.sorted().compactMap { words.indices.contains($0) ? words[$0] : nil }
        guard !picked.isEmpty else { return "" }
        var lines: [String] = []
        var currentLine = picked[0].line
        var currentWords: [String] = []
        for word in picked {
            if word.line != currentLine {
                lines.append(currentWords.joined(separator: " "))
                currentWords = []
                currentLine = word.line
            }
            currentWords.append(word.text)
        }
        lines.append(currentWords.joined(separator: " "))
        return lines.joined(separator: "\n")
    }

    /// Saved custom backdrops, capped at the configured limit.
    static let backdropPresetLimit = 12

    static func decodedBackdropPresets(_ raw: String?) -> [BackdropStyle] {
        guard let raw, !raw.isEmpty,
              let data = raw.data(using: .utf8),
              let presets = try? JSONDecoder().decode([BackdropStyle].self, from: data)
        else { return [] }
        return presets.map { $0.sanitized() }
            .filter { $0.kind != .none }
            .suffix(backdropPresetLimit)
            .map { $0 }
    }

    static func encodedBackdropPresets(_ presets: [BackdropStyle]) -> String {
        guard let data = try? JSONEncoder().encode(Array(presets.suffix(backdropPresetLimit)))
        else { return "[]" }
        return String(data: data, encoding: .utf8) ?? "[]"
    }

    // MARK: - Watermark

    /// A mark of your own on every capture that leaves the editor: a line of
    /// text or a picture from disk, faded, tilted if you like and set on one
    /// of nine places. Persisted as JSON like the backdrop, so the next
    /// capture opens with it already on.
    struct WatermarkStyle: Codable, Equatable {
        enum Kind: String, Codable {
            case none, text, image
        }

        /// The same nine places the recorder's captions and pictures take:
        /// one grid to learn across both editors.
        typealias Anchor = RecorderTextOverlay.Anchor

        var kind: Kind
        var text: String
        /// Absolute path when kind == .image.
        var imagePath: String?
        /// ColorID raw value the text is drawn in.
        var color: String
        var anchor: Anchor
        /// Sliders 0…1; `watermarkFontSize` and `watermarkImageWidth` turn
        /// them into pixels for a given capture.
        var size: Double
        var opacity: Double
        /// Degrees, -90…90: positive tilts the mark up to the right, the way
        /// a diagonal document watermark runs.
        var rotation: Double

        init(kind: Kind = .none,
             text: String = "",
             imagePath: String? = nil,
             color: String = ColorID.white.rawValue,
             anchor: Anchor = .bottomTrailing,
             size: Double = 0.3,
             opacity: Double = 0.4,
             rotation: Double = 0) {
            self.kind = kind
            self.text = text
            self.imagePath = imagePath
            self.color = color
            self.anchor = anchor
            self.size = size
            self.opacity = opacity
            self.rotation = rotation
        }

        static let opacityRange: ClosedRange<Double> = 0.05...1
        static let rotationRange: ClosedRange<Double> = -90...90
        static let textLimit = 120

        /// Clamps the sliders, trims the text and drops a configuration
        /// missing its content back to .none, so a damaged persisted value
        /// can never wedge the editor.
        func sanitized() -> WatermarkStyle {
            var style = self
            style.text = String(text.trimmingCharacters(in: .whitespacesAndNewlines)
                .prefix(Self.textLimit))
            style.color = ColorID(rawValue: color)?.rawValue ?? ColorID.white.rawValue
            style.size = size.isFinite ? max(0, min(1, size)) : 0.3
            style.opacity = opacity.isFinite
                ? max(Self.opacityRange.lowerBound, min(Self.opacityRange.upperBound, opacity))
                : 0.4
            style.rotation = rotation.isFinite
                ? max(Self.rotationRange.lowerBound, min(Self.rotationRange.upperBound, rotation))
                : 0
            switch style.kind {
            case .none:
                break
            case .text:
                guard !style.text.isEmpty else { return style.demoted() }
            case .image:
                guard let path = style.imagePath, !path.isEmpty else { return style.demoted() }
            }
            return style
        }

        private func demoted() -> WatermarkStyle {
            var style = self
            style.kind = .none
            return style
        }

        func encoded() -> String {
            guard let data = try? JSONEncoder().encode(self) else { return "" }
            return String(data: data, encoding: .utf8) ?? ""
        }

        static func decoded(_ raw: String?) -> WatermarkStyle {
            guard let raw, !raw.isEmpty,
                  let data = raw.data(using: .utf8),
                  let style = try? JSONDecoder().decode(WatermarkStyle.self, from: data)
            else { return WatermarkStyle() }
            return style.sanitized()
        }
    }

    /// Saved watermarks, capped like the backdrops.
    static func decodedWatermarkPresets(_ raw: String?) -> [WatermarkStyle] {
        guard let raw, !raw.isEmpty,
              let data = raw.data(using: .utf8),
              let presets = try? JSONDecoder().decode([WatermarkStyle].self, from: data)
        else { return [] }
        return presets.map { $0.sanitized() }
            .filter { $0.kind != .none }
            .suffix(backdropPresetLimit)
            .map { $0 }
    }

    static func encodedWatermarkPresets(_ presets: [WatermarkStyle]) -> String {
        guard let data = try? JSONEncoder().encode(Array(presets.suffix(backdropPresetLimit)))
        else { return "[]" }
        return String(data: data, encoding: .utf8) ?? "[]"
    }

    /// Point size of watermark text in image pixels: factor 0 is a discreet
    /// 2% of the short side, 1 a bold 16%, the recorder's caption ceiling.
    static func watermarkFontSize(for imageSize: CGSize, factor: CGFloat) -> CGFloat {
        let clamped = max(0, min(1, factor))
        return max(8, (min(imageSize.width, imageSize.height) * (0.02 + 0.14 * clamped)).rounded())
    }

    /// Width of a watermark picture in image pixels, from a corner mark of
    /// 5% of the capture's width up to half of it. The picture's own
    /// proportions decide the height.
    static func watermarkImageWidth(for imageSize: CGSize, factor: CGFloat) -> CGFloat {
        let clamped = max(0, min(1, factor))
        return max(1, (imageSize.width * (0.05 + 0.45 * clamped)).rounded())
    }

    struct WatermarkPlacement {
        /// Where the mark's center goes, in image pixels with a top-left origin.
        let center: CGPoint
        /// How much the content shrinks so its tilted bounds stay inside the
        /// margins; 1 when it already fits.
        let fit: CGFloat
    }

    /// Where a mark of `contentSize`, turned by `rotation` degrees, sits on a
    /// capture: its tilted bounding box is what the nine places position, so
    /// a diagonal mark in a corner touches the margin instead of leaving it.
    /// The margin is the recorder's, 5% of the short side.
    static func watermarkPlacement(contentSize: CGSize,
                                   rotation: Double,
                                   anchor: WatermarkStyle.Anchor,
                                   in imageSize: CGSize,
                                   cornerRadius: CGFloat = 0) -> WatermarkPlacement? {
        guard contentSize.width.isFinite, contentSize.height.isFinite,
              contentSize.width > 0, contentSize.height > 0,
              imageSize.width > 0, imageSize.height > 0, rotation.isFinite
        else { return nil }
        let radians = rotation * .pi / 180
        let bounds = CGSize(
            width: abs(contentSize.width * cos(radians)) + abs(contentSize.height * sin(radians)),
            height: abs(contentSize.width * sin(radians)) + abs(contentSize.height * cos(radians)))
        let shortSide = min(imageSize.width, imageSize.height)
        // The inset rectangle must lie entirely inside the rounded capture.
        // At the diagonal of a quarter circle the inset is r * (1 - sqrt(0.5)).
        // A pixel of breathing room avoids clipping antialiased edges. Keep
        // positive space even after cropping down to only a few pixels.
        let radius = cornerRadius.isFinite ? max(0, min(shortSide / 2, cornerRadius)) : 0
        let roundedInset = radius > 0 ? ceil(radius * (1 - sqrt(0.5))) + 1 : 0
        let margin = min(shortSide * 0.45, max(shortSide * 0.05, roundedInset))
        let available = CGSize(width: imageSize.width - margin * 2,
                               height: imageSize.height - margin * 2)
        let fit = min(1, min(available.width / bounds.width, available.height / bounds.height))
        let fitted = CGSize(width: bounds.width * fit, height: bounds.height * fit)
        let point = anchor.unitPoint
        return WatermarkPlacement(
            center: CGPoint(x: margin + (available.width - fitted.width) * point.x + fitted.width / 2,
                            y: margin + (available.height - fitted.height) * point.y + fitted.height / 2),
            fit: fit)
    }
}

/// The action to run automatically right after a capture, chosen in
/// Settings. `.none` leaves the quick-preview HUD waiting for the user, as
/// before this setting existed.
enum ScreenshotDefaultAction: String, CaseIterable {
    case none = ""
    case save
    case saveAndCopy
    case copy
    case edit

    /// The persisted choice; an unknown raw value reads as `.none`.
    static var current: ScreenshotDefaultAction {
        let raw = UserDefaults.standard.string(forKey: DefaultsKey.screenshotDefaultAction) ?? ""
        return ScreenshotDefaultAction(rawValue: raw) ?? .none
    }

    /// Copy and Save and copy put every capture on the clipboard.
    var copiesToClipboard: Bool { self == .copy || self == .saveAndCopy }

    /// The same choice without its clipboard half. Turning automatic copy
    /// off in Settings applies this, so Save and copy keeps saving.
    var withoutCopy: ScreenshotDefaultAction {
        switch self {
        case .copy: return .none
        case .saveAndCopy: return .save
        case .none, .save, .edit: return self
        }
    }
}
