// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Vorssaint

import Accelerate
import AppKit
import AudioToolbox
import Combine
import CoreAudio
import Darwin

struct MixerOutputDevice: Identifiable, Equatable {
    let id: String
    let uid: String
    let name: String
    let isDefault: Bool
    let isHeadphones: Bool
    let canBeDefaultOutput: Bool
    let canBeDefaultSystemOutput: Bool
    let priorityTier: MixerRoutingSupport.PriorityTier
    fileprivate let audioObjectID: AudioObjectID
}

/// One app in the mixer: every audio-producing process it is responsible for,
/// rolled into a single row.
struct MixerApp: Identifiable, Equatable {
    /// Identifies the row and its engine while the app runs.
    let id: String
    /// The key this row's volume and route are saved under: bundle id, or
    /// display name for a process without one. Nil when neither exists; such
    /// a row is still listed and adjustable, but writes nothing to disk.
    let persistenceID: String?
    let ownerPid: pid_t
    let name: String
    let audioObjects: [AudioObjectID]
    /// True while the app is actually emitting sound right now (shown as a
    /// live indicator). Apps appear in the mixer even when momentarily silent,
    /// as long as they hold an audio connection.
    let isPlaying: Bool
    /// The app manages its own audio (Zoom, DAWs): shown in the list so its
    /// absence doesn't read as a bug (issue #177), but never tapped — no
    /// slider, no routing, volume pinned at unity.
    var isBypassed: Bool = false
    var selectedOutputDeviceUID: String?
    var effectiveOutputDeviceUID: String?
    var outputDeviceUnavailable: Bool
    var volume: Double

    var identity: MixerRowIdentity {
        MixerRowIdentity(rowID: id, persistenceID: persistenceID)
    }
}

/// An app the user took out of the mixer list, remembered by name so it can
/// be brought back even while it is not running (issue #300).
struct MixerHiddenApp: Identifiable, Equatable {
    let id: String
    let name: String
}

/// Per-app volume control, something macOS does not offer natively.
///
/// For every app the user turns down or routes to a specific output, a muted
/// CoreAudio process tap removes the app's sound from the original output, and
/// an aggregate device re-renders the tapped stream with the chosen gain. Apps
/// on the system default output at 100% are left completely untouched.
final class AppVolumeMixer: ObservableObject {
    static let shared = AppVolumeMixer()

    static var isSupported: Bool {
        if #available(macOS 14.4, *) { return true }
        return false
    }

    /// Volumes run 0...2: 1.0 is 100% (untouched passthrough), up to 2.0 is a
    /// 200% boost for sources that play too quietly.
    static let maxVolume: Double = 2.0

    @Published private(set) var apps: [MixerApp] = []
    @Published private(set) var outputDevices: [MixerOutputDevice] = []
    @Published private(set) var currentOutputDeviceUID: String?
    @Published private(set) var currentSystemSoundOutputDeviceUID: String?
    @Published private(set) var systemOutputVolume: Double?
    @Published private(set) var systemOutputMuted: Bool?
    @Published private(set) var outputSwitchError: String?
    /// Set when tap creation fails with a permission error, so the panel can
    /// point at the System Audio Recording consent.
    @Published private(set) var needsPermission = false
    /// Apps kept out of the list (issue #300), including the Finder when its
    /// own toggle hides it, so the panel can offer to bring any of them back.
    @Published private(set) var hiddenApps: [MixerHiddenApp] = []

    private var engines: [String: any GainEngine] = [:]
    /// Arbitrates the engine builds running off-main: it suppresses duplicate
    /// builds while a slider keeps dragging, and discards a build that lands
    /// after the mixer moved on (which would leave two live taps on one app).
    private var builds = MixerEngineBuilds()
    /// When each row's engine last changed, so a row whose audio objects
    /// flicker is rebuilt once instead of once per notification.
    private var engineChangeAt: [String: Double] = [:]
    /// When each row's audio last went away. Kept apart from the change stamp
    /// above: the wait before letting a tap go has to be measured from the
    /// moment the audio disappeared, not from whenever the tap was built.
    private var objectsLostAt: [String: Double] = [:]
    /// The last render count seen for each row's engine, so reconciliation
    /// can tell an engine that is rendering from one the HAL quietly stopped
    /// driving after sleep or a device reconfiguration (issue #341).
    private var engineRenderProgress: [String: MixerRoutingSupport.EngineRenderObservation] = [:]
    /// A dead audio path gets one replacement. If that exact replacement also
    /// never renders, the row stays untapped so system audio fails open.
    private var engineRecovery = MixerEngineRecovery()
    private var engineReconcilePending = false
    /// Volumes and routes of rows without a bundle id: adjustable while the
    /// process runs, never written to disk.
    private var sessionVolumes: [String: Double] = [:]
    private var sessionRoutes: [String: String] = [:]
    private var lastAudibleVolume: [String: Double] = [:]
    private var listenerInstalled = false
    /// Device priority needs the output/default substrate without per-app
    /// process discovery. A feature transition restarts the listener set when
    /// this mode changes, so priority-only operation never scans processes.
    private var processMonitoringEnabled = false
    /// Whether this mixer started AirPlay tracking. Only then is there a
    /// manager to stop: creating one loads the private routing stack, which
    /// audio priority and the output switcher alone never need.
    private var airPlayActive = false
    /// The global HAL listeners (devices, default output, process list), kept
    /// so stop() can remove each one again when the mixer leaves the hub.
    private var globalListeners: [AudioObjectPropertySelector] = []
    /// Running-state listeners per live process object, kept so every
    /// registration can be removed when the process disappears.
    private var runningListeners: [AudioObjectID: Set<AudioObjectPropertySelector>] = [:]
    /// Volume and mute belong to the current output device, not the HAL's
    /// system object, so these listeners move whenever that device changes.
    private var outputControlListenerDevice: AudioObjectID?
    private var outputControlListenerAddresses: [AudioObjectPropertyAddress] = []
    private var outputControlRefreshGeneration = 0
    private var stopped = false
    /// Waking can invalidate a live tap without an audio notification, so it
    /// requests a fresh snapshot and restarts the render observations.
    private var wakeObserver: NSObjectProtocol?
    private var lastAutomaticLoweredOutputUID: String?
    /// The output volume as it was before the headphone disconnect protection
    /// lowered it, so the speakers can be handed back the way they were found.
    private var loweredOutput: LoweredOutput?
    private var refreshPending = false
    private var lastListenerRefreshAt: CFAbsoluteTime = 0
    /// Decides which HAL pass gets to publish: one reader at a time, and a
    /// pass the mixer no longer wants is dropped rather than publishing state
    /// that is already out of date.
    private var refresh = MixerRefreshCoordinator()
    private let buildQueue = DispatchQueue(label: "com.brastoo.utils.mixer", qos: .userInitiated)
    /// Every CoreAudio property read runs here, and every HAL notification is
    /// delivered here. Reads serialize behind the audio daemon's device state,
    /// so while a device is being reconfigured (headphones pairing, an
    /// interface renegotiating, a display with audio waking) a single read can
    /// wait for as long as the daemon holds that device — and a reconfiguration
    /// is exactly what fires the listeners in the first place.
    ///
    /// Deliberately not `buildQueue`: creating a tap and its aggregate device
    /// takes far longer than reading a property, and the panel must never wait
    /// behind one to learn which devices exist.
    private struct OutputAdjustment {
        let device: AudioObjectID
        let lifetime: UUID
        var volume: Double?
        var muted: Bool?
        var completion: (Bool) -> Void
    }
    private var pendingOutputAdjustment: OutputAdjustment?
    private var outputWriteInFlight: OutputAdjustment?
    /// One volume or mute key waiting on the output's own reading. A nil
    /// `level` toggles mute.
    private struct OutputStep {
        let level: ((Double) -> Double)?
        let completion: (Bool) -> Void
    }
    private var queuedOutputSteps: [OutputStep] = []
    private var outputStepReadInFlight = false
    private var outputStepReadGeneration = 0
    private let outputControlLock = NSLock()
    private var outputControlLifetime = UUID()
    private let halQueue = DispatchQueue(label: "com.brastoo.utils.mixer.hal", qos: .userInitiated)

    private init() {}

    // MARK: - Lifecycle

    /// System device observation is shared with Audio device priority and the
    /// output switcher. The per-app portion still follows only Volume mixer.
    func syncWithPreferences() {
        let needs = MixerRoutingSupport.observationNeeds(isAvailable: { $0.isAvailable })
        guard needs.devices else {
            stop()
            return
        }

        if listenerInstalled, processMonitoringEnabled != needs.processes {
            stop()
        }
        start()
    }

    /// Starts watching audio processes. Saved volumes re-apply as soon as the
    /// matching app produces sound — no panel interaction needed.
    func start() {
        stopped = false
        processMonitoringEnabled = AppFeature.mixer.isAvailable
        if processMonitoringEnabled {
            publishHiddenApps()
            // Created here, on the main thread, before any refresh reads the
            // AirPlay snapshot from the HAL queue.
            AirPlayRouteManager.shared.activate { [weak self] in
                self?.refreshApps()
            }
            airPlayActive = true
        }
        guard !listenerInstalled else {
            refreshApps()
            return
        }
        listenerInstalled = true
        installListener(selector: kAudioHardwarePropertyDevices)
        installListener(selector: kAudioHardwarePropertyDefaultOutputDevice)
        installListener(selector: kAudioHardwarePropertyDefaultSystemOutputDevice)
        if processMonitoringEnabled, Self.isSupported {
            installListener(selector: kAudioHardwarePropertyProcessObjectList)
        }
        if wakeObserver == nil {
            wakeObserver = NSWorkspace.shared.notificationCenter.addObserver(
                forName: NSWorkspace.didWakeNotification,
                object: nil, queue: .main) { [weak self] _ in
                guard let self else { return }
                // A wake can wedge an engine while leaving the HAL snapshot
                // byte-identical, and apply() skips reconciliation when
                // nothing changed. Dropping the stored render observations
                // and reconciling directly arms the note-then-recheck
                // sequence deterministically, so a frozen engine is caught
                // even on a quiet wake.
                self.engineRenderProgress.removeAll()
                self.engineRecovery.clearAll()
                // An output that drops away during sleep can come back under
                // the same object ID without the volume and mute listeners
                // registered on it, and the level it reports then goes stale.
                // Forgetting the registration makes this refresh subscribe again.
                self.removeOutputControlListeners()
                self.refreshApps()
                self.reconcileEngines(with: self.apps)
                self.scheduleEngineReconcile(after: 2)
            }
        }
        refreshApps()
    }

    /// Tears every tap down so all apps return to untouched system output, and
    /// hands back the one system setting the mixer changes on its own.
    func stopAll() {
        stopped = true
        builds.invalidateAll()
        for engine in engines.values { engine.stop() }
        engines.removeAll()
        engineChangeAt.removeAll()
        objectsLostAt.removeAll()
        engineRenderProgress.removeAll()
        engineRecovery.clearAll()
        restoreLoweredOutputVolume()
    }

    /// Full teardown for the hub: taps, per-process listeners and the global
    /// HAL listeners all go away, and the published state empties out.
    func stop() {
        stopAll()
        sessionVolumes.removeAll()
        sessionRoutes.removeAll()
        // A refresh already reading the HAL must not publish into a mixer that
        // is no longer watching, nor re-register the listeners just removed.
        refresh.discardInFlight()
        pruneRunningListeners(keeping: [])
        removeGlobalListeners()
        if let wakeObserver {
            NSWorkspace.shared.notificationCenter.removeObserver(wakeObserver)
            self.wakeObserver = nil
        }
        if airPlayActive {
            AirPlayRouteManager.shared.deactivate()
            airPlayActive = false
        }
        if !apps.isEmpty { apps = [] }
        if !hiddenApps.isEmpty { hiddenApps = [] }
        if !outputDevices.isEmpty { outputDevices = [] }
        if currentOutputDeviceUID != nil { currentOutputDeviceUID = nil }
        if currentSystemSoundOutputDeviceUID != nil { currentSystemSoundOutputDeviceUID = nil }
        if systemOutputVolume != nil { systemOutputVolume = nil }
        if systemOutputMuted != nil { systemOutputMuted = nil }
        if outputSwitchError != nil { outputSwitchError = nil }
        if needsPermission { needsPermission = false }
        processMonitoringEnabled = false
    }

    /// What the audio system calls when something changes.
    ///
    /// Deliberately the smallest possible answer: the system decides which
    /// thread this arrives on and it is not always the same one, so all it
    /// does is ask the main thread for a refresh and return. Everything the
    /// refresh then reads from the audio system happens away from the main
    /// thread.
    ///
    /// This is the plain callback rather than the closure form on purpose.
    /// Handing a closure back to be removed never matches the one that was
    /// registered: the call answers that it worked and the listener stays,
    /// which measured as two live registrations after one removal and one
    /// re-registration. Matching on this function and the pointer below works.
    private static let listenerCallback: AudioObjectPropertyListenerProc = { _, _, _, client in
        guard let client else { return noErr }
        let mixer = Unmanaged<AppVolumeMixer>.fromOpaque(client).takeUnretainedValue()
        DispatchQueue.main.async { mixer.scheduleListenerRefresh() }
        return noErr
    }

    private static let outputControlListenerCallback: AudioObjectPropertyListenerProc = {
        device, _, _, client in
        guard let client else { return noErr }
        let mixer = Unmanaged<AppVolumeMixer>.fromOpaque(client).takeUnretainedValue()
        DispatchQueue.main.async { mixer.scheduleOutputControlRefresh(for: device) }
        return noErr
    }

    /// Identifies these registrations as ours. Unretained is safe here and
    /// only here: the mixer is a single instance that lives as long as the app.
    private var listenerClient: UnsafeMutableRawPointer {
        Unmanaged.passUnretained(self).toOpaque()
    }

    private func installListener(selector: AudioObjectPropertySelector) {
        var address = AudioObjectPropertyAddress(mSelector: selector,
                                                 mScope: kAudioObjectPropertyScopeGlobal,
                                                 mElement: kAudioObjectPropertyElementMain)
        guard AudioObjectAddPropertyListener(AudioObjectID(kAudioObjectSystemObject),
                                             &address,
                                             Self.listenerCallback,
                                             listenerClient) == noErr else { return }
        globalListeners.append(selector)
    }

    private func removeGlobalListeners() {
        guard listenerInstalled else { return }
        listenerInstalled = false
        removeOutputControlListeners()
        for selector in globalListeners {
            var address = AudioObjectPropertyAddress(mSelector: selector,
                                                     mScope: kAudioObjectPropertyScopeGlobal,
                                                     mElement: kAudioObjectPropertyElementMain)
            AudioObjectRemovePropertyListener(AudioObjectID(kAudioObjectSystemObject),
                                              &address,
                                              Self.listenerCallback,
                                              listenerClient)
        }
        globalListeners.removeAll()
    }

    private func subscribeToOutputControls(of device: AudioObjectID?) {
        guard outputControlListenerDevice != device else { return }
        removeOutputControlListeners()
        guard let device else { return }

        let selectors = Self.outputVolumeSelectors + [kAudioDevicePropertyMute]
        for selector in selectors {
            var address = AudioObjectPropertyAddress(mSelector: selector,
                                                     mScope: kAudioObjectPropertyScopeOutput,
                                                     mElement: kAudioObjectPropertyElementMain)
            guard AudioObjectHasProperty(device, &address) else { continue }
            if AudioObjectAddPropertyListener(device, &address,
                                              Self.outputControlListenerCallback,
                                              listenerClient) == noErr {
                outputControlListenerAddresses.append(address)
            }
        }
        if !outputControlListenerAddresses.isEmpty {
            outputControlListenerDevice = device
        }
    }

    private func removeOutputControlListeners() {
        if let device = outputControlListenerDevice {
            for var address in outputControlListenerAddresses {
                AudioObjectRemovePropertyListener(device, &address,
                                                  Self.outputControlListenerCallback,
                                                  listenerClient)
            }
        }
        outputControlListenerDevice = nil
        outputControlListenerAddresses.removeAll()
        outputControlRefreshGeneration &+= 1
        outputControlLock.withLock { outputControlLifetime = UUID() }
        let pending = pendingOutputAdjustment
        pendingOutputAdjustment = nil
        // Superseded keys are handled: replaying them would adjust the new output.
        pending?.completion(true)
        outputStepReadInFlight = false
        settleQueuedOutputSteps(handled: true)
    }

    private func scheduleOutputControlRefresh(for device: AudioObjectID) {
        guard listenerInstalled, outputControlListenerDevice == device else { return }
        outputControlRefreshGeneration &+= 1
        let generation = outputControlRefreshGeneration
        // A drag and the volume keys can emit several properties for each
        // step. Read once after the burst so an older callback cannot pull the
        // slider back while a newer value is already on screen.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.03) { [weak self] in
            guard let self,
                  self.listenerInstalled,
                  self.outputControlListenerDevice == device,
                  self.outputControlRefreshGeneration == generation else { return }
            self.halQueue.async { [weak self] in
                let volume = Self.hasSettableOutputVolume(for: device)
                    ? Self.outputVolume(for: device).map(Double.init)
                    : nil
                let muted = Self.outputMuted(for: device)
                DispatchQueue.main.async {
                    guard let self,
                          self.listenerInstalled,
                          self.outputControlListenerDevice == device,
                          self.outputControlRefreshGeneration == generation else { return }
                    self.applyOutputControls(volume: volume, muted: muted)
                }
            }
        }
    }

    private func subscribeToRunningChanges(of object: AudioObjectID) {
        for selector in Self.runningListenerSelectors
        where runningListeners[object]?.contains(selector) != true {
            var address = Self.runningAddress(selector)
            if AudioObjectAddPropertyListener(object, &address,
                                              Self.listenerCallback, listenerClient) == noErr {
                runningListeners[object, default: []].insert(selector)
            }
        }
    }

    /// Drops the listeners of process objects that no longer exist. Removal on
    /// a dead object can fail; the entry is forgotten either way. Object ids do
    /// come back (the HAL reuses them for later processes), and a returning id
    /// is simply subscribed again on the next refresh.
    private func pruneRunningListeners(keeping current: Set<AudioObjectID>) {
        for object in runningListeners.keys.filter({ !current.contains($0) }) {
            guard let selectors = runningListeners.removeValue(forKey: object) else { continue }
            for selector in selectors {
                var address = Self.runningAddress(selector)
                AudioObjectRemovePropertyListener(object, &address,
                                                  Self.listenerCallback, listenerClient)
            }
        }
    }

    /// Some HAL versions change IsRunningOutput without sending its listener
    /// notification. IsRunning also reports output IO starting and stopping;
    /// keep both because input IO can already be running when output changes.
    private static let runningListenerSelectors: [AudioObjectPropertySelector] = [
        kAudioProcessPropertyIsRunningOutput, kAudioProcessPropertyIsRunning,
    ]

    private static func runningAddress(_ selector: AudioObjectPropertySelector) -> AudioObjectPropertyAddress {
        AudioObjectPropertyAddress(mSelector: selector,
                                   mScope: kAudioObjectPropertyScopeGlobal,
                                   mElement: kAudioObjectPropertyElementMain)
    }

    /// One hardware event fires several of the listeners above back-to-back
    /// (device list, default device, process list, plus one IsRunningOutput per
    /// process), and a busy audio HAL can keep that stream going for as long as
    /// the panel is open. An isolated notification still refreshes immediately
    /// (headphone unplug must react now); a burst is coalesced into one trailing
    /// refresh so the panel does not redraw once per listener.
    private func scheduleListenerRefresh() {
        guard !refreshPending else { return }
        let now = CFAbsoluteTimeGetCurrent()
        let elapsed = now - lastListenerRefreshAt
        if elapsed >= Self.listenerRefreshInterval {
            lastListenerRefreshAt = now
            refreshApps()
            return
        }
        refreshPending = true
        let delay = Self.listenerRefreshInterval - elapsed
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self else { return }
            self.refreshPending = false
            self.lastListenerRefreshAt = CFAbsoluteTimeGetCurrent()
            self.refreshApps()
        }
    }

    private static let listenerRefreshInterval: CFAbsoluteTime = 0.2

    // MARK: - Volume API (panel)

    /// UI feedback is immediate; one HAL write runs at a time and a burst
    /// retains only its newest requested level. Device changes never inherit
    /// a write intended for the previous output.
    func requestOutputAdjustment(volume: Double? = nil, muted: Bool? = nil,
                                 completion: @escaping (Bool) -> Void = { _ in }) {
        guard let device = outputControlListenerDevice,
              volume?.isFinite != false,
              volume == nil || systemOutputVolume != nil,
              muted == nil || systemOutputMuted != nil else { completion(false); return }
        // A direct control change supersedes keys pressed before it. The HAL
        // read for those keys may still finish later, so invalidate its value.
        outputStepReadGeneration &+= 1
        settleQueuedOutputSteps(handled: true)
        outputControlRefreshGeneration &+= 1
        let previous = pendingOutputAdjustment
        var adjustment = previous ?? OutputAdjustment(device: device,
            lifetime: outputControlLock.withLock { outputControlLifetime }, completion: completion)
        adjustment.completion = completion
        if let volume {
            let value = min(1, max(0, volume))
            adjustment.volume = value
            systemOutputVolume = value
            if value > 0, systemOutputMuted != nil {
                adjustment.muted = false
                systemOutputMuted = false
            }
        }
        if let muted { adjustment.muted = muted; systemOutputMuted = muted }
        pendingOutputAdjustment = adjustment
        previous?.completion(true)
        drainOutputAdjustment()
    }

    /// A volume key steps from the level the output reports now, not from the
    /// last published reading: after sleep an output can come back at another
    /// level without notifying, and stepping from the stale reading left the
    /// island at 21% while the speakers played at 2%. Keys pressed while that
    /// read runs queue behind it, and keys during this app's own write carry on
    /// from the level already requested. `level` receives the audible level
    /// (0 while muted) and returns the one to set.
    func requestOutputStep(level: @escaping (Double) -> Double,
                           completion: @escaping (Bool) -> Void = { _ in }) {
        enqueueOutputKey(OutputStep(level: level, completion: completion),
                         isAvailable: systemOutputVolume != nil)
    }

    /// The mute key rides the same read and queue as the volume keys, so it
    /// toggles the state the output reports now (a stale reading asked for the
    /// state already in place and the key did nothing), and a volume key right
    /// after it steps from the level that one read fetched.
    func requestOutputMuteToggle(completion: @escaping (Bool) -> Void = { _ in }) {
        enqueueOutputKey(OutputStep(level: nil, completion: completion),
                         isAvailable: systemOutputMuted != nil)
    }

    private func enqueueOutputKey(_ step: OutputStep, isAvailable: Bool) {
        guard let device = outputControlListenerDevice, isAvailable else {
            step.completion(false)
            return
        }
        queuedOutputSteps.append(step)
        guard !outputStepReadInFlight else { return }
        guard !hasCurrentOutputAdjustment else {
            applyQueuedOutputSteps()
            return
        }
        outputStepReadInFlight = true
        let readGeneration = outputStepReadGeneration
        let lifetime = outputControlLock.withLock { outputControlLifetime }
        halQueue.async { [weak self] in
            let isDefault = Self.defaultOutputDeviceID() == device
            let volume = isDefault && Self.hasSettableOutputVolume(for: device)
                ? Self.outputVolume(for: device).map(Double.init)
                : nil
            let muted = isDefault ? Self.outputMuted(for: device) : nil
            DispatchQueue.main.async {
                guard let self else { return }
                let current = self.outputControlListenerDevice == device
                    && self.outputControlLock.withLock { self.outputControlLifetime == lifetime }
                // Removing the old listeners already settled that lifetime's
                // keys. Its callback must not drain the new output's queue.
                guard current else { return }
                self.outputStepReadInFlight = false
                guard isDefault else {
                    // The keys were meant for an output that has since been
                    // replaced, as headphones taking over. Replaying a volume
                    // key natively would step the new output a full step per
                    // press, so those settle as handled, the way a pending
                    // adjustment does when its output changes. A native mute
                    // is the same toggle, so mute keys go back to the system
                    // and still mute what now plays. The mixer resubscribes
                    // to that output.
                    let steps = self.queuedOutputSteps
                    self.queuedOutputSteps.removeAll()
                    for step in steps { step.completion(step.level != nil) }
                    if current { self.scheduleListenerRefresh() }
                    return
                }
                // A direct control change since the read began already set
                // the level these keys continue from, read or not. A control
                // the default output lacks leaves its keys to the system; the
                // others still apply.
                let superseded = self.outputStepReadGeneration != readGeneration
                if !superseded, !self.hasCurrentOutputAdjustment {
                    if self.systemOutputVolume != volume { self.systemOutputVolume = volume }
                    if self.systemOutputMuted != muted { self.systemOutputMuted = muted }
                }
                self.applyQueuedOutputSteps()
            }
        }
    }

    private func settleQueuedOutputSteps(handled: Bool) {
        let steps = queuedOutputSteps
        queuedOutputSteps.removeAll()
        for step in steps { step.completion(handled) }
    }

    private func applyQueuedOutputSteps() {
        let steps = queuedOutputSteps
        queuedOutputSteps.removeAll()
        for step in steps {
            if let level = step.level {
                guard let volume = systemOutputVolume else {
                    step.completion(false)
                    continue
                }
                requestOutputAdjustment(volume: level(systemOutputMuted == true ? 0 : volume),
                                        completion: step.completion)
            } else {
                guard let muted = systemOutputMuted else {
                    step.completion(false)
                    continue
                }
                requestOutputAdjustment(muted: !muted, completion: step.completion)
            }
        }
    }

    private func isCurrentOutputAdjustment(_ adjustment: OutputAdjustment) -> Bool {
        outputControlLock.withLock { outputControlLifetime == adjustment.lifetime }
    }

    private var hasCurrentOutputAdjustment: Bool {
        pendingOutputAdjustment != nil || outputWriteInFlight.map(isCurrentOutputAdjustment) == true
    }

    private func applyOutputControls(volume: Double?, muted: Bool?) {
        guard !hasCurrentOutputAdjustment else { return }
        if systemOutputVolume != volume { systemOutputVolume = volume }
        if systemOutputMuted != muted { systemOutputMuted = muted }
    }

    private func drainOutputAdjustment() {
        guard outputWriteInFlight == nil, let adjustment = pendingOutputAdjustment else { return }
        pendingOutputAdjustment = nil
        guard isCurrentOutputAdjustment(adjustment), outputControlListenerDevice == adjustment.device else {
            adjustment.completion(true)
            return
        }
        outputWriteInFlight = adjustment
        halQueue.async { [weak self] in
            guard let self else { return }
            let device = adjustment.device
            var success = self.isCurrentOutputAdjustment(adjustment) && Self.defaultOutputDeviceID() == device
            if success, let volume = adjustment.volume { success = Self.setOutputVolume(Float(volume), for: device) }
            if success, let muted = adjustment.muted, self.isCurrentOutputAdjustment(adjustment) {
                success = Self.setOutputMuted(muted, for: device)
            }
            DispatchQueue.main.async {
                self.outputWriteInFlight = nil
                let current = self.isCurrentOutputAdjustment(adjustment)
                adjustment.completion(!current || success)
                if self.pendingOutputAdjustment != nil {
                    self.drainOutputAdjustment()
                } else if current {
                    self.scheduleOutputControlRefresh(for: device)
                } else {
                    self.scheduleListenerRefresh()
                }
            }
        }
    }

    @discardableResult
    func setCurrentOutputVolume(_ volume: Double) -> Bool {
        let clamped = min(max(volume, 0), 1)
        guard Self.setSystemOutputVolume(clamped) else {
            scheduleListenerRefresh()
            return false
        }
        if systemOutputVolume != clamped { systemOutputVolume = clamped }
        if clamped > 0, systemOutputMuted == true { systemOutputMuted = false }
        return true
    }

    /// 100% means bit-perfect passthrough (no tap). A value the UI would round to
    /// 100% counts as unity, so dragging near 100% or tapping reset both restore
    /// true passthrough; anything else (quieter or boosted) runs the gain engine.
    private func isUnity(_ volume: Double) -> Bool { MixerRoutingSupport.isUnity(volume) }

    func setVolume(_ volume: Double, for app: MixerApp) {
        guard !app.isBypassed else { return }
        engineRecovery.clear(app.id)
        let clamped = Defaults.sanitizedAppVolume(volume)
        persistVolume(clamped, for: app)
        if clamped > 0.001 { lastAudibleVolume[app.id] = clamped }
        if let index = apps.firstIndex(where: { $0.id == app.id }) {
            apps[index].volume = clamped
            let updated = apps[index]
            applyRouting(for: updated)
        } else {
            applyRouting(for: app)
        }
        // Changing gain alone cannot revive a stalled aggregate. Check the
        // render path as well, including when the HAL snapshot did not change.
        reconcileEngines(with: apps)
    }

    func setOutputDeviceUID(_ uid: String?, for app: MixerApp) {
        guard !app.isBypassed else { return }
        if uid == MixerRoutingSupport.airPlaySpeakerChoiceID {
            chooseAirPlaySpeaker(for: app)
            return
        }
        engineRecovery.clear(app.id)
        let sanitized = Defaults.sanitizedAppOutputDeviceUID(uid)
        persistOutputDeviceUID(sanitized, for: app)
        if let sanitized, MixerRoutingSupport.isAirPlaySentinel(sanitized), !AirPlayRouteManager.shared.isConnected {
            // After the menu that asked for it closes, so the list opens at the pointer.
            DispatchQueue.main.async { AirPlayRouteManager.shared.presentPicker() }
        }
        if let index = apps.firstIndex(where: { $0.id == app.id }) {
            apps[index].selectedOutputDeviceUID = sanitized
            applyOutputRoute(to: &apps[index],
                             savedOutputs: [app.id: sanitized].compactMapValues { $0 },
                             availableUIDs: MixerRoutingSupport.routableOutputUIDs(
                                outputDevices.map(\.uid),
                                airPlayConnected: AirPlayRouteManager.isSpeakerConnected),
                             defaultUID: currentOutputDeviceUID)
            // The running tap is left alone here: applyRouting builds the one
            // for the new device first and only then stops this one, so the
            // sound never falls back to the old output in between.
            applyRouting(for: apps[index])
        }
    }

    /// Choosing a speaker from an app's menu sends that app to AirPlay too,
    /// and opens the speaker list even while one is already picked.
    private func chooseAirPlaySpeaker(for app: MixerApp) {
        let routed = app.selectedOutputDeviceUID.map(MixerRoutingSupport.isAirPlaySentinel) == true
        let connected = AirPlayRouteManager.shared.isConnected
        // Without a speaker, routing the app opens the list on its own.
        if !routed { setOutputDeviceUID(AirPlayRouteManager.airPlaySentinelUID, for: app) }
        if routed || connected {
            DispatchQueue.main.async { AirPlayRouteManager.shared.presentPicker() }
        }
    }

    @discardableResult
    func setUniversalOutputDeviceUID(_ uid: String) -> Bool {
        setDefaultOutputDeviceUID(uid)
    }

    /// Priority changes only the normal system default. Unlike the manual
    /// universal picker, this must not erase explicit per-app routes or
    /// block the main thread while a device is being reconfigured.
    func setPriorityOutputDeviceUID(_ uid: String) {
        guard let sanitized = Defaults.sanitizedAppOutputDeviceUID(uid),
              let device = outputDevices.first(where: {
                  $0.uid == sanitized && $0.canBeDefaultOutput
              }) else {
            outputSwitchError = L10n.shared.s.mixerOutputUnavailable
            refreshApps()
            return
        }

        halQueue.async { [weak self] in
            let status = Self.setDefaultDevice(
                device.audioObjectID,
                selector: kAudioHardwarePropertyDefaultOutputDevice)
            DispatchQueue.main.async {
                guard let self, self.listenerInstalled else { return }
                if status == noErr {
                    if self.outputSwitchError != nil { self.outputSwitchError = nil }
                } else {
                    let message = "OSStatus \(status)"
                    if self.outputSwitchError != message { self.outputSwitchError = message }
                }
                // Let the HAL snapshot publish the actual default. Some
                // devices apply a successful write after a short delay, so an
                // immediate read-back would report a false picker error.
                self.refresh.discardInFlight()
                self.refreshApps()
            }
        }
    }

    @discardableResult
    private func setDefaultOutputDeviceUID(_ uid: String) -> Bool {
        guard let sanitized = Defaults.sanitizedAppOutputDeviceUID(uid),
              let device = outputDevices.first(where: { $0.uid == sanitized && $0.canBeDefaultOutput }) else {
            outputSwitchError = L10n.shared.s.mixerOutputUnavailable
            refreshApps()
            return false
        }

        let status = Self.setDefaultDevice(device.audioObjectID,
                                           selector: kAudioHardwarePropertyDefaultOutputDevice)
        guard status == noErr else {
            outputSwitchError = "OSStatus \(status)"
            refreshApps()
            return false
        }

        outputSwitchError = nil
        // The default app output just changed by this app's own hand, so a refresh
        // still reading the previous devices is thrown away; the one at the end
        // of this method replaces it.
        refresh.discardInFlight()
        let savedOutputUIDs = savedOutputDeviceUIDs()
        let preferences = MixerRoutingSupport.preferencesAfterUniversalOutputSwitch(
            outputDeviceUIDs: savedOutputUIDs,
            volumes: savedVolumes(),
            switchSucceeded: true)
        persistOutputDeviceUIDs(preferences.outputDeviceUIDs)

        currentOutputDeviceUID = device.uid
        outputDevices = outputDevices.map { outputDevice in
            MixerOutputDevice(id: outputDevice.id,
                              uid: outputDevice.uid,
                              name: outputDevice.name,
                              isDefault: outputDevice.uid == device.uid,
                              isHeadphones: outputDevice.isHeadphones,
                              canBeDefaultOutput: outputDevice.canBeDefaultOutput,
                              canBeDefaultSystemOutput: outputDevice.canBeDefaultSystemOutput,
                              priorityTier: outputDevice.priorityTier,
                              audioObjectID: outputDevice.audioObjectID)
        }

        // Builds started for the previous device can no longer be installed;
        // the engines themselves stay live until reconciliation has their
        // replacement running on the new device.
        builds.invalidateAll()

        let availableUIDs = MixerRoutingSupport.routableOutputUIDs(
            outputDevices.map(\.uid),
            airPlayConnected: AirPlayRouteManager.isSpeakerConnected)
        apps = apps.map { current in
            var app = current
            app.volume = storedVolume(for: app.identity, saved: preferences.volumes) ?? app.volume
            applyOutputRoute(to: &app,
                             savedOutputs: preferences.outputDeviceUIDs,
                             availableUIDs: availableUIDs,
                             defaultUID: device.uid)
            return app
        }
        reconcileEngines(with: apps)
        clearPermissionIfNoActiveAdjustments()
        refreshApps()
        return true
    }

    @discardableResult
    func setSystemSoundOutputDeviceUID(_ uid: String) -> Bool {
        guard let sanitized = Defaults.sanitizedAppOutputDeviceUID(uid),
              let device = outputDevices.first(where: {
                  $0.uid == sanitized && $0.canBeDefaultSystemOutput
              }) else {
            outputSwitchError = L10n.shared.s.mixerOutputUnavailable
            refreshApps()
            return false
        }

        let status = Self.setDefaultDevice(
            device.audioObjectID,
            selector: kAudioHardwarePropertyDefaultSystemOutputDevice)
        guard status == noErr else {
            outputSwitchError = "OSStatus \(status)"
            refreshApps()
            return false
        }

        outputSwitchError = nil
        refresh.discardInFlight()
        currentSystemSoundOutputDeviceUID = device.uid
        refreshApps()
        return true
    }

    @discardableResult
    func switchToNextSoundOutput(in selectedUIDs: [String]) -> Bool {
        let availableUIDs = Set(outputDevices.filter(\.canBeDefaultOutput).map(\.uid))
        guard let nextUID = MixerRoutingSupport.nextSelectedOutputDeviceUID(
            currentUID: currentOutputDeviceUID,
            selectedUIDs: selectedUIDs,
            availableUIDs: availableUIDs) else {
            // With an available selection, no next output means the only one is already playing.
            return selectedUIDs.contains { rawUID in
                MixerRoutingSupport.sanitizedDeviceUID(rawUID).map { availableUIDs.contains($0) } ?? false
            }
        }
        return setUniversalOutputDeviceUID(nextUID)
    }

    func toggleMute(_ app: MixerApp) {
        if app.volume > 0.001 {
            lastAudibleVolume[app.id] = app.volume
            setVolume(0, for: app)
        } else {
            setVolume(lastAudibleVolume[app.id] ?? 1, for: app)
        }
    }

    /// Main-thread only. Engine creation happens off-main (CoreAudio object
    /// setup takes tens of milliseconds) and lands back here exactly once.
    ///
    /// A tap mutes the app on the real output and replays it through the
    /// aggregate, so an engine that goes away for even a moment hands the app
    /// straight back to the speakers at full volume. Replacements are built
    /// first and the old engine is stopped only once the new one is running.
    private func applyRouting(for app: MixerApp) {
        guard !stopped else { return }
        guard !app.isBypassed else {
            discardEngine(for: app.id)
            return
        }
        guard let targetOutputDeviceUID = app.effectiveOutputDeviceUID,
              appNeedsEngine(app) else {
            // System default at 100% stays true passthrough.
            discardEngine(for: app.id)
            clearPermissionIfNoActiveAdjustments()
            return
        }
        if let engine = engines[app.id],
           engine.tappedObjects == app.audioObjects,
           engine.outputDeviceUID == targetOutputDeviceUID {
            engine.gain = Float(app.volume)
            return
        }
        // Nothing is ever tapped on behalf of an app the user never adjusted.
        guard rowMayBeTapped(app) else {
            discardEngine(for: app.id)
            clearPermissionIfNoActiveAdjustments()
            return
        }
        let configuration = MixerEngineRecovery.Configuration(
            objects: app.audioObjects,
            outputDeviceUID: targetOutputDeviceUID)
        guard engineRecovery.allowsBuild(app.id, configuration: configuration) else { return }
        guard #available(macOS 14.4, *), let token = builds.begin(app.id) else { return }

        if MixerRoutingSupport.isAirPlaySentinel(targetOutputDeviceUID) {
            // Without a listed Mac output to clock it, the engine would count
            // as gone on every pass. A device list without one is a passing
            // state, and the next refresh builds again.
            guard let clockUID = clockDeviceUIDForAirPlayTap() else {
                builds.finish(app.id, token: token)
                return
            }
            buildQueue.async { [weak self] in
                // No renderer, no stream: the app stays on its current path
                // instead of being tapped into silence, and this is not a
                // missing permission, so the permission hint stays hidden.
                guard AirPlayRouteManager.shared.prepareToStream() else {
                    DispatchQueue.main.async {
                        self?.finishUnavailableAirPlayBuild(for: app.id, token: token)
                    }
                    return
                }
                let engine = AirPlayGainEngine(appID: app.id,
                                               objects: app.audioObjects,
                                               gain: Float(app.volume),
                                               clockDeviceUID: clockUID)
                if engine == nil {
                    AirPlayRouteManager.shared.stopIfIdle()
                }
                DispatchQueue.main.async {
                    guard let self else {
                        engine?.stop()
                        return
                    }
                    self.install(engine, for: app.id, token: token)
                }
            }
            return
        }

        buildQueue.async { [weak self] in
            let engine = TapGainEngine(objects: app.audioObjects,
                                       gain: Float(app.volume),
                                       outputDeviceUID: targetOutputDeviceUID)
            DispatchQueue.main.async {
                guard let self else {
                    engine?.stop()
                    return
                }
                self.install(engine, for: app.id, token: token)
            }
        }
    }

    /// An AirPlay build that could not get a renderer ends here, not in
    /// `install`: whatever already plays the app keeps playing it, and the
    /// permission hint (which `install` shows for a failed tap) stays hidden.
    private func finishUnavailableAirPlayBuild(for id: String, token: Int) {
        builds.finish(id, token: token)
        // Shown as unavailable from now on, and not retried on every pass.
        AirPlayRouteManager.shared.reportStreamingFailure()
    }

    /// A listed Mac output, the current one when it is listed: an engine
    /// counts as gone once its clock is no longer listed.
    private func clockDeviceUIDForAirPlayTap() -> String? {
        let hardware = outputDevices.map(\.uid).filter { !MixerRoutingSupport.isAirPlaySentinel($0) }
        if let current = currentOutputDeviceUID, hardware.contains(current) { return current }
        return hardware.first
    }

    /// Lands one finished build on the main thread.
    private func install(_ engine: (any GainEngine)?, for id: String, token: Int) {
        let isCurrentBuild = builds.isCurrent(id, token: token)
        builds.finish(id, token: token)
        // A build that started before the mixer moved on (feature switched
        // off, output device changed, a newer build for the same row) would
        // add a second live tap to the app and render its sound twice.
        guard isCurrentBuild, !stopped else {
            engine?.stop()
            return
        }
        guard let engine else {
            // The tap could not be created: keeping the engine that is already
            // running beats leaving the app with none, unless it renders to a
            // device that is gone, in which case it can only mute the app.
            if let running = engines[id],
               !MixerRoutingSupport.engineOutputIsPresent(running.outputDeviceUID,
                                                          clockUID: running.clockDeviceUID,
                                                          listedUIDs: outputDevices.map(\.uid),
                                                          airPlayConnected: AirPlayRouteManager.isSpeakerConnected) {
                discardEngine(for: id)
            }
            // A row that still has a tap running is plainly not being refused
            // for lack of consent, so the permission hint stays out of it.
            if engines[id] == nil, !needsPermission {
                needsPermission = true
            }
            return
        }
        if needsPermission {
            needsPermission = false
        }
        // The slider may have moved (or returned to 100%) while the engine was
        // being built, or the app's audio objects may have changed. Honor the
        // latest state, never an old tap target.
        guard let latestApp = apps.first(where: { $0.id == id }) else {
            engine.stop()
            return
        }
        guard latestApp.audioObjects == engine.tappedObjects,
              latestApp.effectiveOutputDeviceUID == engine.outputDeviceUID,
              appNeedsEngine(latestApp) else {
            engine.stop()
            applyRouting(for: latestApp)
            return
        }
        engine.gain = Float(latestApp.volume)
        let previous = engines.updateValue(engine, forKey: id)
        engineChangeAt[id] = CFAbsoluteTimeGetCurrent()
        // The fresh engine starts its render count over.
        engineRenderProgress.removeValue(forKey: id)
        previous?.stop()
        // A tap mutes immediately. Arm the render check here instead of
        // waiting for another HAL event, or a dead first aggregate can leave
        // the app silent until the mixer quits (issue #601).
        reconcileEngines(with: apps)
    }

    /// Stops and forgets a row's engine. Used where silence is the intent
    /// (back to 100% on the default output, row gone), never for a rebuild.
    private func discardEngine(for id: String) {
        engines.removeValue(forKey: id)?.stop()
        engineChangeAt.removeValue(forKey: id)
        objectsLostAt.removeValue(forKey: id)
        engineRenderProgress.removeValue(forKey: id)
        engineRecovery.clear(id)
    }

    private func rowMayBeTapped(_ app: MixerApp) -> Bool {
        MixerRoutingSupport.rowMayBeTapped(
            savedVolume: storedVolume(for: app.identity, saved: savedVolumes()),
            savedRouteUID: storedRoute(for: app.identity, saved: savedOutputDeviceUIDs()),
            defaultOutputDeviceUID: currentOutputDeviceUID)
    }

    private func appNeedsEngine(_ app: MixerApp) -> Bool {
        MixerRoutingSupport.requiresEngine(hasAudioObjects: !app.audioObjects.isEmpty,
                                           volume: app.volume,
                                           selectedOutputDeviceUID: app.selectedOutputDeviceUID,
                                           targetOutputDeviceUID: app.effectiveOutputDeviceUID,
                                           defaultOutputDeviceUID: currentOutputDeviceUID)
    }

    private func applyOutputRoute(to app: inout MixerApp,
                                  savedOutputs: [String: String],
                                  availableUIDs: Set<String>,
                                  defaultUID: String?) {
        let selectedUID = storedRoute(for: app.identity, saved: savedOutputs)
        app.selectedOutputDeviceUID = selectedUID
        app.effectiveOutputDeviceUID = MixerRoutingSupport.effectiveDeviceUID(
            selectedUID: selectedUID,
            availableUIDs: availableUIDs,
            defaultUID: defaultUID)
        app.outputDeviceUnavailable = MixerRoutingSupport.selectedDeviceUnavailable(
            selectedUID: selectedUID,
            availableUIDs: availableUIDs)
    }

    // MARK: - Process discovery

    /// The main-thread state one refresh pass needs, copied in so the HAL pass
    /// never reads a property that another thread can be writing.
    private struct RefreshRequest {
        let includeApps: Bool
        let previousDefaultUID: String?
        let previousOutputDevices: [MixerOutputDevice]
        let lowered: LoweredOutputState
        let lowerOnHeadphonesDisconnect: Bool
        let lowerToPercent: Int
        let savedVolumes: [String: Double]
        let savedOutputs: [String: String]
        let sessionVolumes: [String: Double]
        let sessionRoutes: [String: String]
        let showFinder: Bool
        /// Persistence ids the list must leave out: the apps the user hid,
        /// plus the Finder while its toggle is off (issue #300).
        let hiddenRowIDs: Set<String>
        let ownPid: pid_t
    }

    /// Everything one refresh read from the HAL, handed back for the main
    /// thread to turn into published state.
    private struct RefreshSnapshot {
        let defaultUID: String?
        let systemSoundUID: String?
        let outputDevices: [MixerOutputDevice]
        let defaultDeviceID: AudioObjectID?
        let systemOutputVolume: Double?
        let systemOutputMuted: Bool?
        /// Nil where process taps do not exist (before macOS 14.4): the app
        /// list stays empty and no process object is looked at.
        let apps: [MixerApp]?
        let processObjects: [AudioObjectID]
        let lowered: LoweredOutputState
    }

    /// Kicks off one refresh. Reading the audio HAL happens on `halQueue`;
    /// everything published, every engine and every listener record is touched
    /// back on the main thread, where it lives.
    func refreshApps() {
        // A throttled refresh can land after stop(); watching is over.
        guard listenerInstalled else { return }
        // A pass already reading the HAL holds the slot: running a second one
        // now would read against state the first has not published yet. The
        // request is remembered and runs as soon as that one lands.
        guard let generation = refresh.begin() else { return }
        let request = RefreshRequest(
            includeApps: processMonitoringEnabled,
            previousDefaultUID: currentOutputDeviceUID,
            previousOutputDevices: outputDevices,
            lowered: LoweredOutputState(lastAutomaticLoweredOutputUID: lastAutomaticLoweredOutputUID,
                                        loweredOutput: loweredOutput),
            lowerOnHeadphonesDisconnect: AppFeature.mixer.isAvailable
                && UserDefaults.standard.bool(forKey: DefaultsKey.mixerLowerVolumeOnHeadphonesDisconnect),
            lowerToPercent: Defaults.sanitizedMixerHeadphonesDisconnectVolumePercent(
                UserDefaults.standard.integer(forKey: DefaultsKey.mixerHeadphonesDisconnectVolumePercent)),
            savedVolumes: savedVolumes(),
            savedOutputs: savedOutputDeviceUIDs(),
            sessionVolumes: sessionVolumes,
            sessionRoutes: sessionRoutes,
            showFinder: UserDefaults.standard.bool(forKey: DefaultsKey.mixerShowFinder),
            hiddenRowIDs: MixerRoutingSupport.hiddenRowIDs(
                hiddenApps: savedHiddenApps(),
                showFinder: UserDefaults.standard.bool(forKey: DefaultsKey.mixerShowFinder)),
            ownPid: ProcessInfo.processInfo.processIdentifier)

        halQueue.async { [weak self] in
            let snapshot = Self.readSnapshot(request)
            DispatchQueue.main.async {
                self?.apply(snapshot, generation: generation)
            }
        }
    }

    /// Main thread. Turns one HAL snapshot into published state, engines and
    /// listener records, in the same order the synchronous version used.
    private func apply(_ snapshot: RefreshSnapshot, generation: Int) {
        // The mixer no longer wants this pass (it stopped, or changed the
        // output itself, while the pass was reading). The one thing still
        // worth keeping is a volume the pass lowered on the HAL, so the
        // speakers can be handed back later.
        guard refresh.finish(generation) else {
            if snapshot.lowered.loweredOutput != nil {
                lastAutomaticLoweredOutputUID = snapshot.lowered.lastAutomaticLoweredOutputUID
                loweredOutput = snapshot.lowered.loweredOutput
            }
            return
        }
        let refreshAgain = refresh.takeRepeatRequest()
        guard listenerInstalled else { return }
        defer { if refreshAgain { refreshApps() } }

        lastAutomaticLoweredOutputUID = snapshot.lowered.lastAutomaticLoweredOutputUID
        loweredOutput = snapshot.lowered.loweredOutput

        if (snapshot.defaultUID != currentOutputDeviceUID
            || snapshot.systemSoundUID != currentSystemSoundOutputDeviceUID),
           outputSwitchError != nil {
            outputSwitchError = nil
        }
        let audioEnvironmentChanged = currentOutputDeviceUID != nil
            && (snapshot.defaultUID != currentOutputDeviceUID || snapshot.outputDevices != outputDevices)
        if audioEnvironmentChanged {
            // Builds aimed at the previous audio environment can no longer be
            // installed; reconciliation below replaces the live engines one by
            // one, each new tap running before its predecessor stops.
            builds.invalidateAll()
        }
        // Assigning a @Published property signals SwiftUI even when the value is
        // identical, and refreshes run on every CoreAudio notification — publish
        // only real changes or a chatty HAL re-renders the panel continuously.
        if currentOutputDeviceUID != snapshot.defaultUID {
            currentOutputDeviceUID = snapshot.defaultUID
        }
        if currentSystemSoundOutputDeviceUID != snapshot.systemSoundUID {
            currentSystemSoundOutputDeviceUID = snapshot.systemSoundUID
        }
        if snapshot.outputDevices != outputDevices {
            outputDevices = snapshot.outputDevices
        }
        subscribeToOutputControls(of: snapshot.defaultDeviceID)
        applyOutputControls(volume: snapshot.systemOutputVolume, muted: snapshot.systemOutputMuted)

        guard let next = snapshot.apps else {
            if !apps.isEmpty {
                apps = []
            }
            return
        }

        pruneRunningListeners(keeping: Set(snapshot.processObjects))
        for object in snapshot.processObjects {
            // Audio starting/stopping can leave the process object list
            // unchanged — subscribe to its running-state properties.
            subscribeToRunningChanges(of: object)
        }

        guard audioEnvironmentChanged || next != apps else { return }
        if apps != next {
            apps = next
        }
        reconcileEngines(with: next)
        clearPermissionIfNoActiveAdjustments()
    }

    /// Runs on `halQueue`. Every CoreAudio read of a refresh happens here and
    /// nothing outside the returned snapshot is touched.
    private static func readSnapshot(_ request: RefreshRequest) -> RefreshSnapshot {
        let defaultUID = defaultOutputDeviceUID(selector: kAudioHardwarePropertyDefaultOutputDevice)
        let systemSoundUID = defaultOutputDeviceUID(
            selector: kAudioHardwarePropertyDefaultSystemOutputDevice)
        let nextOutputDevices = outputDevices(defaultUID: defaultUID)
        let defaultDevice = nextOutputDevices.first { $0.uid == defaultUID }
        let availableUIDs = MixerRoutingSupport.routableOutputUIDs(
            nextOutputDevices.map(\.uid),
            airPlayConnected: AirPlayRouteManager.isSpeakerConnected)
        let lowered = loweringOutputVolumeIfHeadphonesDisconnected(
            state: request.lowered,
            previousDefaultUID: request.previousDefaultUID,
            previousOutputDevices: request.previousOutputDevices,
            nextDefaultUID: defaultUID,
            nextOutputDevices: nextOutputDevices,
            lowerOnDisconnect: request.lowerOnHeadphonesDisconnect,
            lowerToPercent: request.lowerToPercent)
        let systemOutputVolume = defaultDevice.flatMap { device in
            hasSettableOutputVolume(for: device.audioObjectID)
                ? outputVolume(for: device.audioObjectID).map(Double.init)
                : nil
        }
        let systemOutputMuted = defaultDevice.flatMap { outputMuted(for: $0.audioObjectID) }

        guard request.includeApps, isSupported else {
            return RefreshSnapshot(defaultUID: defaultUID,
                                   systemSoundUID: systemSoundUID,
                                   outputDevices: nextOutputDevices,
                                   defaultDeviceID: defaultDevice?.audioObjectID,
                                   systemOutputVolume: systemOutputVolume,
                                   systemOutputMuted: systemOutputMuted,
                                   apps: nil,
                                   processObjects: [],
                                   lowered: lowered)
        }

        let ownPid = request.ownPid
        let saved = request.savedVolumes
        let savedOutputs = request.savedOutputs
        let showFinder = request.showFinder
        var groups: [pid_t: [AudioObjectID]] = [:]
        var playing: Set<pid_t> = []
        var bypassed: Set<pid_t> = []
        var bundleHints: [pid_t: String] = [:]
        let processObjects = audioProcessObjects()
        for object in processObjects {
            var pid: pid_t = -1
            guard Self.read(object, kAudioProcessPropertyPID, &pid), pid > 0, pid != ownPid else { continue }

            // Show every regular app that holds an audio connection, not only
            // the ones making sound this instant, so apps are adjustable before
            // they play and stay put between sounds.
            guard let app = ResponsibleProcess.regularAppOwner(of: pid) else { continue }
            let owner = app.processIdentifier
            let name = ResponsibleProcess.displayName(pid: owner, fallback: app.localizedName ?? "pid \(owner)")
            // Bypassed apps (Zoom, DAWs) still get a row — hiding them read
            // as a bug (issue #177) — but they are never tapped: volume
            // pinned at unity, no saved routing, so appNeedsEngine is always
            // false for them.
            if MixerRoutingSupport.bypassesProcessTap(bundleIdentifier: app.bundleIdentifier,
                                                      name: name) {
                bypassed.insert(owner)
            }

            var running: UInt32 = 0
            _ = Self.read(object, kAudioProcessPropertyIsRunningOutput, &running)
            if running != 0 { playing.insert(owner) }

            groups[owner, default: []].append(object)
            if bundleHints[owner] == nil {
                // The audio object knows the bundle id of its own process,
                // which is the app itself whenever it plays its own sound.
                // For a helper that plays on an app's behalf the owner found
                // above is the app, and its bundle id is the one that counts.
                bundleHints[owner] = app.bundleIdentifier
                    ?? (pid == owner ? Self.processBundleIdentifier(of: object) : nil)
            }
        }

        var next: [MixerApp] = []
        for (owner, objects) in groups {
            let fallbackName = "pid \(owner)"
            let name = ResponsibleProcess.displayName(pid: owner, fallback: fallbackName)
            // The pid fallback is not a name to save under: pids recycle.
            let identity = MixerRoutingSupport.rowIdentity(bundleIdentifier: bundleHints[owner],
                                                           ownerPid: owner,
                                                           displayName: name == fallbackName ? nil : name)
            // Hidden means no row, and with no row the engine reconciliation
            // below tears its tap down too: an app taken off the list always
            // plays untouched, never silently attenuated (issue #300).
            if MixerRoutingSupport.isHiddenFromMixer(persistenceID: identity.persistenceID,
                                                     hiddenIDs: request.hiddenRowIDs) { continue }
            let isBypassed = bypassed.contains(owner)
            let route = isBypassed ? nil : storedRoute(for: identity,
                                                       saved: savedOutputs,
                                                       session: request.sessionRoutes)
            next.append(MixerApp(id: identity.rowID,
                                 persistenceID: identity.persistenceID,
                                 ownerPid: owner,
                                 name: name,
                                 audioObjects: objects.sorted(),
                                 isPlaying: playing.contains(owner),
                                 isBypassed: isBypassed,
                                 selectedOutputDeviceUID: route,
                                 effectiveOutputDeviceUID: isBypassed ? nil : MixerRoutingSupport.effectiveDeviceUID(
                                    selectedUID: route,
                                    availableUIDs: availableUIDs,
                                    defaultUID: defaultUID),
                                 outputDeviceUnavailable: isBypassed ? false : MixerRoutingSupport.selectedDeviceUnavailable(
                                    selectedUID: route,
                                    availableUIDs: availableUIDs),
                                 volume: isBypassed ? 1 : (storedVolume(for: identity,
                                                                       saved: saved,
                                                                       session: request.sessionVolumes) ?? 1)))
        }
        if MixerRoutingSupport.needsPersistentFinderRow(
            showFinder: showFinder,
            hasFinderRow: next.contains { $0.id == MixerRoutingSupport.finderBundleIdentifier }
        ), let finder = NSRunningApplication.runningApplications(
            withBundleIdentifier: MixerRoutingSupport.finderBundleIdentifier
        ).first {
            let id = MixerRoutingSupport.finderBundleIdentifier
            next.append(MixerApp(id: id,
                                 persistenceID: id,
                                 ownerPid: finder.processIdentifier,
                                 name: finder.localizedName ?? "Finder",
                                 audioObjects: [],
                                 isPlaying: false,
                                 selectedOutputDeviceUID: savedOutputs[id],
                                 effectiveOutputDeviceUID: MixerRoutingSupport.effectiveDeviceUID(
                                    selectedUID: savedOutputs[id],
                                    availableUIDs: availableUIDs,
                                    defaultUID: defaultUID),
                                 outputDeviceUnavailable: MixerRoutingSupport.selectedDeviceUnavailable(
                                    selectedUID: savedOutputs[id],
                                    availableUIDs: availableUIDs),
                                 volume: saved[id] ?? 1))
        }
        next.sort {
            MixerRoutingSupport.displayOrderedBefore(name: $0.name, id: $0.id,
                                                     otherName: $1.name, otherID: $1.id)
        }
        next = coalescingAppsWithDuplicateIDs(next)

        return RefreshSnapshot(defaultUID: defaultUID,
                               systemSoundUID: systemSoundUID,
                               outputDevices: nextOutputDevices,
                               defaultDeviceID: defaultDevice?.audioObjectID,
                               systemOutputVolume: systemOutputVolume,
                               systemOutputMuted: systemOutputMuted,
                               apps: next,
                               processObjects: processObjects,
                               lowered: lowered)
    }

    private static func coalescingAppsWithDuplicateIDs(_ apps: [MixerApp]) -> [MixerApp] {
        var merged: [MixerApp] = []
        var indexesByID: [String: Int] = [:]

        for app in apps {
            guard let index = indexesByID[app.id] else {
                indexesByID[app.id] = merged.count
                merged.append(app)
                continue
            }

            let existing = merged[index]
            let audioObjects = Array(Set(existing.audioObjects).union(app.audioObjects)).sorted()
            merged[index] = MixerApp(id: existing.id,
                                     persistenceID: existing.persistenceID,
                                     ownerPid: existing.ownerPid,
                                     name: existing.name,
                                     audioObjects: audioObjects,
                                     isPlaying: existing.isPlaying || app.isPlaying,
                                     selectedOutputDeviceUID: existing.selectedOutputDeviceUID,
                                     effectiveOutputDeviceUID: existing.effectiveOutputDeviceUID,
                                     outputDeviceUnavailable: existing.outputDeviceUnavailable,
                                     volume: existing.volume)
        }

        return merged
    }

    /// What the headphone disconnect protection has done to the system volume,
    /// so it can be undone. Main-thread state; a refresh pass gets a copy and
    /// hands the new value back.
    private struct LoweredOutput {
        let uid: String
        let previousVolume: Float32
        let appliedVolume: Float32
    }

    private struct LoweredOutputState {
        var lastAutomaticLoweredOutputUID: String?
        var loweredOutput: LoweredOutput?
    }

    /// Runs on `halQueue` as part of a refresh: reading and writing an output
    /// device's volume are HAL calls, and this fires exactly when the audio
    /// daemon is busiest (a device just went away).
    private static func loweringOutputVolumeIfHeadphonesDisconnected(
        state: LoweredOutputState,
        previousDefaultUID: String?,
        previousOutputDevices: [MixerOutputDevice],
        nextDefaultUID: String?,
        nextOutputDevices: [MixerOutputDevice],
        lowerOnDisconnect: Bool,
        lowerToPercent: Int) -> LoweredOutputState {
        var state = state
        if let nextDefaultUID,
           nextOutputDevices.first(where: { $0.uid == nextDefaultUID })?.isHeadphones == true {
            state.lastAutomaticLoweredOutputUID = nil
            // Headphones are back: the speakers get the volume they had before
            // the disconnect lowered them.
            state.loweredOutput = restoringLoweredOutputVolume(state.loweredOutput,
                                                               in: nextOutputDevices)
            return state
        }

        guard lowerOnDisconnect,
              let previousDefaultUID,
              let previousDefault = previousOutputDevices.first(where: { $0.uid == previousDefaultUID }),
              previousDefault.isHeadphones,
              !nextOutputDevices.contains(where: { $0.uid == previousDefaultUID && $0.isHeadphones }),
              let nextDefaultUID,
              let nextDefault = nextOutputDevices.first(where: { $0.uid == nextDefaultUID }),
              !nextDefault.isHeadphones,
              state.lastAutomaticLoweredOutputUID != nextDefaultUID else {
            return state
        }

        let volume = Float32(Double(lowerToPercent) / 100)
        let previousVolume = outputVolume(for: nextDefault.audioObjectID)
        if setOutputVolume(volume, for: nextDefault.audioObjectID) {
            state.lastAutomaticLoweredOutputUID = nextDefaultUID
            if let previousVolume, previousVolume > volume {
                state.loweredOutput = LoweredOutput(uid: nextDefaultUID,
                                                    previousVolume: previousVolume,
                                                    appliedVolume: volume)
            }
        }
        return state
    }

    /// Puts back the volume this feature lowered, as long as it is still the
    /// value the app set: anything else means it was changed since, and that
    /// choice wins. Returns what is left to restore later.
    private static func restoringLoweredOutputVolume(_ lowered: LoweredOutput?,
                                                     in devices: [MixerOutputDevice]) -> LoweredOutput? {
        guard let lowered else { return nil }
        guard let device = devices.first(where: { $0.uid == lowered.uid }) else {
            // The device is not around to restore right now; it may come back.
            return lowered
        }
        guard MixerRoutingSupport.shouldRestoreOutputVolume(
            appliedVolume: Double(lowered.appliedVolume),
            currentVolume: outputVolume(for: device.audioObjectID).map(Double.init)) else { return nil }
        _ = setOutputVolume(lowered.previousVolume, for: device.audioObjectID)
        return nil
    }

    /// Teardown path only, and deliberately synchronous: `stopAll()` runs while
    /// the app is quitting, so anything the mixer still owes the system has to
    /// be handed back before the process goes away.
    private func restoreLoweredOutputVolume() {
        loweredOutput = Self.restoringLoweredOutputVolume(loweredOutput, in: outputDevices)
    }

    /// Brings the running engines in line with the current app list: drops
    /// taps for apps that stopped playing, retargets taps whose process set
    /// changed (new helper spawned), and applies saved volumes to newcomers.
    ///
    /// A tap is never torn down to be rebuilt right after: the replacement is
    /// built first (applyRouting) and the old one stops once it is running.
    /// Rows that keep changing fold into a single trailing rebuild instead of
    /// one per notification.
    private func reconcileEngines(with apps: [MixerApp]) {
        let apps = Self.coalescingAppsWithDuplicateIDs(apps)
        var byId: [String: MixerApp] = [:]
        for app in apps {
            byId[app.id] = app
        }

        let now = CFAbsoluteTimeGetCurrent()
        var nextPassDelay: Double?

        for (id, engine) in Array(engines) {
            let app = byId[id]
            let hasAudioObjects = !(app?.audioObjects.isEmpty ?? true)

            // The row is gone or momentarily has no audio object: an app that
            // recreates its audio unit between clips does exactly this and is
            // back a few milliseconds later. Nothing is audible in between, so
            // the tap is kept for a short window instead of being destroyed
            // and rebuilt once per notification.
            guard hasAudioObjects, let app else {
                let lostAt = objectsLostAt[id]
                if let delay = MixerRoutingSupport.engineTeardownDelay(
                    hasAudioObjects: false,
                    lastChangeAt: lostAt,
                    now: now) {
                    if lostAt == nil { objectsLostAt[id] = now }
                    nextPassDelay = min(nextPassDelay ?? delay, delay)
                } else {
                    discardEngine(for: id)
                }
                continue
            }
            // The audio came back inside the window, so the next disappearance
            // starts its own wait rather than inheriting this one.
            objectsLostAt.removeValue(forKey: id)

            // Waking from sleep, or a device renegotiating right after, can
            // leave the aggregate wedged: its IO proc never runs again while
            // the tap keeps muting the app, and nothing else about the engine
            // looks wrong, so it used to be kept forever and the app stayed
            // silent until quit (issue #341). A render count that stops
            // moving while the app is playing is conclusive: the engine goes
            // away at once, which unmutes the app even if the rebuild below
            // cannot land yet, and a fresh tap takes its place.
            switch MixerRoutingSupport.engineRenderVerdict(previous: engineRenderProgress[id],
                                                           cycles: engine.renderCycles,
                                                           isPlaying: app.isPlaying,
                                                           now: now) {
            case .note(let observation, let recheckAfter):
                if let previous = engineRenderProgress[id],
                   observation.cycles != previous.cycles {
                    engineRecovery.clear(id)
                }
                engineRenderProgress[id] = observation
                nextPassDelay = min(nextPassDelay ?? recheckAfter, recheckAfter)
            case .stalled(let recheckAfter):
                nextPassDelay = min(nextPassDelay ?? recheckAfter, recheckAfter)
            case .wedged:
                engines.removeValue(forKey: id)?.stop()
                engineRenderProgress.removeValue(forKey: id)
                engineChangeAt[id] = now
                let configuration = MixerEngineRecovery.Configuration(
                    objects: engine.tappedObjects,
                    outputDeviceUID: engine.outputDeviceUID)
                let shouldRetry = engineRecovery.recordFailure(id, configuration: configuration)
                if shouldRetry {
                    applyRouting(for: app)
                }
                continue
            case nil:
                engineRenderProgress.removeValue(forKey: id)
            }

            let listedUIDs = outputDevices.map(\.uid)
            // An AirPlay engine whose clock output went away keeps its route
            // and objects, so that clock is checked on its own. Only that:
            // an engine on a default the list hides is otherwise left alone.
            let clockIsGone = engine.clockDeviceUID.map { !listedUIDs.contains($0) } == true
            guard engine.tappedObjects != app.audioObjects
                || engine.outputDeviceUID != app.effectiveOutputDeviceUID
                || !appNeedsEngine(app)
                || clockIsGone else { continue }

            engineChangeAt[id] = now
            guard appNeedsEngine(app) else {
                // Back to 100% on the default output: passthrough is the point.
                discardEngine(for: id)
                continue
            }
            // An engine rendering to a device that is gone (headphones just
            // unplugged) can only mute the app, so it goes right away; every
            // other rebuild keeps its tap until the replacement is running.
            if !MixerRoutingSupport.engineOutputIsPresent(engine.outputDeviceUID,
                                                          clockUID: engine.clockDeviceUID,
                                                          listedUIDs: listedUIDs,
                                                          airPlayConnected: AirPlayRouteManager.isSpeakerConnected) {
                engines.removeValue(forKey: id)?.stop()
                engineRenderProgress.removeValue(forKey: id)
            }
            applyRouting(for: app)
        }

        for app in apps where appNeedsEngine(app) && engines[app.id] == nil {
            applyRouting(for: app)
        }
        forgetEngineStateOfMissingRows(byId)
        if let nextPassDelay {
            scheduleEngineReconcile(after: nextPassDelay)
        }
    }

    /// One shared trailing pass for pending rebuilds and render checks.
    /// Playing engines keep checking their atomic counters; once all apps
    /// are idle and no rebuild is pending, no further pass is scheduled.
    private func scheduleEngineReconcile(after delay: Double) {
        guard !engineReconcilePending else { return }
        engineReconcilePending = true
        DispatchQueue.main.asyncAfter(deadline: .now() + max(delay, 0.01)) { [weak self] in
            guard let self else { return }
            self.engineReconcilePending = false
            guard !self.stopped, self.listenerInstalled else { return }
            self.reconcileEngines(with: self.apps)
        }
    }

    /// Session state of rows that are gone. Volumes chosen for rows without a
    /// bundle id are deliberately kept: an app that recreates its audio unit
    /// drops off the list for a moment, and its slider must survive that.
    private func forgetEngineStateOfMissingRows(_ byId: [String: MixerApp]) {
        for id in engineChangeAt.keys where byId[id] == nil && engines[id] == nil {
            engineChangeAt.removeValue(forKey: id)
            objectsLostAt.removeValue(forKey: id)
            engineRecovery.clear(id)
        }
    }

    // MARK: - Persistence

    private func savedVolumes() -> [String: Double] {
        let raw = UserDefaults.standard.dictionary(forKey: DefaultsKey.appVolumes) ?? [:]
        var sanitized: [String: Double] = [:]
        for (id, value) in raw {
            let number: Double?
            if let value = value as? Double {
                number = value
            } else if let value = value as? NSNumber {
                number = value.doubleValue
            } else {
                number = nil
            }
            guard let number, number.isFinite else { continue }
            sanitized[id] = Defaults.sanitizedAppVolume(number)
        }
        return sanitized
    }

    private func savedOutputDeviceUIDs() -> [String: String] {
        let raw = UserDefaults.standard.dictionary(forKey: DefaultsKey.appOutputDevices) ?? [:]
        return Defaults.sanitizedAppOutputDevices(raw)
    }

    // MARK: - List visibility (issue #300)

    /// Takes a row out of the list. Its saved volume and route are kept for
    /// the day it comes back; while hidden the app is never tapped, so it
    /// always plays untouched. The Finder keeps its own preference key, from
    /// the days when it was the only row that could be hidden.
    func hideFromList(_ app: MixerApp) {
        guard let id = app.persistenceID else { return }
        if id == MixerRoutingSupport.finderBundleIdentifier {
            UserDefaults.standard.set(false, forKey: DefaultsKey.mixerShowFinder)
        } else {
            var hidden = savedHiddenApps()
            hidden[id] = app.name
            persistHiddenApps(hidden)
        }
        publishHiddenApps()
        refreshApps()
    }

    /// Puts a hidden app back on the list; its saved volume and route apply
    /// again on the next refresh.
    func showInList(id: String) {
        if id == MixerRoutingSupport.finderBundleIdentifier {
            UserDefaults.standard.set(true, forKey: DefaultsKey.mixerShowFinder)
        } else {
            var hidden = savedHiddenApps()
            hidden.removeValue(forKey: id)
            persistHiddenApps(hidden)
        }
        publishHiddenApps()
        refreshApps()
    }

    private func savedHiddenApps() -> [String: String] {
        MixerRoutingSupport.sanitizedHiddenApps(
            UserDefaults.standard.dictionary(forKey: DefaultsKey.mixerHiddenApps) ?? [:])
    }

    private func persistHiddenApps(_ hidden: [String: String]) {
        if hidden.isEmpty {
            UserDefaults.standard.removeObject(forKey: DefaultsKey.mixerHiddenApps)
        } else {
            UserDefaults.standard.set(hidden, forKey: DefaultsKey.mixerHiddenApps)
        }
    }

    /// Rebuilds the published hidden list: the stored map, plus the Finder
    /// while its toggle keeps it out, sorted the same way as the visible rows.
    private func publishHiddenApps() {
        var entries = savedHiddenApps().map { MixerHiddenApp(id: $0.key, name: $0.value) }
        if !UserDefaults.standard.bool(forKey: DefaultsKey.mixerShowFinder) {
            let finderID = MixerRoutingSupport.finderBundleIdentifier
            let name = NSRunningApplication.runningApplications(withBundleIdentifier: finderID)
                .first?.localizedName ?? "Finder"
            entries.append(MixerHiddenApp(id: finderID, name: name))
        }
        entries.sort {
            MixerRoutingSupport.displayOrderedBefore(name: $0.name, id: $0.id,
                                                     otherName: $1.name, otherID: $1.id)
        }
        if hiddenApps != entries { hiddenApps = entries }
    }

    /// The volume of a row: from disk when the row has a key to save under,
    /// otherwise from this session only. Static so a refresh pass can resolve
    /// rows off the main thread from copies of the session maps.
    private static func storedVolume(for identity: MixerRowIdentity,
                                     saved: [String: Double],
                                     session: [String: Double]) -> Double? {
        guard let key = identity.persistenceID else { return session[identity.rowID] }
        return saved[key]
    }

    private static func storedRoute(for identity: MixerRowIdentity,
                                    saved: [String: String],
                                    session: [String: String]) -> String? {
        guard let key = identity.persistenceID else { return session[identity.rowID] }
        return saved[key]
    }

    private func storedVolume(for identity: MixerRowIdentity, saved: [String: Double]) -> Double? {
        Self.storedVolume(for: identity, saved: saved, session: sessionVolumes)
    }

    private func storedRoute(for identity: MixerRowIdentity, saved: [String: String]) -> String? {
        Self.storedRoute(for: identity, saved: saved, session: sessionRoutes)
    }

    private func persistVolume(_ volume: Double, for app: MixerApp) {
        guard let id = app.persistenceID else {
            // Neither a bundle id nor a display name: nothing stable to write
            // down. The slider still works while the app runs.
            if isUnity(volume) {
                sessionVolumes.removeValue(forKey: app.id)
            } else {
                sessionVolumes[app.id] = volume
            }
            return
        }
        var volumes = savedVolumes()
        if isUnity(volume) {
            volumes.removeValue(forKey: id)
        } else {
            volumes[id] = volume
        }
        UserDefaults.standard.set(volumes, forKey: DefaultsKey.appVolumes)
    }

    private func persistOutputDeviceUID(_ uid: String?, for app: MixerApp) {
        guard let id = app.persistenceID else {
            if let uid {
                sessionRoutes[app.id] = uid
            } else {
                sessionRoutes.removeValue(forKey: app.id)
            }
            return
        }
        var routes = savedOutputDeviceUIDs()
        if let uid {
            routes[id] = uid
        } else {
            routes.removeValue(forKey: id)
        }
        UserDefaults.standard.set(routes, forKey: DefaultsKey.appOutputDevices)
    }

    private func persistOutputDeviceUIDs(_ routes: [String: String]) {
        if routes.isEmpty {
            UserDefaults.standard.removeObject(forKey: DefaultsKey.appOutputDevices)
        } else {
            UserDefaults.standard.set(routes, forKey: DefaultsKey.appOutputDevices)
        }
    }

    private func clearPermissionIfNoActiveAdjustments() {
        guard needsPermission,
              !apps.contains(where: appNeedsEngine),
              engines.isEmpty,
              builds.isEmpty else { return }
        needsPermission = false
    }

    // MARK: - CoreAudio plumbing

    /// Every process object the audio HAL knows about. The island's level
    /// reader groups them by responsible app the same way this mixer does.
    static func audioProcessObjects() -> [AudioObjectID] {
        var address = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyProcessObjectList,
                                                 mScope: kAudioObjectPropertyScopeGlobal,
                                                 mElement: kAudioObjectPropertyElementMain)
        var size: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject),
                                             &address, 0, nil, &size) == noErr else { return [] }
        var objects = [AudioObjectID](repeating: 0, count: Int(size) / MemoryLayout<AudioObjectID>.size)
        guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),
                                         &address, 0, nil, &size, &objects) == noErr else { return [] }
        return objects
    }

    /// The bundle id the audio HAL itself reports for a process object. Used
    /// only to fill in an identity the running-application lookup could not
    /// provide, never to override it.
    private static func processBundleIdentifier(of object: AudioObjectID) -> String? {
        guard #available(macOS 14.4, *) else { return nil }
        var bundleRef: CFString = "" as CFString
        guard read(object, kAudioProcessPropertyBundleID, &bundleRef) else { return nil }
        let bundleID = bundleRef as String
        return bundleID.isEmpty ? nil : bundleID
    }

    private static let outputVolumeSelectors: [AudioObjectPropertySelector] = [
        kAudioHardwareServiceDeviceProperty_VirtualMainVolume,
        kAudioDevicePropertyVolumeScalar,
    ]

    private static func outputVolume(for deviceID: AudioObjectID) -> Float32? {
        for selector in outputVolumeSelectors {
            var address = AudioObjectPropertyAddress(mSelector: selector,
                                                     mScope: kAudioObjectPropertyScopeOutput,
                                                     mElement: kAudioObjectPropertyElementMain)
            guard AudioObjectHasProperty(deviceID, &address) else { continue }
            var volume: Float32 = 0
            if read(deviceID, selector, &volume, scope: kAudioObjectPropertyScopeOutput) {
                return volume
            }
        }
        return nil
    }

    private static func hasSettableOutputVolume(for deviceID: AudioObjectID) -> Bool {
        for selector in outputVolumeSelectors {
            var address = AudioObjectPropertyAddress(mSelector: selector,
                                                     mScope: kAudioObjectPropertyScopeOutput,
                                                     mElement: kAudioObjectPropertyElementMain)
            guard AudioObjectHasProperty(deviceID, &address) else { continue }
            var isSettable = DarwinBoolean(false)
            if AudioObjectIsPropertySettable(deviceID, &address, &isSettable) == noErr,
               isSettable.boolValue {
                return true
            }
        }
        return false
    }

    private static func outputDevices(defaultUID: String?) -> [MixerOutputDevice] {
        var address = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyDevices,
                                                 mScope: kAudioObjectPropertyScopeGlobal,
                                                 mElement: kAudioObjectPropertyElementMain)
        var size: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject),
                                             &address, 0, nil, &size) == noErr else { return [] }
        var deviceIDs = [AudioObjectID](repeating: 0, count: Int(size) / MemoryLayout<AudioObjectID>.size)
        guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),
                                         &address, 0, nil, &size, &deviceIDs) == noErr else { return [] }

        var devices: [MixerOutputDevice] = []
        for deviceID in deviceIDs {
            guard hasOutputStreams(deviceID) else { continue }

            var isAlive: UInt32 = 1
            if read(deviceID, kAudioDevicePropertyDeviceIsAlive, &isAlive), isAlive == 0 {
                continue
            }
            var isHidden: UInt32 = 0
            if read(deviceID, kAudioDevicePropertyIsHidden, &isHidden), isHidden != 0 {
                continue
            }
            let canBeDefaultOutput = canBeDefault(deviceID,
                                                  selector: kAudioDevicePropertyDeviceCanBeDefaultDevice)
            let canBeDefaultSystemOutput = canBeDefault(
                deviceID,
                selector: kAudioDevicePropertyDeviceCanBeDefaultSystemDevice)

            var uidRef: CFString = "" as CFString
            guard read(deviceID, kAudioDevicePropertyDeviceUID, &uidRef) else { continue }
            let uid = uidRef as String
            guard !uid.isEmpty else { continue }

            var nameRef: CFString = "" as CFString
            let name = read(deviceID, kAudioObjectPropertyName, &nameRef)
                ? nameRef as String
                : uid
            guard !MicMuteSupport.isOwnDevice(name: name) else { continue }
            let dataSourceName = outputDataSourceName(for: deviceID)
            var transportType: UInt32 = 0
            _ = read(deviceID, kAudioDevicePropertyTransportType, &transportType)

            devices.append(MixerOutputDevice(id: uid,
                                             uid: uid,
                                             name: name,
                                             isDefault: uid == defaultUID,
                                             isHeadphones: MixerRoutingSupport.outputLooksLikeHeadphones(
                                                name: name,
                                                uid: uid,
                                                dataSourceName: dataSourceName),
                                             canBeDefaultOutput: canBeDefaultOutput,
                                             canBeDefaultSystemOutput: canBeDefaultSystemOutput,
                                             priorityTier: MixerRoutingSupport.PriorityTier(
                                                transportType: transportType),
                                             audioObjectID: deviceID))
        }

        // Always listed while the picker API exists, next to any AirPlay device
        // macOS itself exposes: the two are different routes. It is a per-app
        // route only: picking a speaker never moves the Mac's own output, so it
        // is never offered as the system, alert-sound or priority output.
        if AirPlayRouteManager.isListed {
            let airPlayName: String
            if let active = AirPlayRouteManager.currentSpeakerName, !active.isEmpty {
                airPlayName = "\(active) (AirPlay)"
            } else {
                airPlayName = "AirPlay"
            }
            devices.append(MixerOutputDevice(id: AirPlayRouteManager.airPlaySentinelUID,
                                             uid: AirPlayRouteManager.airPlaySentinelUID,
                                             name: airPlayName,
                                             isDefault: false,
                                             isHeadphones: false,
                                             canBeDefaultOutput: false,
                                             canBeDefaultSystemOutput: false,
                                             priorityTier: .hardware,
                                             audioObjectID: 0))
        }

        return devices.sorted { lhs, rhs in
            MixerRoutingSupport.deviceDisplayOrderedBefore(
                isDefault: lhs.isDefault, name: lhs.name, uid: lhs.uid,
                otherIsDefault: rhs.isDefault, otherName: rhs.name, otherUID: rhs.uid)
        }
    }

    private static func outputDataSourceName(for deviceID: AudioObjectID) -> String? {
        var dataSourceID: UInt32 = 0
        guard read(deviceID,
                   kAudioDevicePropertyDataSource,
                   &dataSourceID,
                   scope: kAudioObjectPropertyScopeOutput) else { return nil }

        var address = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyDataSourceNameForIDCFString,
            mScope: kAudioObjectPropertyScopeOutput,
            mElement: kAudioObjectPropertyElementMain)
        var nameRef: CFString = "" as CFString
        let status = withUnsafeMutablePointer(to: &dataSourceID) { dataSourcePointer in
            withUnsafeMutablePointer(to: &nameRef) { namePointer in
                var translation = AudioValueTranslation(
                    mInputData: UnsafeMutableRawPointer(dataSourcePointer),
                    mInputDataSize: UInt32(MemoryLayout<UInt32>.size),
                    mOutputData: UnsafeMutableRawPointer(namePointer),
                    mOutputDataSize: UInt32(MemoryLayout<CFString>.size))
                var size = UInt32(MemoryLayout<AudioValueTranslation>.size)
                return AudioObjectGetPropertyData(
                    deviceID,
                    &address,
                    0,
                    nil,
                    &size,
                    &translation)
            }
        }
        guard status == noErr else { return nil }
        return nameRef as String
    }

    private static func hasOutputStreams(_ deviceID: AudioObjectID) -> Bool {
        var address = AudioObjectPropertyAddress(mSelector: kAudioDevicePropertyStreams,
                                                 mScope: kAudioObjectPropertyScopeOutput,
                                                 mElement: kAudioObjectPropertyElementMain)
        var size: UInt32 = 0
        return AudioObjectGetPropertyDataSize(deviceID, &address, 0, nil, &size) == noErr
            && size >= MemoryLayout<AudioObjectID>.size
    }

    private static func canBeDefault(_ deviceID: AudioObjectID,
                                     selector: AudioObjectPropertySelector) -> Bool {
        var value: UInt32 = 0
        return read(deviceID, selector, &value, scope: kAudioObjectPropertyScopeOutput) && value != 0
    }

    private static func defaultOutputDeviceUID(
        selector: AudioObjectPropertySelector = kAudioHardwarePropertyDefaultOutputDevice
    ) -> String? {
        var defaultDevice = AudioObjectID(0)
        guard read(AudioObjectID(kAudioObjectSystemObject),
                   selector, &defaultDevice),
              defaultDevice != 0 else { return nil }
        var uidRef: CFString = "" as CFString
        guard read(defaultDevice, kAudioDevicePropertyDeviceUID, &uidRef) else { return nil }
        return uidRef as String
    }

    private static func setDefaultDevice(_ deviceID: AudioObjectID,
                                         selector: AudioObjectPropertySelector) -> OSStatus {
        var nextDeviceID = deviceID
        var address = AudioObjectPropertyAddress(mSelector: selector,
                                                 mScope: kAudioObjectPropertyScopeGlobal,
                                                 mElement: kAudioObjectPropertyElementMain)
        return AudioObjectSetPropertyData(AudioObjectID(kAudioObjectSystemObject),
                                          &address,
                                          0,
                                          nil,
                                          UInt32(MemoryLayout<AudioObjectID>.size),
                                          &nextDeviceID)
    }

    private static func setOutputVolume(_ volume: Float32, for deviceID: AudioObjectID) -> Bool {
        let clamped = min(max(volume, 0), 1)
        for selector in outputVolumeSelectors {
            var address = AudioObjectPropertyAddress(mSelector: selector,
                                                     mScope: kAudioObjectPropertyScopeOutput,
                                                     mElement: kAudioObjectPropertyElementMain)
            guard AudioObjectHasProperty(deviceID, &address) else { continue }

            var isSettable = DarwinBoolean(false)
            guard AudioObjectIsPropertySettable(deviceID, &address, &isSettable) == noErr,
                  isSettable.boolValue else { continue }

            var nextVolume = clamped
            let status = AudioObjectSetPropertyData(deviceID,
                                                    &address,
                                                    0,
                                                    nil,
                                                    UInt32(MemoryLayout<Float32>.size),
                                                    &nextVolume)
            if status == noErr {
                return true
            }
        }
        return false
    }

    /// System volume as people mean it: the default output device's main
    /// scalar. Static on purpose so callers (the command bar) never spin the
    /// mixer up; false when the device exposes no software volume control.
    @discardableResult
    static func setSystemOutputVolume(_ volume: Double) -> Bool {
        guard let device = defaultOutputDeviceID() else { return false }
        let clamped = Float32(min(max(volume, 0), 1))
        let applied = setOutputVolume(clamped, for: device)
        // Mute is a separate switch from the level, so asking for a volume
        // while the Mac is muted would set a number nobody can hear. Asking
        // for sound means asking for sound, which is what the volume keys do.
        if clamped > 0 { setOutputMuted(false, for: device) }
        return applied
    }

    /// Whether the sound is currently cut, or nil when this output has no
    /// mute switch of its own.
    static func systemOutputIsMuted() -> Bool? {
        guard let device = defaultOutputDeviceID() else { return nil }
        return outputMuted(for: device)
    }

    @discardableResult
    static func setSystemOutputMuted(_ muted: Bool) -> Bool {
        guard let device = defaultOutputDeviceID() else { return false }
        return setOutputMuted(muted, for: device)
    }

    private static func defaultOutputDeviceID() -> AudioObjectID? {
        var device = AudioObjectID(0)
        guard read(AudioObjectID(kAudioObjectSystemObject),
                   kAudioHardwarePropertyDefaultOutputDevice, &device),
              device != 0 else { return nil }
        return device
    }

    /// The mute switch can sit on the device as a whole or on each channel,
    /// depending on the driver, so both are tried before giving up.
    private static func muteElements(for deviceID: AudioObjectID) -> [AudioObjectPropertyElement] {
        [kAudioObjectPropertyElementMain, 1, 2]
    }

    private static func outputMuted(for deviceID: AudioObjectID) -> Bool? {
        for element in muteElements(for: deviceID) {
            var address = AudioObjectPropertyAddress(mSelector: kAudioDevicePropertyMute,
                                                     mScope: kAudioObjectPropertyScopeOutput,
                                                     mElement: element)
            guard AudioObjectHasProperty(deviceID, &address) else { continue }
            var value: UInt32 = 0
            var size = UInt32(MemoryLayout<UInt32>.size)
            guard AudioObjectGetPropertyData(deviceID, &address, 0, nil, &size, &value) == noErr
            else { continue }
            return value != 0
        }
        return nil
    }

    @discardableResult
    private static func setOutputMuted(_ muted: Bool, for deviceID: AudioObjectID) -> Bool {
        var changed = false
        for element in muteElements(for: deviceID) {
            var address = AudioObjectPropertyAddress(mSelector: kAudioDevicePropertyMute,
                                                     mScope: kAudioObjectPropertyScopeOutput,
                                                     mElement: element)
            guard AudioObjectHasProperty(deviceID, &address) else { continue }
            var settable = DarwinBoolean(false)
            guard AudioObjectIsPropertySettable(deviceID, &address, &settable) == noErr,
                  settable.boolValue else { continue }
            var value: UInt32 = muted ? 1 : 0
            if AudioObjectSetPropertyData(deviceID, &address, 0, nil,
                                          UInt32(MemoryLayout<UInt32>.size), &value) == noErr {
                changed = true
            }
        }
        return changed
    }

    @discardableResult
    fileprivate static func read<T>(_ object: AudioObjectID,
                                    _ selector: AudioObjectPropertySelector,
                                    _ value: inout T,
                                    scope: AudioObjectPropertyScope = kAudioObjectPropertyScopeGlobal) -> Bool {
        var address = AudioObjectPropertyAddress(mSelector: selector,
                                                 mScope: scope,
                                                 mElement: kAudioObjectPropertyElementMain)
        var size = UInt32(MemoryLayout<T>.size)
        return withUnsafeMutablePointer(to: &value) { pointer in
            AudioObjectGetPropertyData(object, &address, 0, nil, &size,
                                       UnsafeMutableRawPointer(pointer)) == noErr
        }
    }
}

// MARK: - Tap engine

/// Availability-erased face of the engine, so the mixer can store engines on
/// any macOS while the implementation requires 14.4.
private protocol GainEngine: AnyObject {
    var gain: Float { get set }
    var tappedObjects: [AudioObjectID] { get }
    var outputDeviceUID: String { get }
    /// The hardware output that clocks an engine streaming elsewhere (AirPlay),
    /// nil for an engine that plays on `outputDeviceUID` itself.
    var clockDeviceUID: String? { get }
    /// How many IO callbacks the engine has completed. A count that stops
    /// moving while the tapped app is playing means the aggregate is no
    /// longer rendering, so the tap can only mute (issue #341).
    var renderCycles: UInt64 { get }
    func stop()
}

/// The audio path for one routed app: a muted process tap feeding an aggregate
/// device whose IO proc re-renders the samples scaled by `gain` onto the chosen
/// output device.
@available(macOS 14.4, *)
private final class TapGainEngine: GainEngine {
    let tappedObjects: [AudioObjectID]
    let outputDeviceUID: String
    var clockDeviceUID: String? { nil }
    var gain: Float {
        get { gainBox.value }
        set { gainBox.value = min(max(newValue, 0), Float(AppVolumeMixer.maxVolume)) }
    }

    private final class AtomicFloatBox {
        private var bits: Int32

        init(_ value: Float) {
            bits = Int32(bitPattern: value.bitPattern)
        }

        var value: Float {
            get {
                Float(bitPattern: UInt32(bitPattern: OSAtomicAdd32Barrier(0, &bits)))
            }
            set {
                let replacement = Int32(bitPattern: newValue.bitPattern)
                while true {
                    let current = OSAtomicAdd32Barrier(0, &bits)
                    if OSAtomicCompareAndSwap32Barrier(current, replacement, &bits) { return }
                }
            }
        }
    }

    private final class AtomicCycleBox {
        private var bits: Int64 = 0
        var value: UInt64 { UInt64(bitPattern: OSAtomicAdd64Barrier(0, &bits)) }
        func increment() { _ = OSAtomicIncrement64Barrier(&bits) }
    }

    /// One limiter per output buffer, preallocated so the realtime thread
    /// never allocates. Touched only by the IO proc once rendering starts.
    private final class LimiterBox {
        let lookahead: BoostLookaheadBufferListLimiter
        var fallback = BoostBufferListLimiter()
        init(channelCapacity: Int) {
            lookahead = BoostLookaheadBufferListLimiter(channelCapacity: channelCapacity)
        }
    }

    /// How fast the limiter recovers, kept beside the limiters rather than
    /// inside them: the device can change its rate while this engine keeps
    /// rendering, and the audio thread must never find another thread halfway
    /// through writing its state. Same one-float exchange as the gain.
    private typealias ReleaseBox = AtomicFloatBox

    private let gainBox = AtomicFloatBox(1)
    private let cycleBox = AtomicCycleBox()
    private let releaseBox = ReleaseBox(BoostLimiter.release(sampleRate: 48000))
    var renderCycles: UInt64 { cycleBox.value }
    private var tapID = AudioObjectID(0)
    private var aggregateID = AudioObjectID(0)
    private var ioProc: AudioDeviceIOProcID?
    /// The retained `ReleaseBox` handed to the rate listener, released when
    /// the listener goes away.
    private var rateListenerClient: UnsafeMutableRawPointer?

    init?(objects: [AudioObjectID], gain: Float, outputDeviceUID: String) {
        tappedObjects = objects
        gainBox.value = min(max(gain, 0), Float(AppVolumeMixer.maxVolume))
        self.outputDeviceUID = outputDeviceUID

        let description = CATapDescription(stereoMixdownOfProcesses: objects)
        description.muteBehavior = .mutedWhenTapped
        description.isPrivate = true
        guard AudioHardwareCreateProcessTap(description, &tapID) == noErr, tapID != 0 else {
            return nil
        }

        let aggregate: [String: Any] = [
            kAudioAggregateDeviceNameKey: "Brastoo Mixer",
            kAudioAggregateDeviceUIDKey: UUID().uuidString,
            kAudioAggregateDeviceIsPrivateKey: true,
            kAudioAggregateDeviceMainSubDeviceKey: outputDeviceUID,
            kAudioAggregateDeviceSubDeviceListKey: [[kAudioSubDeviceUIDKey: outputDeviceUID]],
            kAudioAggregateDeviceTapListKey: [[
                kAudioSubTapUIDKey: description.uuid.uuidString,
                kAudioSubTapDriftCompensationKey: true,
            ]],
            kAudioAggregateDeviceTapAutoStartKey: true,
        ]
        guard AudioHardwareCreateAggregateDevice(aggregate as CFDictionary, &aggregateID) == noErr,
              aggregateID != 0 else {
            AudioHardwareDestroyProcessTap(tapID)
            return nil
        }

        let box = gainBox
        // A boost pushes loud samples past full scale, and clamping the
        // overshoot flattens every peak into audible crackle (issue #326).
        // The limiter turns the whole signal down for just the moment a peak
        // would not fit, so a boosted app gets louder without distorting.
        let limiterBox = LimiterBox(
            channelCapacity: Self.outputChannelCapacity(of: aggregateID))
        releaseBox.value = BoostLimiter.release(sampleRate: Self.nominalSampleRate(of: aggregateID))
        let release = releaseBox
        let cycles = cycleBox
        let tapChannels = Self.tapChannels(of: tapID)
        guard AudioDeviceCreateIOProcIDWithBlock(&ioProc, aggregateID, nil, { _, input, _, output, _ in
            let inputBuffers = UnsafeMutableAudioBufferListPointer(UnsafeMutablePointer(mutating: input))
            let outputBuffers = UnsafeMutableAudioBufferListPointer(output)
            guard let tapIndex = MixerRender.tapBufferIndex(in: inputBuffers,
                                                            tapChannels: tapChannels) else {
                // No samples to put in the buffer is not a reason to leave it:
                // whatever the HAL left there plays otherwise (issue #326).
                MixerRender.silence(outputBuffers)
                return
            }
            let gain = box.value
            // `render` silences whatever it does not fill, so every path from
            // here on leaves the output written.
            let frames = MixerRender.render(source: inputBuffers[tapIndex],
                                            into: outputBuffers,
                                            gain: gain)
            // Keep the tiny delay filled for every live engine. Crossing from
            // attenuation into boost then changes level without inserting a
            // fresh block of silence into audio that is already playing.
            guard frames > 0 else { return }
            cycles.increment()
            let releaseCoefficient = release.value
            if !limiterBox.lookahead.process(outputBuffers, frames: frames,
                                             release: releaseCoefficient) {
                limiterBox.fallback.process(outputBuffers, frames: frames,
                                            release: releaseCoefficient)
            }
        }) == noErr else {
            AudioHardwareDestroyAggregateDevice(aggregateID)
            AudioHardwareDestroyProcessTap(tapID)
            return nil
        }

        // Installed only once there is something to keep current, so the
        // failure paths above have nothing to undo.
        startWatchingSampleRate()

        guard AudioDeviceStart(aggregateID, ioProc) == noErr else {
            stop()
            return nil
        }
    }

    /// Keeps the limiter's recovery honest when the output device changes its
    /// rate under a running engine.
    ///
    /// A headset that takes the microphone for a call renegotiates to a
    /// call rate, and the aggregate follows it without the IO proc ever
    /// stopping (measured: the render kept going straight through a
    /// 48k to 44.1k change and back). Nothing else would notice, so a boosted
    /// app would keep recovering at the old rate's speed for as long as the
    /// engine lives.
    private func startWatchingSampleRate() {
        var address = Self.nominalSampleRateAddress()
        let client = Unmanaged.passRetained(releaseBox).toOpaque()
        guard AudioObjectAddPropertyListener(aggregateID, &address,
                                             Self.sampleRateListener, client) == noErr else {
            Unmanaged<ReleaseBox>.fromOpaque(client).release()
            return
        }
        rateListenerClient = client
    }

    /// Where the new rate is read, away from whatever thread the answer
    /// arrived on. Serial, so two changes in a row cannot land out of order.
    fileprivate static let rateQueue = DispatchQueue(label: "com.brastoo.utils.mixer.rate",
                                                 qos: .userInitiated)
    /// How many teardowns may sit in the HAL at once. Operations past the
    /// bound wait in the queue holding no thread, so however often a wedged
    /// HAL parks a destroy, the shared pool loses at most this many workers
    /// (issue #971).
    private static let maximumConcurrentTeardowns = 4
    /// A broken HAL path can park inside teardown — `AudioHardwareDestroyProcessTap`
    /// on a wedged tap is the one that does it. Serialized, that one call left
    /// every later engine's aggregate and tap alive behind it, for as long as
    /// the app ran. Overlapping them lets the rest through, under the bound
    /// above so the parked ones cannot take the thread pool with them.
    fileprivate static let teardownQueue: OperationQueue = {
        let queue = OperationQueue()
        queue.name = "com.brastoo.utils.mixer.teardown"
        queue.qualityOfService = .utility
        queue.maxConcurrentOperationCount = maximumConcurrentTeardowns
        return queue
    }()

    /// The smallest possible answer, for the same reason as the mixer's own
    /// callback above: the system decides which thread this arrives on and it
    /// is not always the same one. Reading the audio system here would park
    /// whatever thread that is behind the very device being reconfigured,
    /// which is the change that sent this notification in the first place.
    private static let sampleRateListener: AudioObjectPropertyListenerProc = { deviceID, _, _, client in
        guard let client else { return noErr }
        // Held for the hop, so the engine can stop and hand back its
        // registration without the read landing in memory that is gone.
        let box = Unmanaged<ReleaseBox>.fromOpaque(client).takeUnretainedValue()
        rateQueue.async {
            box.value = BoostLimiter.release(sampleRate: nominalSampleRate(of: deviceID))
        }
        return noErr
    }

    fileprivate static func nominalSampleRateAddress() -> AudioObjectPropertyAddress {
        AudioObjectPropertyAddress(mSelector: kAudioDevicePropertyNominalSampleRate,
                                   mScope: kAudioObjectPropertyScopeGlobal,
                                   mElement: kAudioObjectPropertyElementMain)
    }

    /// How many channels the tap hands over, used to find it among the
    /// aggregate's input buffers. A stereo mixdown is what the tap is asked
    /// for, so that is also the fallback.
    private static func tapChannels(of tapID: AudioObjectID) -> Int {
        var format = AudioStreamBasicDescription()
        guard AppVolumeMixer.read(tapID, kAudioTapPropertyFormat, &format),
              format.mChannelsPerFrame > 0 else { return 2 }
        return Int(format.mChannelsPerFrame)
    }

    private static func outputChannelCapacity(of deviceID: AudioObjectID) -> Int {
        var address = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyStreamConfiguration,
            mScope: kAudioDevicePropertyScopeOutput,
            mElement: kAudioObjectPropertyElementMain)
        var size: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(deviceID, &address, 0, nil, &size) == noErr,
              size >= UInt32(MemoryLayout<AudioBufferList>.size) else { return 2 }
        let storage = UnsafeMutableRawPointer.allocate(
            byteCount: Int(size), alignment: MemoryLayout<AudioBufferList>.alignment)
        defer { storage.deallocate() }
        guard AudioObjectGetPropertyData(deviceID, &address, 0, nil, &size, storage) == noErr else {
            return 2
        }
        let buffers = UnsafeMutableAudioBufferListPointer(
            storage.assumingMemoryBound(to: AudioBufferList.self))
        return max(2, buffers.reduce(0) { $0 + Int($1.mNumberChannels) })
    }

    /// The rate the aggregate renders at, for the limiter's release timing.
    /// A failed read falls back to the common device rate; being off by a
    /// device's worth of rate only shifts the release by milliseconds.
    private static func nominalSampleRate(of deviceID: AudioObjectID) -> Double {
        var sampleRate: Float64 = 0
        guard AppVolumeMixer.read(deviceID, kAudioDevicePropertyNominalSampleRate, &sampleRate),
              sampleRate > 0 else { return 48000 }
        return sampleRate
    }

    func stop() {
        let tapID = self.tapID
        let aggregateID = self.aggregateID
        let ioProc = self.ioProc
        let listenerClient = rateListenerClient
        guard tapID != 0 || aggregateID != 0 || ioProc != nil || listenerClient != nil else {
            return
        }

        self.tapID = 0
        self.aggregateID = 0
        self.ioProc = nil
        rateListenerClient = nil

        // `mutedWhenTapped` only suppresses the original output while the tap
        // is being read. Stop that read before returning so audio is handed
        // back immediately; the cleanup calls after it may wait on a broken
        // HAL path and therefore run away from the main thread.
        if let ioProc, aggregateID != 0 {
            AudioDeviceStop(aggregateID, ioProc)
        }

        Self.teardownQueue.addOperation {
            if let listenerClient {
                var mayReleaseListener = aggregateID == 0
                if aggregateID != 0 {
                    var address = Self.nominalSampleRateAddress()
                    mayReleaseListener = AudioObjectRemovePropertyListener(
                        aggregateID, &address, Self.sampleRateListener, listenerClient) == noErr
                }
                // If HAL refuses removal, retain the tiny callback box. A late
                // callback is safer than dereferencing a released pointer.
                if mayReleaseListener {
                    Unmanaged<ReleaseBox>.fromOpaque(listenerClient).release()
                }
            }
            if let ioProc, aggregateID != 0 {
                AudioDeviceDestroyIOProcID(aggregateID, ioProc)
            }
            if aggregateID != 0 {
                AudioHardwareDestroyAggregateDevice(aggregateID)
            }
            if tapID != 0 {
                AudioHardwareDestroyProcessTap(tapID)
            }
        }
    }

    deinit { stop() }
}

/// An audio path that taps an application and feeds its audio into AirPlayRouteManager for streaming to AirPlay.
@available(macOS 14.4, *)
private final class AirPlayGainEngine: GainEngine {
    let tappedObjects: [AudioObjectID]
    let outputDeviceUID: String
    let clockDeviceUID: String?
    private let appID: String

    private final class AtomicFloatBox {
        private var bits: Int32
        init(_ value: Float) { bits = Int32(bitPattern: value.bitPattern) }
        var value: Float {
            get { Float(bitPattern: UInt32(bitPattern: OSAtomicAdd32Barrier(0, &bits))) }
            set {
                let replacement = Int32(bitPattern: newValue.bitPattern)
                while true {
                    let current = OSAtomicAdd32Barrier(0, &bits)
                    if OSAtomicCompareAndSwap32Barrier(current, replacement, &bits) { return }
                }
            }
        }
    }

    private final class AtomicCycleBox {
        private var bits: Int64 = 0
        var value: UInt64 { UInt64(bitPattern: OSAtomicAdd64Barrier(0, &bits)) }
        func increment() { _ = OSAtomicIncrement64Barrier(&bits) }
    }

    private let gainBox: AtomicFloatBox
    private let cycleBox = AtomicCycleBox()
    var renderCycles: UInt64 { cycleBox.value }

    var gain: Float {
        get { gainBox.value }
        set { gainBox.value = min(max(newValue, 0), Float(AppVolumeMixer.maxVolume)) }
    }

    private var tapID: AudioObjectID = 0
    private var aggregateID: AudioObjectID = 0
    private var ioProc: AudioDeviceIOProcID?
    private let ringBuffer: AudioRingBuffer
    /// This engine's own lane in the AirPlay mix; ended once, by this engine.
    private var registration: AirPlayStreamRegistration?
    /// The ring, retained for the sample-rate listener while it is installed.
    private var rateListenerClient: UnsafeMutableRawPointer?

    init?(appID: String, objects: [AudioObjectID], gain: Float, clockDeviceUID: String) {
        self.appID = appID
        self.tappedObjects = objects
        self.outputDeviceUID = AirPlayRouteManager.airPlaySentinelUID
        self.clockDeviceUID = clockDeviceUID
        self.gainBox = AtomicFloatBox(gain)

        let description = CATapDescription(stereoMixdownOfProcesses: objects)
        description.muteBehavior = .mutedWhenTapped
        description.isPrivate = true
        guard AudioHardwareCreateProcessTap(description, &tapID) == noErr, tapID != 0 else {
            return nil
        }

        let aggregate: [String: Any] = [
            // A fixed name, listed in MicMuteSupport.ownDeviceNames, so no
            // device list ever offers this private aggregate as an output.
            kAudioAggregateDeviceNameKey: "Brastoo AirPlay",
            kAudioAggregateDeviceUIDKey: UUID().uuidString,
            kAudioAggregateDeviceIsPrivateKey: true,
            kAudioAggregateDeviceMainSubDeviceKey: clockDeviceUID,
            kAudioAggregateDeviceSubDeviceListKey: [[kAudioSubDeviceUIDKey: clockDeviceUID]],
            kAudioAggregateDeviceTapListKey: [[
                kAudioSubTapUIDKey: description.uuid.uuidString,
                kAudioSubTapDriftCompensationKey: true,
            ]],
            kAudioAggregateDeviceTapAutoStartKey: true,
        ]
        guard AudioHardwareCreateAggregateDevice(aggregate as CFDictionary, &aggregateID) == noErr,
              aggregateID != 0 else {
            // Not fully initialized yet, so no deinit follows: clean up here.
            AudioHardwareDestroyProcessTap(tapID)
            return nil
        }

        let tapChannels = Self.tapChannels(of: tapID)
        let sampleRate = Self.nominalSampleRate(of: aggregateID)
        self.ringBuffer = AudioRingBuffer(sampleRate: sampleRate)
        let ring = self.ringBuffer
        let box = self.gainBox
        let cycles = self.cycleBox

        guard AudioDeviceCreateIOProcIDWithBlock(&ioProc, aggregateID, nil, { _, input, _, output, _ in
            let inputBuffers = UnsafeMutableAudioBufferListPointer(UnsafeMutablePointer(mutating: input))
            let outputBuffers = UnsafeMutableAudioBufferListPointer(output)

            MixerRender.silence(outputBuffers)

            guard let tapIndex = MixerRender.tapBufferIndex(in: inputBuffers, tapChannels: tapChannels),
                  let data = inputBuffers[tapIndex].mData?.assumingMemoryBound(to: Float.self) else {
                return
            }

            let channels = Int(inputBuffers[tapIndex].mNumberChannels)
            let frames = MixerRender.frames(bytes: inputBuffers[tapIndex].mDataByteSize,
                                            channels: inputBuffers[tapIndex].mNumberChannels)
            guard frames > 0 else { return }
            cycles.increment()

            let currentGain = box.value
            if currentGain > 0.0001 {
                // The buffer's own layout: the lone buffer the tap index
                // falls back to may not have the tap's two channels.
                ring.write(frames: data, frameCount: frames, channels: channels, gain: currentGain)
            }
        }) == noErr else {
            // Fully initialized from here, so deinit calls stop() again; one
            // stop() tears down once and leaves nothing for the second.
            ioProc = nil
            stop()
            return nil
        }

        // Installed only once there is something to keep current, so the
        // failure paths above have nothing to undo.
        startWatchingSampleRate()

        guard AudioDeviceStart(aggregateID, ioProc) == noErr,
              let registration = AirPlayRouteManager.shared.addAudioStream(appID: appID, buffer: ringBuffer) else {
            stop()
            return nil
        }
        self.registration = registration
    }

    /// Keeps the ring's rate current when the clock device renegotiates it
    /// under the running tap, the same way the device engines follow it for
    /// their limiter. A stale rate would play the app at the wrong speed.
    private func startWatchingSampleRate() {
        var address = TapGainEngine.nominalSampleRateAddress()
        let client = Unmanaged.passRetained(ringBuffer).toOpaque()
        guard AudioObjectAddPropertyListener(aggregateID, &address,
                                             Self.sampleRateListener, client) == noErr else {
            Unmanaged<AudioRingBuffer>.fromOpaque(client).release()
            return
        }
        rateListenerClient = client
    }

    private static let sampleRateListener: AudioObjectPropertyListenerProc = { deviceID, _, _, client in
        guard let client else { return noErr }
        let ring = Unmanaged<AudioRingBuffer>.fromOpaque(client).takeUnretainedValue()
        TapGainEngine.rateQueue.async {
            ring.sampleRate = nominalSampleRate(of: deviceID)
        }
        return noErr
    }

    func stop() {
        registration?.end()
        registration = nil
        let aggregate = aggregateID
        let tap = tapID
        let proc = ioProc
        let listenerClient = rateListenerClient
        self.aggregateID = 0
        self.tapID = 0
        self.ioProc = nil
        rateListenerClient = nil

        if let proc, aggregate != 0 {
            AudioDeviceStop(aggregate, proc)
        }

        // The same bounded queue as the device engines: a teardown parked in a
        // wedged HAL must not take the shared thread pool with it (issue #971).
        TapGainEngine.teardownQueue.addOperation {
            if let listenerClient {
                var mayRelease = aggregate == 0
                if aggregate != 0 {
                    var address = TapGainEngine.nominalSampleRateAddress()
                    mayRelease = AudioObjectRemovePropertyListener(
                        aggregate, &address, Self.sampleRateListener, listenerClient) == noErr
                }
                // A late callback is safer than reading a released ring.
                if mayRelease {
                    Unmanaged<AudioRingBuffer>.fromOpaque(listenerClient).release()
                }
            }
            if let proc, aggregate != 0 {
                AudioDeviceDestroyIOProcID(aggregate, proc)
            }
            if aggregate != 0 {
                AudioHardwareDestroyAggregateDevice(aggregate)
            }
            if tap != 0 {
                AudioHardwareDestroyProcessTap(tap)
            }
        }
    }

    deinit { stop() }

    private static func tapChannels(of tapID: AudioObjectID) -> Int {
        var format = AudioStreamBasicDescription()
        guard AppVolumeMixer.read(tapID, kAudioTapPropertyFormat, &format),
              format.mChannelsPerFrame > 0 else { return 2 }
        return Int(format.mChannelsPerFrame)
    }

    private static func nominalSampleRate(of deviceID: AudioObjectID) -> Double {
        var rate: Double = 44_100
        _ = AppVolumeMixer.read(deviceID, kAudioDevicePropertyNominalSampleRate, &rate)
        return rate > 0 ? rate : 44_100
    }
}
