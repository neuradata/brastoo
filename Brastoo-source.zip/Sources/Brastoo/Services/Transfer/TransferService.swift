// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import AppKit
import Combine

/// The engine that moves the bytes: sendme, the reference file transfer tool
/// of the iroh project, shipped inside the app as a helper and run once per
/// transfer. It connects the two computers directly (QUIC, with hole punching
/// through NAT), falls back to a relay when a direct path cannot be made,
/// encrypts end to end, verifies every block with BLAKE3 and resumes an
/// interrupted download.
///
/// The sender gets a code (a "ticket") that names its device and the content;
/// whoever has the code can fetch the content for as long as the sender keeps
/// offering it. There are no accounts and nothing is uploaded anywhere.
enum TransferEngine {
    static let name = "sendme"
    /// The release bundled by Tools/fetch-transfer-engine.sh. The parsing in
    /// TransferOutput follows what this version prints.
    static let version = "0.36.0"

    /// TIOCSWINSZ, which Swift does not import from the C headers.
    private static let setWindowSize: UInt = 0x8008_7467

    static var executableURL: URL? {
        let url = Bundle.main.bundleURL
            .appendingPathComponent("Contents/Helpers", isDirectory: true)
            .appendingPathComponent(name, isDirectory: false)
        return FileManager.default.isExecutableFile(atPath: url.path) ? url : nil
    }

    /// The ticket inside whatever was pasted: the bare code, or the whole
    /// "sendme receive blob…" line the command-line tool prints.
    static func ticket(in text: String) -> String? {
        guard let range = text.range(of: "blob[a-z0-9]{40,}", options: .regularExpression) else {
            return nil
        }
        return String(text[range])
    }

    /// A pseudo-terminal for the engine. It draws its progress bars only on a
    /// terminal, and this release aborts a send whose input is not one, so it
    /// is given one for both. The terminal is made wide enough that no bar is
    /// ever cut short. Nothing is typed into it.
    static func openTerminal() -> (master: Int32, slave: FileHandle)? {
        let master = posix_openpt(O_RDWR | O_NOCTTY)
        guard master >= 0 else { return nil }
        guard grantpt(master) == 0, unlockpt(master) == 0, let path = ptsname(master) else {
            close(master)
            return nil
        }
        var size = winsize(ws_row: 50, ws_col: 400, ws_xpixel: 0, ws_ypixel: 0)
        _ = ioctl(master, setWindowSize, &size)
        let slave = open(path, O_RDWR | O_NOCTTY)
        guard slave >= 0 else {
            close(master)
            return nil
        }
        return (master, FileHandle(fileDescriptor: slave, closeOnDealloc: true))
    }

    /// The last line worth showing from what a failed run printed, without
    /// the "error: " the tool puts in front of it.
    static func failureLine(in text: String) -> String {
        let lines = text.split(whereSeparator: \.isNewline)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        let line = lines.last(where: { $0.hasPrefix("error:") }) ?? lines.last ?? ""
        let cleaned = line.hasPrefix("error:")
            ? String(line.dropFirst("error:".count)).trimmingCharacters(in: .whitespaces)
            : line
        return String(cleaned.prefix(240))
    }
}

/// What the person chose in Settings › Transfers, and how each choice reaches
/// the engine.
enum TransferPreferences {
    enum Key {
        static let destinationPath = "transferDestinationPath"
        static let revealWhenDone = "transferRevealWhenDone"
        static let copyCodeAutomatically = "transferCopyCodeAutomatically"
        static let notifyReceived = "transferNotifyReceived"
        static let notifyUploadStarted = "transferNotifyUploadStarted"
        static let menuBarStatus = "transferMenuBarStatus"
        static let keepAwake = "transferKeepAwake"
        static let connectionMode = "transferConnectionMode"
        static let customRelayURL = "transferCustomRelayURL"
        static let hideAddresses = "transferHideAddresses"
        static let expiryMinutes = "transferExpiryMinutes"
    }

    enum ConnectionMode: String, CaseIterable, Identifiable {
        /// Direct when possible, the public relays otherwise.
        case automatic
        /// No relay at all.
        case direct
        /// A relay the person runs.
        case custom

        var id: String { rawValue }
    }

    /// Minutes a code stays valid; 0 keeps it until the send is stopped.
    static let expiryChoices = [60, 480, 1_440, 10_080, 0]

    static func registerDefaults() {
        UserDefaults.standard.register(defaults: [
            Key.destinationPath: "",
            Key.revealWhenDone: false,
            Key.copyCodeAutomatically: false,
            Key.notifyReceived: true,
            Key.notifyUploadStarted: true,
            Key.menuBarStatus: true,
            Key.keepAwake: true,
            Key.connectionMode: ConnectionMode.automatic.rawValue,
            Key.customRelayURL: "",
            Key.hideAddresses: false,
            Key.expiryMinutes: 1_440,
        ])
    }

    static var connectionMode: ConnectionMode {
        ConnectionMode(rawValue: UserDefaults.standard.string(forKey: Key.connectionMode) ?? "") ?? .automatic
    }

    /// The custom relay as typed, when it is a usable https address.
    static func validRelay(_ text: String) -> String? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let components = URLComponents(string: trimmed),
              components.scheme?.lowercased() == "https",
              let host = components.host, !host.isEmpty,
              components.user == nil, components.password == nil
        else { return nil }
        return trimmed
    }

    static var expiryMinutes: Int {
        let stored = UserDefaults.standard.integer(forKey: Key.expiryMinutes)
        return expiryChoices.contains(stored) ? stored : 1_440
    }

    /// The chosen folder while it still exists, otherwise Downloads.
    static var destination: URL {
        let path = UserDefaults.standard.string(forKey: Key.destinationPath) ?? ""
        if !path.isEmpty {
            var isDirectory: ObjCBool = false
            if FileManager.default.fileExists(atPath: path, isDirectory: &isDirectory), isDirectory.boolValue {
                return URL(fileURLWithPath: path, isDirectory: true)
            }
        }
        return FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true)
    }

    /// The engine's relay and ticket options for the current choices.
    static func networkArguments(sending: Bool) -> [String] {
        let defaults = UserDefaults.standard
        let hide = sending && defaults.bool(forKey: Key.hideAddresses)
        switch connectionMode {
        case .direct:
            // Without a relay the code can only carry direct addresses.
            return ["--relay", "disabled"]
        case .custom:
            if let relay = validRelay(defaults.string(forKey: Key.customRelayURL) ?? "") {
                return ["--relay", relay] + (hide ? ["--ticket-type", "Relay"] : [])
            }
            return hide ? ["--ticket-type", "Relay"] : []
        case .automatic:
            return hide ? ["--ticket-type", "Relay"] : []
        }
    }
}

/// Bytes going to one computer that is downloading something offered here.
struct TransferUpload: Equatable {
    var peer: String
    var sentBytes: Double
    var totalBytes: Double
    var rate: Double

    var fraction: Double {
        totalBytes > 0 ? min(sentBytes / totalBytes, 1) : 0
    }
}

/// One file or folder being offered to whoever holds its code.
final class TransferSend: ObservableObject, Identifiable {
    enum State: Equatable {
        case preparing
        case ready(ticket: String)
        case stopped
        case expired
        case failed(String)
    }

    let id = UUID()
    let source: URL
    @Published fileprivate(set) var state: State = .preparing
    /// The size the engine reported after reading the content, e.g. "1.2 GiB".
    @Published fileprivate(set) var sizeText: String?
    /// The download someone is making right now, nil while nobody is.
    @Published fileprivate(set) var upload: TransferUpload?
    /// When the code stops working, nil for a code that does not expire.
    @Published fileprivate(set) var expiresAt: Date?

    fileprivate var process: Process?
    fileprivate var terminalSource: DispatchSourceRead?
    fileprivate var output = ""
    fileprivate var errors = ""
    fileprivate var lines = TransferLineBuffer()
    fileprivate var totalBytes: Double = 0
    fileprivate var expireRequested = false
    fileprivate var onReady: ((String) -> Void)?
    fileprivate var onDownloadStarted: (() -> Void)?

    /// Progress of one request from the other side, kept across redraws.
    private struct Track {
        var index: Int
        var done: Double
        var total: Double
        /// Sizes of the blobs this request has already gone past.
        var completed: Double
        var lastPair: (Double, Double)?
    }

    private var tracks: [String: Track] = [:]
    fileprivate var lastUploadUpdate: Date?
    fileprivate var rateSample: (bytes: Double, time: Date)?

    fileprivate init(source: URL) {
        self.source = source
    }

    var isActive: Bool {
        switch state {
        case .preparing, .ready: return true
        case .stopped, .expired, .failed: return false
        }
    }

    fileprivate func consume(output text: String) {
        output += text
        // Only whole lines: a ticket cut in half by the pipe would be a
        // different, useless code.
        guard let lastNewline = output.lastIndex(where: \.isNewline) else { return }
        for line in output[..<lastNewline].split(whereSeparator: \.isNewline) {
            if sizeText == nil, line.hasPrefix("imported ") {
                let parts = line.components(separatedBy: ", ")
                if parts.count >= 3 {
                    sizeText = parts[parts.count - 2]
                    totalBytes = TransferOutput.bytes(parts[parts.count - 2]) ?? 0
                }
            }
            if state == .preparing, line.hasPrefix("sendme receive "),
               let ticket = TransferEngine.ticket(in: String(line)) {
                state = .ready(ticket: ticket)
                onReady?(ticket)
            }
        }
    }

    fileprivate func consume(terminal text: String) {
        for line in lines.append(text) {
            if let drawn = TransferOutput.upload(in: line) {
                apply(drawn)
            } else if line.hasPrefix("error") || line.contains("panicked") {
                errors += line + "\n"
            }
        }
    }

    /// Folds one redraw of a request's bar into the running total for it.
    ///
    /// The downloader first asks for the tail of every blob to learn the
    /// sizes; that is always request 0 of a connection and moves no content,
    /// so it is left out. The request after it walks the blobs in order, each
    /// from zero to its size. A redraw that still shows the previous blob's
    /// numbers under the next blob's index is skipped, as is one whose
    /// position is past its length; both are the engine catching up.
    private func apply(_ drawn: TransferOutput.Upload) {
        guard drawn.request > 0, drawn.done <= drawn.total else { return }
        let key = "\(drawn.connection)/\(drawn.request)"
        var isNew = false
        var track: Track
        if let known = tracks[key] {
            track = known
        } else {
            track = Track(index: drawn.index, done: 0, total: 0, completed: 0, lastPair: nil)
            isNew = true
        }
        if drawn.index != track.index {
            if let last = track.lastPair, last.0 == drawn.done, last.1 == drawn.total { return }
            track.completed += track.total
            track.index = drawn.index
        }
        track.done = drawn.done
        track.total = drawn.total
        track.lastPair = (drawn.done, drawn.total)
        tracks[key] = track

        let sent = track.completed + track.done
        lastUploadUpdate = Date()
        upload = TransferUpload(peer: drawn.peer,
                                sentBytes: sent,
                                totalBytes: max(totalBytes, sent),
                                rate: upload?.rate ?? 0)
        if isNew { onDownloadStarted?() }
    }

    /// Called once a second: the speed from what moved since the last call,
    /// and the end of an upload that has gone quiet.
    fileprivate func tick(now: Date) {
        guard var current = upload else { return }
        if let last = lastUploadUpdate, now.timeIntervalSince(last) > 3 {
            upload = nil
            rateSample = nil
            return
        }
        if let sample = rateSample {
            let elapsed = now.timeIntervalSince(sample.time)
            if elapsed >= 0.8 {
                let instant = max(current.sentBytes - sample.bytes, 0) / elapsed
                current.rate = current.rate > 0 ? current.rate * 0.5 + instant * 0.5 : instant
                rateSample = (current.sentBytes, now)
                upload = current
            }
        } else {
            rateSample = (current.sentBytes, now)
        }
    }

    fileprivate func finish() {
        process = nil
        terminalSource?.cancel()
        terminalSource = nil
        upload = nil
        switch state {
        case .ready:
            state = expireRequested ? .expired : .stopped
        case .preparing:
            state = .failed(TransferEngine.failureLine(in: errors + "\n" + output))
        case .stopped, .expired, .failed:
            break
        }
    }
}

/// One download, from a pasted code into a folder.
final class TransferReceive: ObservableObject, Identifiable {
    enum State: Equatable {
        case connecting
        case receiving
        /// Everything has arrived and is being written out to the folder.
        case finishing
        case done
        case cancelled
        case failed(String)
    }

    let id = UUID()
    let ticket: String
    let destination: URL
    @Published fileprivate(set) var state: State = .connecting
    /// The file or folder the content arrives as, once the sender has said.
    @Published fileprivate(set) var name: String?
    @Published fileprivate(set) var receivedBytes: Double = 0
    @Published fileprivate(set) var totalBytes: Double = 0
    @Published fileprivate(set) var rate: Double = 0
    @Published fileprivate(set) var fileCount: Int?

    fileprivate var process: Process?
    fileprivate var terminalSource: DispatchSourceRead?
    fileprivate var output = ""
    fileprivate var errors = ""
    fileprivate var lines = TransferLineBuffer()
    fileprivate var cancelRequested = false

    fileprivate init(ticket: String, destination: URL) {
        self.ticket = ticket
        self.destination = destination
    }

    var isActive: Bool {
        switch state {
        case .connecting, .receiving, .finishing: return true
        case .done, .cancelled, .failed: return false
        }
    }

    var fraction: Double {
        totalBytes > 0 ? min(receivedBytes / totalBytes, 1) : 0
    }

    /// Where the received item ended up, when the engine named it.
    var resultURL: URL? {
        guard state == .done, let name, !name.isEmpty else { return nil }
        return destination.appendingPathComponent(name)
    }

    fileprivate func consume(output text: String) {
        output += text
        for line in output.split(whereSeparator: \.isNewline) where line.hasPrefix("exporting to ") {
            name = String(line.dropFirst("exporting to ".count)).trimmingCharacters(in: .whitespaces)
        }
    }

    fileprivate func consume(terminal text: String) {
        for line in lines.append(text) {
            if let drawn = TransferOutput.download(in: line) {
                receivedBytes = drawn.done
                totalBytes = drawn.total
                rate = drawn.rate
                if state == .connecting { state = .receiving }
            } else if line.hasPrefix("getting collection") {
                fileCount = TransferOutput.files(in: line)
                if state == .connecting { state = .receiving }
            } else if line.hasPrefix("[4/4]") || line.hasPrefix("exporting ") {
                if state == .connecting || state == .receiving {
                    state = .finishing
                    rate = 0
                    if totalBytes > 0 { receivedBytes = totalBytes }
                }
            } else if !line.hasPrefix("[") {
                // Everything that is not a progress bar: warnings and the
                // final "error: …" line.
                errors += line + "\n"
            }
        }
    }

    fileprivate func finish(status: Int32) {
        process = nil
        terminalSource?.cancel()
        terminalSource = nil
        rate = 0
        if status == 0 {
            if totalBytes > 0 { receivedBytes = totalBytes }
            state = .done
        } else if cancelRequested {
            state = .cancelled
        } else {
            state = .failed(TransferEngine.failureLine(in: errors))
        }
    }
}

/// What is moving right now, across every transfer: the numbers the menu bar
/// shows beside the icon.
struct TransferActivity: Equatable {
    struct Flow: Equatable {
        var rate: Double
        var fraction: Double
    }

    var upload: Flow?
    var download: Flow?

    var isEmpty: Bool { upload == nil && download == nil }
}

/// Starts, follows and stops transfers. Used from the main thread only.
final class TransferService: ObservableObject {
    static let shared = TransferService()

    @Published private(set) var sends: [TransferSend] = []
    @Published private(set) var receives: [TransferReceive] = []
    @Published private(set) var activity = TransferActivity()

    private var ticker: Timer?
    private var awakeToken: NSObjectProtocol?

    private init() {
        TransferPreferences.registerDefaults()
    }

    var engineAvailable: Bool { TransferEngine.executableURL != nil }

    // MARK: - Engine

    private struct Launched {
        let process: Process
        let terminal: DispatchSourceRead
    }

    private enum LaunchError: Error {
        case unavailable
    }

    /// Runs the engine with its progress on a pseudo-terminal. `onOutput`
    /// gets what it prints for other programs, `onTerminal` what it draws for
    /// a person; all three callbacks arrive on the main thread.
    private func launch(arguments: [String],
                        directory: URL,
                        terminalInput: Bool,
                        onOutput: @escaping (String) -> Void,
                        onTerminal: @escaping (String) -> Void,
                        onExit: @escaping (Int32) -> Void) throws -> Launched {
        guard let engine = TransferEngine.executableURL,
              let terminal = TransferEngine.openTerminal() else { throw LaunchError.unavailable }

        let process = Process()
        process.executableURL = engine
        process.arguments = arguments
        process.currentDirectoryURL = directory
        // An app has no TERM of its own, and without one the engine treats
        // its terminal as unable to show progress.
        var environment = ProcessInfo.processInfo.environment
        environment["TERM"] = "xterm-256color"
        process.environment = environment
        process.standardInput = terminalInput ? terminal.slave : FileHandle.nullDevice
        process.standardError = terminal.slave
        let output = Pipe()
        process.standardOutput = output
        output.fileHandleForReading.readabilityHandler = { handle in
            let data = handle.availableData
            guard !data.isEmpty else {
                handle.readabilityHandler = nil
                return
            }
            let text = String(decoding: data, as: UTF8.self)
            DispatchQueue.main.async { onOutput(text) }
        }
        process.terminationHandler = { finished in
            let status = finished.terminationStatus
            // A moment for the last lines the engine drew to be read first:
            // the reason for a failure is among them.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { onExit(status) }
        }

        let master = terminal.master
        do {
            try process.run()
        } catch {
            output.fileHandleForReading.readabilityHandler = nil
            close(master)
            try? terminal.slave.close()
            throw error
        }
        // The engine holds its own copy of this end now.
        try? terminal.slave.close()

        // Read with read(2) rather than FileHandle: the end of a terminal is
        // reported as an error on some systems, which FileHandle raises as an
        // exception. Whatever the engine drew before this point is waiting in
        // the terminal's buffer.
        let source = DispatchSource.makeReadSource(fileDescriptor: master,
                                                   queue: DispatchQueue.global(qos: .utility))
        source.setEventHandler {
            var buffer = [UInt8](repeating: 0, count: 16_384)
            let count = read(master, &buffer, buffer.count)
            if count > 0 {
                let text = String(decoding: buffer[0..<count], as: UTF8.self)
                DispatchQueue.main.async { onTerminal(text) }
            } else {
                source.cancel()
            }
        }
        source.setCancelHandler { close(master) }
        source.resume()
        return Launched(process: process, terminal: source)
    }

    // MARK: - Sending

    func startSending(_ source: URL) {
        let session = TransferSend(source: source)
        sends.insert(session, at: 0)
        // The engine keeps its bookkeeping in the folder it is started from,
        // so each send gets a scratch folder of its own. The content itself is
        // read in place, not copied there.
        let work = FileManager.default.temporaryDirectory
            .appendingPathComponent("brastoo-transfer-\(session.id.uuidString)", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)
        } catch {
            session.state = .failed(error.localizedDescription)
            return
        }

        let defaults = UserDefaults.standard
        let name = source.lastPathComponent
        // Asked the first time it matters; macOS shows the prompt only once.
        if defaults.bool(forKey: TransferPreferences.Key.notifyUploadStarted) {
            Notifier.requestPermission()
        }
        session.onReady = { [weak session] ticket in
            let minutes = TransferPreferences.expiryMinutes
            session?.expiresAt = minutes > 0 ? Date().addingTimeInterval(Double(minutes) * 60) : nil
            if defaults.bool(forKey: TransferPreferences.Key.copyCodeAutomatically) {
                NSPasteboard.general.clearContents()
                NSPasteboard.general.setString(ticket, forType: .string)
            }
        }
        session.onDownloadStarted = {
            guard defaults.bool(forKey: TransferPreferences.Key.notifyUploadStarted) else { return }
            let text = TransferStrings.localized(L10n.shared.language)
            Notifier.post(title: text.notifyUploadTitle,
                          body: String(format: text.notifyUploadBodyFormat, name))
        }

        let arguments = ["send"] + TransferPreferences.networkArguments(sending: true) + [source.path]
        do {
            let launched = try launch(
                arguments: arguments,
                directory: work,
                terminalInput: true,
                onOutput: { [weak session] text in session?.consume(output: text) },
                onTerminal: { [weak session] text in session?.consume(terminal: text) },
                onExit: { [weak self, weak session] _ in
                    session?.finish()
                    try? FileManager.default.removeItem(at: work)
                    self?.refreshActivity()
                })
            session.process = launched.process
            session.terminalSource = launched.terminal
            startTicker()
        } catch {
            session.state = .failed(error is LaunchError ? "" : error.localizedDescription)
            try? FileManager.default.removeItem(at: work)
        }
    }

    /// Stops offering the content. The engine is asked to quit the way
    /// Control-C would, which lets it close its connections and clean up.
    func stop(_ session: TransferSend) {
        guard let process = session.process, process.isRunning else { return }
        process.interrupt()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            if process.isRunning { process.terminate() }
        }
    }

    func remove(_ session: TransferSend) {
        stop(session)
        sends.removeAll { $0 === session }
    }

    // MARK: - Receiving

    /// False when the text holds no code at all; nothing is started then.
    @discardableResult
    func startReceiving(code: String, into destination: URL) -> Bool {
        guard let ticket = TransferEngine.ticket(in: code) else { return false }
        let session = TransferReceive(ticket: ticket, destination: destination)
        receives.insert(session, at: 0)
        if UserDefaults.standard.bool(forKey: TransferPreferences.Key.notifyReceived) {
            Notifier.requestPermission()
        }

        let arguments = ["receive"] + TransferPreferences.networkArguments(sending: false) + [ticket]
        do {
            // The engine writes the result, and its resumable partial
            // download, into the folder it is started from.
            let launched = try launch(
                arguments: arguments,
                directory: destination,
                terminalInput: false,
                onOutput: { [weak session] text in session?.consume(output: text) },
                onTerminal: { [weak session] text in session?.consume(terminal: text) },
                onExit: { [weak self, weak session] status in
                    guard let session else { return }
                    session.finish(status: status)
                    self?.receiveDidFinish(session)
                    self?.refreshActivity()
                })
            session.process = launched.process
            session.terminalSource = launched.terminal
            startTicker()
        } catch {
            session.state = .failed(error is LaunchError ? "" : error.localizedDescription)
        }
        return true
    }

    private func receiveDidFinish(_ session: TransferReceive) {
        let defaults = UserDefaults.standard
        let text = TransferStrings.localized(L10n.shared.language)
        let name = session.name ?? ""
        switch session.state {
        case .done:
            if defaults.bool(forKey: TransferPreferences.Key.notifyReceived) {
                Notifier.post(title: text.notifyDoneTitle, body: name)
            }
            if defaults.bool(forKey: TransferPreferences.Key.revealWhenDone) {
                reveal(session)
            }
        case .failed:
            if defaults.bool(forKey: TransferPreferences.Key.notifyReceived) {
                Notifier.post(title: text.notifyFailedTitle, body: name)
            }
        case .connecting, .receiving, .finishing, .cancelled:
            break
        }
    }

    /// Shows the received item in the Finder, or its folder when the engine
    /// never named the item.
    func reveal(_ session: TransferReceive) {
        if let url = session.resultURL, FileManager.default.fileExists(atPath: url.path) {
            NSWorkspace.shared.activateFileViewerSelecting([url])
        } else {
            NSWorkspace.shared.open(session.destination)
        }
    }

    func cancel(_ session: TransferReceive) {
        guard let process = session.process, process.isRunning else { return }
        session.cancelRequested = true
        process.interrupt()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            if process.isRunning { process.terminate() }
        }
    }

    func remove(_ session: TransferReceive) {
        cancel(session)
        receives.removeAll { $0 === session }
    }

    // MARK: - Quitting

    /// Asks every running engine to quit. Called when the app terminates, so
    /// no helper is left offering or downloading after Brastoo is gone.
    func stopAll() {
        for session in sends {
            if let process = session.process, process.isRunning { process.interrupt() }
        }
        for session in receives {
            if let process = session.process, process.isRunning { process.interrupt() }
        }
        ticker?.invalidate()
        ticker = nil
        setKeepAwake(false)
    }

    // MARK: - Once a second

    private func startTicker() {
        guard ticker == nil else { return }
        let timer = Timer(timeInterval: 1, repeats: true) { [weak self] _ in
            self?.tick()
        }
        timer.tolerance = 0.1
        RunLoop.main.add(timer, forMode: .common)
        ticker = timer
    }

    private func tick() {
        let now = Date()
        for session in sends where session.isActive {
            session.tick(now: now)
            if let expiry = session.expiresAt, now >= expiry, !session.expireRequested {
                session.expireRequested = true
                stop(session)
            }
        }
        refreshActivity()
        let anythingRunning = sends.contains(where: \.isActive) || receives.contains(where: \.isActive)
        if !anythingRunning {
            ticker?.invalidate()
            ticker = nil
        }
    }

    /// Recomputes what the menu bar shows and whether the Mac is kept awake.
    private func refreshActivity() {
        var current = TransferActivity()

        let uploads = sends.compactMap(\.upload)
        if !uploads.isEmpty {
            let sent = uploads.reduce(0) { $0 + $1.sentBytes }
            let total = uploads.reduce(0) { $0 + $1.totalBytes }
            current.upload = TransferActivity.Flow(
                rate: uploads.reduce(0) { $0 + $1.rate },
                fraction: total > 0 ? min(sent / total, 1) : 0)
        }

        let downloads = receives.filter { $0.state == .receiving || $0.state == .finishing }
        if !downloads.isEmpty {
            let received = downloads.reduce(0) { $0 + $1.receivedBytes }
            let total = downloads.reduce(0) { $0 + $1.totalBytes }
            current.download = TransferActivity.Flow(
                rate: downloads.reduce(0) { $0 + $1.rate },
                fraction: total > 0 ? min(received / total, 1) : 0)
        }

        if current != activity { activity = current }

        let anythingRunning = sends.contains(where: \.isActive) || receives.contains(where: \.isActive)
        setKeepAwake(anythingRunning && UserDefaults.standard.bool(forKey: TransferPreferences.Key.keepAwake))
    }

    private func setKeepAwake(_ wanted: Bool) {
        if wanted, awakeToken == nil {
            awakeToken = ProcessInfo.processInfo.beginActivity(
                options: [.idleSystemSleepDisabled],
                reason: "Brastoo file transfer")
        } else if !wanted, let token = awakeToken {
            ProcessInfo.processInfo.endActivity(token)
            awakeToken = nil
        }
    }
}
