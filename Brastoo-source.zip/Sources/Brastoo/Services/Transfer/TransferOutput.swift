// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import Foundation

/// Reads what the transfer engine draws on its terminal. sendme reports
/// progress only as the progress bars it paints for a person, so the app gives
/// it a pseudo-terminal and reads the bars back: bytes done, total and speed.
/// Checked against the lines version 0.36.0 really prints.
enum TransferOutput {
    /// One redraw of the downloader's bar.
    struct Download: Equatable {
        let done: Double
        let total: Double
        let rate: Double
    }

    /// One redraw of a bar on the sending side. The engine draws one bar per
    /// request and walks it through the blobs of the content in order.
    struct Upload: Equatable {
        /// Short id of the computer on the other end.
        let peer: String
        let connection: String
        let request: Int
        /// Which blob of the content the bar is on.
        let index: Int
        let done: Double
        let total: Double
    }

    private static let amount = "[0-9.]+ [KMGTPE]?i?B"
    private static let escapes = try! NSRegularExpression(pattern: "\u{001B}\\[[0-9;?]*[A-Za-z]")
    private static let downloadLine = try! NSRegularExpression(
        pattern: "Downloading.*\\] (\(amount))/(\(amount)) (\(amount))/s")
    private static let uploadLine = try! NSRegularExpression(
        pattern: "n (\\S+) r (\\d+)/(\\d+) i (\\d+) # \\S+.*\\] (\(amount))/(\(amount))\\s*$")
    private static let fileCount = try! NSRegularExpression(pattern: "(\\d+) files")

    private static func groups(_ regex: NSRegularExpression, in line: String) -> [String]? {
        let range = NSRange(line.startIndex..., in: line)
        guard let match = regex.firstMatch(in: line, options: [], range: range) else { return nil }
        var found: [String] = []
        for index in 1..<match.numberOfRanges {
            guard let part = Range(match.range(at: index), in: line) else { return nil }
            found.append(String(line[part]))
        }
        return found
    }

    /// The text with the terminal's colour and cursor codes taken out.
    static func withoutEscapes(_ text: String) -> String {
        let range = NSRange(text.startIndex..., in: text)
        return escapes.stringByReplacingMatches(in: text, options: [], range: range, withTemplate: "")
    }

    /// "123.28 MiB" as a number of bytes. The engine always uses binary units.
    static func bytes(_ text: String) -> Double? {
        let parts = text.split(separator: " ")
        guard parts.count == 2, let value = Double(parts[0]) else { return nil }
        switch parts[1] {
        case "B": return value
        case "KiB": return value * 1_024
        case "MiB": return value * 1_048_576
        case "GiB": return value * 1_073_741_824
        case "TiB": return value * 1_099_511_627_776
        case "PiB": return value * 1_125_899_906_842_624
        default: return nil
        }
    }

    static func download(in line: String) -> Download? {
        guard let found = groups(downloadLine, in: line), found.count == 3,
              let done = bytes(found[0]), let total = bytes(found[1]), let rate = bytes(found[2])
        else { return nil }
        return Download(done: done, total: total, rate: rate)
    }

    static func upload(in line: String) -> Upload? {
        guard let found = groups(uploadLine, in: line), found.count == 6,
              let request = Int(found[2]), let index = Int(found[3]),
              let done = bytes(found[4]), let total = bytes(found[5])
        else { return nil }
        return Upload(peer: found[0], connection: found[1], request: request,
                      index: index, done: done, total: total)
    }

    /// The number in "getting collection … 3 files, …".
    static func files(in line: String) -> Int? {
        guard let found = groups(fileCount, in: line), let first = found.first else { return nil }
        return Int(first)
    }
}

/// Turns the engine's terminal stream into whole lines. A bar is redrawn by
/// returning to the start of the line, so a line ends at a carriage return as
/// well as at a newline; whatever follows the last of either is kept until
/// the next chunk completes it.
struct TransferLineBuffer {
    private var pending = ""

    mutating func append(_ chunk: String) -> [String] {
        pending += chunk
        guard let last = pending.lastIndex(where: { $0 == "\r" || $0 == "\n" || $0 == "\r\n" }) else {
            // No line end in sight: never let a stream without one grow unbounded.
            if pending.count > 65_536 { pending = "" }
            return []
        }
        let complete = String(pending[...last])
        pending = String(pending[pending.index(after: last)...])
        return TransferOutput.withoutEscapes(complete)
            .split(whereSeparator: { $0 == "\r" || $0 == "\n" || $0 == "\r\n" })
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }
}

/// How amounts, speeds and times are written in the window and the menu bar.
enum TransferFormat {
    private static let byteFormatter: ByteCountFormatter = {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        formatter.allowsNonnumericFormatting = false
        return formatter
    }()

    static func size(_ bytes: Double) -> String {
        byteFormatter.string(fromByteCount: Int64(max(bytes, 0)))
    }

    static func rate(_ bytesPerSecond: Double) -> String {
        size(bytesPerSecond) + "/s"
    }

    static func percent(_ fraction: Double) -> String {
        "\(Int((min(max(fraction, 0), 1) * 100).rounded(.down)))%"
    }

    /// "0:42", "12:05" or "1:03:20".
    static func duration(_ seconds: Double) -> String {
        let total = Int(max(seconds, 0).rounded())
        let hours = total / 3_600
        let minutes = (total % 3_600) / 60
        let rest = total % 60
        return hours > 0
            ? String(format: "%d:%02d:%02d", hours, minutes, rest)
            : String(format: "%d:%02d", minutes, rest)
    }
}
