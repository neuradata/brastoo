// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Amira Labs, Inc.

import CryptoKit
import Foundation
import IOKit
import SystemConfiguration

/// Tells Amira Labs' own panel that this copy of Brastoo is installed and
/// still in use, so the company can see how many computers run it.
///
/// What is sent, when the app opens and every few hours while it runs: an id
/// for this Mac, the computer's name, its model, and the Brastoo and macOS
/// versions. Nothing about what the app is used for.
///
/// The panel's address and key are not in the source: build.sh stamps them
/// into the bundle's Info.plist from Server/painel.local, the file
/// Server/Publicar-Painel.command writes. A build made without that file has
/// neither, and then this does nothing at all.
final class InstallHeartbeat {
    static let shared = InstallHeartbeat()

    struct Configuration {
        let endpoint: URL
        let key: String
    }

    /// Where to report, or nil when this build reports nowhere.
    static let configuration: Configuration? = {
        // The Developer build is the one being worked on, not an installation.
        if AppInfo.isDeveloperBuild { return nil }
        let info = Bundle.main
        guard let address = info.object(forInfoDictionaryKey: "BrastooInstallsEndpoint") as? String,
              let key = info.object(forInfoDictionaryKey: "BrastooInstallsKey") as? String,
              !key.isEmpty,
              let base = URL(string: address), base.scheme == "https", base.host != nil
        else { return nil }
        return Configuration(endpoint: base.appendingPathComponent("v1/seen"), key: key)
    }()

    static var isActive: Bool { configuration != nil }

    /// How long a successful report stands before the next one.
    private static let interval: TimeInterval = 6 * 60 * 60
    /// How often the app looks at whether a report is due. A report that
    /// failed, say with no network, is tried again on the next look.
    private static let checkEvery: TimeInterval = 30 * 60
    private static let fallbackIdentifierKey = "installIdentifier"

    private var timer: Timer?
    private var lastSent: Date?
    private var sending = false
    private lazy var session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 15
        configuration.timeoutIntervalForResource = 30
        configuration.httpCookieStorage = nil
        configuration.urlCache = nil
        configuration.waitsForConnectivity = false
        return URLSession(configuration: configuration)
    }()

    private init() {}

    /// Call once at launch, on the main thread.
    func start() {
        guard timer == nil, Self.isActive else { return }
        // Not in the first seconds: launch has more urgent things to do.
        DispatchQueue.main.asyncAfter(deadline: .now() + 20) { [weak self] in
            self?.sendIfDue()
        }
        let timer = Timer(timeInterval: Self.checkEvery, repeats: true) { [weak self] _ in
            self?.sendIfDue()
        }
        timer.tolerance = 5 * 60
        RunLoop.main.add(timer, forMode: .common)
        self.timer = timer
    }

    private func sendIfDue() {
        guard let configuration = Self.configuration, !sending else { return }
        if let lastSent, Date().timeIntervalSince(lastSent) < Self.interval { return }

        let version = ProcessInfo.processInfo.operatingSystemVersion
        let report: [String: String] = [
            "id": Self.identifier,
            "name": Self.computerName,
            "model": Self.model,
            "app": AppInfo.version,
            "os": "\(version.majorVersion).\(version.minorVersion).\(version.patchVersion)",
        ]
        guard let body = try? JSONSerialization.data(withJSONObject: report) else { return }

        var request = URLRequest(url: configuration.endpoint)
        request.httpMethod = "POST"
        request.httpBody = body
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(configuration.key, forHTTPHeaderField: "X-Brastoo-Key")

        sending = true
        session.dataTask(with: request) { [weak self] _, response, _ in
            let accepted = (response as? HTTPURLResponse).map { (200..<300).contains($0.statusCode) } ?? false
            DispatchQueue.main.async {
                guard let self else { return }
                self.sending = false
                if accepted { self.lastSent = Date() }
            }
        }.resume()
    }

    // MARK: - What identifies this Mac

    /// One id per Mac, the same after the app is reinstalled or its settings
    /// are reset, so a computer is never counted twice. It is a digest of the
    /// hardware id, not the hardware id itself.
    private static let identifier: String = {
        if let hardware = hardwareIdentifier {
            let digest = SHA256.hash(data: Data(("brastoo.install." + hardware).utf8))
            return uuidText(Array(digest.prefix(16)))
        }
        let defaults = UserDefaults.standard
        if let stored = defaults.string(forKey: fallbackIdentifierKey), UUID(uuidString: stored) != nil {
            return stored.lowercased()
        }
        let fresh = UUID().uuidString.lowercased()
        defaults.set(fresh, forKey: fallbackIdentifierKey)
        return fresh
    }()

    private static var hardwareIdentifier: String? {
        let service = IOServiceGetMatchingService(kIOMainPortDefault,
                                                  IOServiceMatching("IOPlatformExpertDevice"))
        guard service != 0 else { return nil }
        defer { IOObjectRelease(service) }
        let property = IORegistryEntryCreateCFProperty(service, "IOPlatformUUID" as CFString,
                                                       kCFAllocatorDefault, 0)
        guard let value = property?.takeRetainedValue() as? String, !value.isEmpty else { return nil }
        return value
    }

    /// Sixteen bytes written the way an id is written: 8-4-4-4-12.
    private static func uuidText(_ bytes: [UInt8]) -> String {
        let hex = bytes.map { String(format: "%02x", $0) }.joined()
        let cuts = [8, 4, 4, 4, 12]
        var parts: [String] = []
        var start = hex.startIndex
        for length in cuts {
            let end = hex.index(start, offsetBy: length)
            parts.append(String(hex[start..<end]))
            start = end
        }
        return parts.joined(separator: "-")
    }

    /// The name in System Settings › General › About, e.g. "MacBook Pro de Ana".
    private static var computerName: String {
        if let name = SCDynamicStoreCopyComputerName(nil, nil) as String?, !name.isEmpty {
            return String(name.prefix(80))
        }
        return "Mac"
    }

    /// The model identifier, e.g. "Mac15,6".
    private static let model: String = {
        var size = 0
        guard sysctlbyname("hw.model", nil, &size, nil, 0) == 0, size > 0 else { return "" }
        var buffer = [CChar](repeating: 0, count: size)
        guard sysctlbyname("hw.model", &buffer, &size, nil, 0) == 0 else { return "" }
        let allowed = Set("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz,._ -")
        return String(String(cString: buffer).filter { allowed.contains($0) }.prefix(40))
    }()
}
