// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Vorssaint

import AppKit
import Combine

/// Owns the menu bar presence: the black hole glyph, the optional countdown
/// title and the tooltip. Click handling is delegated back to the AppDelegate.
final class StatusItemController {
    var onLeftClick: (() -> Void)?
    /// Receives the button that was clicked, so a menu can open from it
    /// while the main item is out of the bar.
    var onRightClick: ((NSStatusBarButton?) -> Void)?
    var onMetricClick: ((MenuBarMetric, NSStatusBarButton) -> Void)?
    var onClipboardPreviewClick: (() -> Void)?
    /// A click on the transfer figures beside the icon, rather than on the
    /// icon itself.
    var onTransferStatusClick: (() -> Void)?
    /// How wide the transfer figures were drawn at the start of the title,
    /// zero while none are shown. A click within that width is on them.
    private var renderedTransferWidth: CGFloat = 0

    private(set) var statusItem: NSStatusItem!
    /// The optional "show latest copy" item: same shape as a metric item —
    /// independent, opt-in and separately clickable — but not itself a
    /// MenuBarMetric, since its content comes from ClipboardHistoryService
    /// rather than a SystemSnapshot reading.
    private var clipboardPreviewStatusItem: NSStatusItem?
    private var metricStatusItems: [String: NSStatusItem] = [:]
    private var metricStatusItemFocus: [String: MenuBarMetric] = [:]
    private var cancellables = Set<AnyCancellable>()
    private var titleTimer: Timer?
    private var defaultsObserver: NSObjectProtocol?
    /// Last combination applied by updateIconAppearance, so refresh ticks
    /// don't re-render an unchanged icon every 2 seconds.
    private var lastIconStateKey = ""
    /// Mirrors only the island's fullscreen presentation state. A notification
    /// avoids loading NotchService when its feature was never installed.
    private(set) var islandHiddenInFullscreen = false
    /// True while the app itself keeps the main item out of the bar, for
    /// Dynamic Island or for separate metrics, as opposed to macOS dropping
    /// it. Recovery leaves such an item alone.
    private(set) var mainItemHiddenByChoice = false
    private var heldMicBadgeActive: Bool?
    /// A settings reply already waiting for the next turn of the run loop.
    private var settingsSyncScheduled = false
    /// How many readings in a row each metric has failed to render, so an
    /// item is kept through a hiccup but not forever.
    private var metricEmptyRenders: [String: Int] = [:]
    /// How many metric items are actually showing a reading. An item kept
    /// through a hiccup shows nothing, so it must not be what makes the main
    /// item step aside: that would leave the menu bar with nothing to click.
    private var renderedMetricItemCount = 0
    /// True while a refresh is running. Anything the menu bar announces back
    /// to us in the middle of one is a consequence of that same work, so it
    /// is answered once afterwards rather than on top of it.
    private var isRefreshing = false
    private var refreshRequestedWhileRunning = false
    /// True once the clipboard preview's own subscriptions are wired up.
    /// Merely referencing ClipboardHistoryService.shared brings the whole
    /// service to life — its saved history file and image folder included —
    /// so bind() only touches it once the feature is actually available,
    /// rather than for every launch regardless of whether anyone uses it.
    private var clipboardBindingsInstalled = false
    private static let mainAutosaveName = "BrastooMenuBarItem"
    private static let metricAutosavePrefix = "BrastooMetric"
    private static let clipboardPreviewAutosaveName = "BrastooClipboardPreview"
    private static let maxPlacementGeneration = 10_000
    private static let emptyStatusImage = NSImage()

    /// One separate menu bar item: a metric, or a metric with its temperature
    /// when the two are combined.
    struct MetricStatusGroup {
        let id: String
        let metrics: [MenuBarMetric]
        let focusMetric: MenuBarMetric
        let title: String
    }

    /// Cached so the countdown tooltip doesn't allocate a DateFormatter (expensive)
    /// on every refresh while a keep-awake session is active.
    private static let timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter
    }()

    var button: NSStatusBarButton? { statusItem.button }

    func containsStatusItem(at screenPoint: NSPoint) -> Bool {
        let items = [statusItem, clipboardPreviewStatusItem].compactMap { $0 } + Array(metricStatusItems.values)
        // A hidden item keeps its last frame, which another app's item may
        // occupy by now.
        let buttons = items.filter(\.isVisible).compactMap(\.button)
        // Bound once for the whole scan: a default argument is evaluated per
        // call, so leaving it to the default would rebuild this per button.
        let screenFrames = NSScreen.screens.map(\.frame)
        return buttons.contains { button in
            guard let frame = button.window?.frame,
                  StatusItemAnchorSupport.isTrustworthyStatusFrame(frame, screenFrames: screenFrames)
            else { return false }
            return frame.insetBy(dx: -4, dy: -8).contains(screenPoint)
        }
    }

    init() {
        installStatusItem()
        bind()
    }

    /// Creates the status item and configures its button. The menu bar item is the
    /// app's entry point unless the person lets Dynamic Island stand in for it, so
    /// an empty behavior set keeps it from being dragged off the bar (reordering
    /// still works), and forcing isVisible undoes any hidden state macOS may have
    /// persisted. If it ever goes missing, re-opening the app recovers access (see
    /// applicationShouldHandleReopen) and the "Show menu bar icon" button in
    /// Settings rebuilds it.
    private func installStatusItem() {
        // Nothing here may touch the saved placement. 3.3.3 retired a legacy
        // 64pt offset on every launch and took working coordinates with it;
        // giving up a spot is now something only an explicit recovery does.
        //
        // A fresh NSStatusItem starts blank; the memoized icon state belongs
        // to the previous instance and must not suppress the first apply.
        lastIconStateKey = ""
        // Recovery must place the full content from the start. A square slot
        // can fit while its expanded title is dropped, leaving a stale frame
        // that incorrectly makes the recovery look successful.
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        // A stable identity so macOS remembers the item's position across launches
        // and across rebuilds, instead of re-placing it at the crowded default spot.
        statusItem.autosaveName = StatusItemPlacementSupport.mainAutosaveName(in: .standard)
        statusItem.behavior = []
        statusItem.isVisible = true
        if let button = statusItem.button {
            button.image = BlackHoleGlyph.image(active: false)
            button.font = MenuBarRenderer.statusFont(stacked: false)
            button.alignment = .left
            button.cell?.lineBreakMode = .byClipping
            button.cell?.usesSingleLineMode = false
            button.target = self
            button.action = #selector(clicked)
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
        }
        refresh()
        syncMonitorMode()
        updateIconAppearance()
    }

    /// Tears the status item down and builds a fresh one, dropping the hidden state
    /// macOS remembered for it so the rebuilt one is not put straight back out of
    /// sight — while keeping the spot the person arranged, which a brand new
    /// identity would throw away.
    func recreateStatusItem() {
        // The item goes away first: AppKit writes its placement and remembered
        // visibility back under its own name as it is removed, which would put
        // back whatever was cleared a moment earlier.
        if let statusItem { NSStatusBar.system.removeStatusItem(statusItem) }
        StatusItemPlacementSupport.clearRememberedVisibility(in: .standard)
        installStatusItem()
    }

    /// Starts the item over under a brand new identity, giving up the saved
    /// position along with everything else macOS remembered about it. Last
    /// resort: the item lands wherever macOS puts a first-time item, which on
    /// a crowded bar can be a worse place than the one it came from, so this
    /// is only for an icon that stayed away after keeping its spot.
    func resetStatusItemPlacementIdentity() {
        if let statusItem { NSStatusBar.system.removeStatusItem(statusItem) }
        StatusItemPlacementSupport.bumpPlacementGeneration(in: .standard)
        installStatusItem()
    }

    private func bind() {
        KeepAwakeManager.shared.$isActive
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.updateIconAppearance()
                self?.refresh()
            }
            .store(in: &cancellables)

        UpdateService.shared.$state
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in self?.updateIconAppearance() }
            .store(in: &cancellables)

        MicMuteService.shared.$isMuted
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in self?.updateIconAppearance() }
            .store(in: &cancellables)

        KeepAwakeManager.shared.$endDate
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in self?.refresh() }
            .store(in: &cancellables)

        L10n.shared.$language
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in self?.refresh() }
            .store(in: &cancellables)

        SystemMonitor.shared.$snapshot
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                guard MenuBarMetric.anyEnabled(in: .standard) else { return }
                self?.refresh()
            }
            .store(in: &cancellables)

        NotificationCenter.default.publisher(for: NotchService.fullscreenVisibilityDidChange)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] notification in
                guard let self, let hidden = notification.userInfo?["hidden"] as? Bool,
                      hidden != self.islandHiddenInFullscreen else { return }
                self.islandHiddenInFullscreen = hidden
                self.refresh()
            }
            .store(in: &cancellables)

        TransferService.shared.$activity
            .removeDuplicates()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in self?.refresh() }
            .store(in: &cancellables)

        bindClipboardPreviewIfAvailable()

        defaultsObserver = NotificationCenter.default.addObserver(forName: UserDefaults.didChangeNotification,
                                                                  object: nil,
                                                                  queue: .main) { [weak self] _ in
            // Showing a status item writes its own remembered position into
            // this same domain and announces it right there on the stack, so
            // reacting immediately would call back into the work that is
            // still running. The reply waits for the next turn of the run
            // loop, and a burst of writes collapses into one.
            self?.scheduleSettingsSync()
        }
    }

    private func scheduleSettingsSync() {
        guard !settingsSyncScheduled else { return }
        settingsSyncScheduled = true
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.settingsSyncScheduled = false
            self.syncMonitorMode()
            self.updateIconAppearance()
            self.refresh()
            self.bindClipboardPreviewIfAvailable()
            self.syncClipboardPreviewItem()
        }
    }

    /// Wires up the clipboard preview's own subscriptions the first time the
    /// feature is actually available — at launch if it already is, or the
    /// moment a settings change (installing it from the hub, included) makes
    /// it so. Referencing ClipboardHistoryService.shared any earlier would
    /// bring the service to life for every launch, reading its saved history
    /// file and scanning its image folder even for someone who never turned
    /// the feature on.
    private func bindClipboardPreviewIfAvailable() {
        guard !clipboardBindingsInstalled, AppFeature.clipboardHistory.isAvailable else { return }
        clipboardBindingsInstalled = true
        ClipboardHistoryService.shared.$latestPasteboardEntry
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in self?.syncClipboardPreviewItem() }
            .store(in: &cancellables)

        ClipboardHistoryService.shared.$isRunning
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in self?.syncClipboardPreviewItem() }
            .store(in: &cancellables)
    }

    deinit {
        // The controller lives for the whole process today, but tear down cleanly
        // so a future "recreate the status item" path can't leak a firing timer or
        // a block observer that outlives this instance.
        titleTimer?.invalidate()
        if let defaultsObserver { NotificationCenter.default.removeObserver(defaultsObserver) }
        for item in metricStatusItems.values {
            NSStatusBar.system.removeStatusItem(item)
        }
        if let clipboardPreviewStatusItem {
            NSStatusBar.system.removeStatusItem(clipboardPreviewStatusItem)
        }
    }

    /// Keeps the background sampler in step with the menu bar settings: it runs
    /// continuously only while at least one metric is pinned to the menu bar.
    private func syncMonitorMode() {
        let defaults = UserDefaults.standard
        let interval = Defaults.sanitizedMonitorInterval(defaults.integer(forKey: DefaultsKey.monitorInterval))
        SystemMonitor.shared.setInterval(seconds: interval)
        SystemMonitor.shared.setMenuBarActive(MenuBarMetric.anyEnabled(in: defaults))
    }

    private func syncTitleTimer(keepAwakeActive: Bool,
                                showsCountdown: Bool,
                                endDate: Date?) {
        let shouldRun = MenuBarSpacingSupport.needsTitleRefreshTimer(
            keepAwakeActive: keepAwakeActive,
            showsCountdown: showsCountdown,
            hasEndDate: endDate != nil)
        guard shouldRun else {
            titleTimer?.invalidate()
            titleTimer = nil
            return
        }
        guard titleTimer == nil else { return }
        let timer = Timer(timeInterval: 30, repeats: true) { [weak self] _ in
            self?.refresh()
        }
        timer.tolerance = 5
        RunLoop.main.add(timer, forMode: .common)
        titleTimer = timer
    }

    private var currentMicBadgeActive: Bool {
        MicMuteService.shared.isMuted
            && UserDefaults.standard.bool(forKey: DefaultsKey.micMuteMenuBarIndicator)
    }

    private var renderedMicBadgeActive: Bool {
        heldMicBadgeActive ?? currentMicBadgeActive
    }

    /// Keeps the variable-width mic badge unchanged while any status item is
    /// anchoring an open panel. The current state is rendered after it closes.
    func setMicBadgeHeld(_ held: Bool) {
        if held {
            guard heldMicBadgeActive == nil else { return }
            heldMicBadgeActive = currentMicBadgeActive
            return
        }
        guard heldMicBadgeActive != nil else { return }
        heldMicBadgeActive = nil
        updateIconAppearance()
    }

    /// Reflects keep-awake state and an available update in the icon. Updates
    /// keep the blue attention glyph; an active session uses the chosen icon.
    /// With the mute indicator option on, a red slashed mic joins the glyph
    /// while the microphone is muted, whatever the underlying state. The
    /// glyph can also hide entirely while metrics render in the title (user
    /// option); the decision reads the button's actual title, so it must run
    /// AFTER refresh() writes it — refresh() calls this at its end.
    private func updateIconAppearance() {
        guard let button = statusItem?.button else { return }
        let defaults = UserDefaults.standard
        let updateAvailable: Bool
        if case .available = UpdateService.shared.state {
            updateAvailable = true
        } else {
            updateAvailable = false
        }
        let micBadgeActive = renderedMicBadgeActive
        let optionEnabled = defaults.bool(forKey: DefaultsKey.menuBarHideIconWithMetrics)
        let separateMetrics = defaults.bool(forKey: DefaultsKey.menuBarSeparateMetrics)
        let signal = updateAvailable || micBadgeActive
        let islandHides = MenuBarSpacingSupport.islandHidesStatusIcon(
            in: defaults, hiddenInFullscreen: islandHiddenInFullscreen) && !signal
        let hidden = islandHides || MenuBarSpacingSupport.shouldHideStatusIcon(
            optionEnabled: optionEnabled,
            separateMetrics: separateMetrics,
            metricsEnabled: MenuBarMetric.anyEnabled(in: defaults),
            renderedTitleLength: button.attributedTitle.length,
            mustShowForSignal: signal)
        // In the separate-items mode the metrics are their own clickable
        // items, so hiding means the whole main item steps aside instead of
        // just its image (which is all that item has). With Dynamic Island
        // standing in, the item goes whenever it has no text of its own.
        let mainItemHidden = (islandHides && button.attributedTitle.length == 0)
            || MenuBarSpacingSupport.shouldHideMainStatusItem(
                optionEnabled: optionEnabled,
                separateMetrics: separateMetrics,
                metricItemsShown: renderedMetricItemCount,
                renderedTitleLength: button.attributedTitle.length,
                mustShowForSignal: signal)
        mainItemHiddenByChoice = mainItemHidden
        let keepAwakeActive = KeepAwakeManager.shared.isActive

        // refresh() runs on every monitor tick and lands here; re-rendering
        // the same image every 2 seconds would be wasted composition, so the
        // image is only touched when some ingredient actually changed.
        let stateKey = [String(hidden), String(mainItemHidden), String(updateAvailable),
                        String(keepAwakeActive), KeepAwakeIconTint.current.rawValue,
                        KeepAwakeActiveIcon.current.rawValue, BlackHoleGlyph.chosenSymbolName,
                        String(micBadgeActive)].joined(separator: "|")
        guard stateKey != lastIconStateKey else { return }
        lastIconStateKey = stateKey

        statusItem.isVisible = !mainItemHidden

        guard !hidden else {
            // A non-nil image lets macOS apply the inactive-display appearance
            // to the title while keeping the glyph visually absent.
            button.image = Self.emptyStatusImage
            return
        }
        let stateImage: NSImage?
        if updateAvailable {
            stateImage = BlackHoleGlyph.attentionImage()
        } else {
            stateImage = BlackHoleGlyph.image(active: keepAwakeActive)
        }
        if micBadgeActive {
            button.image = BlackHoleGlyph.micMutedImage(over: stateImage) ?? stateImage
        } else {
            button.image = stateImage
        }
    }

    @objc private func clicked() {
        if NSApp.currentEvent?.type == .rightMouseUp {
            onRightClick?(statusItem.button)
        } else if clickIsOnTransferStatus() {
            onTransferStatusClick?()
        } else {
            onLeftClick?()
        }
    }

    /// True when the click landed on the transfer figures. They are the first
    /// thing in the title, right after the icon, so the title's own rectangle
    /// says where they start.
    private func clickIsOnTransferStatus() -> Bool {
        guard renderedTransferWidth > 0,
              let button = statusItem.button,
              let event = NSApp.currentEvent,
              event.window === button.window,
              let cell = button.cell as? NSButtonCell else { return false }
        let point = button.convert(event.locationInWindow, from: nil)
        let start = cell.titleRect(forBounds: button.bounds).minX
        return point.x >= start - 2 && point.x <= start + renderedTransferWidth + 6
    }

    /// "↑ 12,3 MB/s 45%" and "↓ 3,1 MB/s 10%" for whatever is moving, with the
    /// arrows in the brand's blue. Nil while nothing moves or the option is off.
    private static func transferTitle(for activity: TransferActivity,
                                      defaults: UserDefaults) -> NSAttributedString? {
        guard !activity.isEmpty,
              defaults.bool(forKey: TransferPreferences.Key.menuBarStatus) else { return nil }
        let blue = NSColor(srgbRed: 9.0 / 255.0, green: 141.0 / 255.0, blue: 226.0 / 255.0, alpha: 1)
        let title = NSMutableAttributedString()
        func append(_ arrow: String, _ flow: TransferActivity.Flow) {
            if title.length > 0 { title.append(NSAttributedString(string: "  ")) }
            title.append(NSAttributedString(string: arrow, attributes: [.foregroundColor: blue]))
            let figures = " \(TransferFormat.rate(flow.rate)) \(TransferFormat.percent(flow.fraction))"
            title.append(NSAttributedString(string: figures))
        }
        if let upload = activity.upload { append("↑", upload) }
        if let download = activity.download { append("↓", download) }
        return title
    }

    /// The item a right-click menu opens from: the main one while it is in
    /// the bar, otherwise the item that was clicked. A menu set on an item
    /// that is out of the bar has nowhere on screen to open from.
    func menuHost(for button: NSStatusBarButton?) -> NSStatusItem {
        guard !statusItem.isVisible, let button else { return statusItem }
        let others = [clipboardPreviewStatusItem].compactMap { $0 } + Array(metricStatusItems.values)
        return others.first { $0.button === button } ?? statusItem
    }

    /// Updates the countdown title and tooltip from the current session state.
    func refresh() {
        guard !isRefreshing else {
            refreshRequestedWhileRunning = true
            return
        }
        isRefreshing = true
        defer {
            isRefreshing = false
            if refreshRequestedWhileRunning {
                refreshRequestedWhileRunning = false
                DispatchQueue.main.async { [weak self] in self?.refresh() }
            }
        }
        performRefresh()
    }

    private func performRefresh() {
        guard let button = statusItem?.button else { return }
        let manager = KeepAwakeManager.shared
        let strings = L10n.shared.s
        let defaults = UserDefaults.standard
        let snapshot = SystemMonitor.shared.snapshot
        let metrics = MenuBarMetric.enabled(in: defaults)
        let separateMetrics = defaults.bool(forKey: DefaultsKey.menuBarSeparateMetrics)

        syncTitleTimer(keepAwakeActive: manager.isActive,
                       showsCountdown: defaults.bool(forKey: DefaultsKey.showCountdown),
                       endDate: manager.endDate)

        // Compose the title from the keep-awake countdown (when shown) followed by
        // the pinned live metrics. Built attributed so the memory pressure dot can
        // carry its green/yellow/red color; all other runs stay adaptive.
        let title = NSMutableAttributedString()
        // Transfers come first, so they sit right beside the icon and a click
        // on them can be told from a click on anything after them.
        var transferWidth: CGFloat = 0
        if let transferTitle = Self.transferTitle(for: TransferService.shared.activity,
                                                  defaults: defaults) {
            let measured = NSMutableAttributedString(string: " ")
            measured.append(transferTitle)
            measured.addAttribute(.font,
                                  value: MenuBarRenderer.statusFont(stacked: false),
                                  range: NSRange(location: 0, length: measured.length))
            transferWidth = ceil(measured.size().width)
            title.append(transferTitle)
        }
        renderedTransferWidth = transferWidth
        let includesTransfer = transferWidth > 0
        var includesCountdown = false
        if manager.isActive, defaults.bool(forKey: DefaultsKey.showCountdown) {
            let countdown: String
            if let end = manager.endDate {
                let remaining = max(0, Int(end.timeIntervalSinceNow))
                let hours = remaining / 3600
                let minutes = (remaining % 3600) / 60
                countdown = hours > 0 ? String(format: "%d:%02d", hours, minutes) : "\(max(minutes, 1)) min"
            } else {
                countdown = "∞"
            }
            if title.length > 0 { title.append(NSAttributedString(string: "  ")) }
            title.append(NSAttributedString(string: countdown))
            includesCountdown = true
        }
        if separateMetrics {
            refreshMetricStatusItems(metrics: metrics, snapshot: snapshot, strings: strings)
        } else {
            removeMetricStatusItems(except: Set<String>())
            renderedMetricItemCount = 0
        }
        if !separateMetrics, !metrics.isEmpty {
            let metricsTitle = MenuBarRenderer.attributed(for: snapshot,
                                                          metrics: metrics,
                                                          allowStacked: !includesCountdown && !includesTransfer,
                                                          linePrefix: " ")
            if metricsTitle.length > 0 {
                if title.length > 0 { title.append(NSAttributedString(string: "  ")) }
                title.append(metricsTitle)
            }
        }

        // Every write below invalidates the button's layout and redraws the
        // status window even when the value is identical — and this runs on
        // every monitor tick and defaults change. Rounded metric strings
        // repeat most ticks, so skipping no-op writes skips that churn.
        if statusItem.length != NSStatusItem.variableLength {
            statusItem.length = NSStatusItem.variableLength
        }

        if title.length == 0 {
            if button.attributedTitle.length != 0 {
                button.attributedTitle = NSAttributedString(string: "")
            }
            if button.imagePosition != .imageOnly {
                button.imagePosition = .imageOnly
            }
        } else {
            // The leading space separates the glyph from the text; with the
            // glyph hidden by the metrics-only option or by Dynamic Island it
            // would be pure dead padding on the item's left edge. Same
            // decision inputs as updateIconAppearance, with a sentinel length:
            // the title is known non-empty on this branch.
            let updateAvailable: Bool
            if case .available = UpdateService.shared.state {
                updateAvailable = true
            } else {
                updateAvailable = false
            }
            let signal = updateAvailable || renderedMicBadgeActive
            let glyphHidden = (MenuBarSpacingSupport.islandHidesStatusIcon(
                in: defaults, hiddenInFullscreen: islandHiddenInFullscreen) && !signal)
                || MenuBarSpacingSupport.shouldHideStatusIcon(
                    optionEnabled: defaults.bool(forKey: DefaultsKey.menuBarHideIconWithMetrics),
                    separateMetrics: separateMetrics,
                    metricsEnabled: !metrics.isEmpty,
                    renderedTitleLength: 1,
                    mustShowForSignal: signal)
            let full = NSMutableAttributedString(string: glyphHidden ? "" : " ")
            full.append(title)
            let stacked = full.string.contains("\n")
            let font = MenuBarRenderer.statusFont(stacked: stacked)
            full.addAttribute(.font, value: font, range: NSRange(location: 0, length: full.length))
            if stacked {
                let paragraph = NSMutableParagraphStyle()
                paragraph.alignment = .left
                paragraph.lineBreakMode = .byClipping
                paragraph.minimumLineHeight = MenuBarRenderer.statusLineHeight(stacked: true)
                paragraph.maximumLineHeight = MenuBarRenderer.statusLineHeight(stacked: true)
                full.addAttribute(.paragraphStyle,
                                  value: paragraph,
                                  range: NSRange(location: 0, length: full.length))
                full.addAttribute(.baselineOffset,
                                  value: -0.4,
                                  range: NSRange(location: 0, length: full.length))
            }
            if !full.isEqual(to: button.attributedTitle) {
                button.font = font
                button.attributedTitle = full
            }
            if button.imagePosition != .imageLeading {
                button.imagePosition = .imageLeading
            }
        }

        let toolTip: String
        if manager.isActive {
            if manager.sessionTrigger == .automation {
                toolTip = FeatureStrings.keepAwakeAutomation(L10n.shared.language)
                    .activeStatus(for: manager.activeAutomationConditions)
            } else if let end = manager.endDate {
                toolTip = "\(strings.statusActiveUntil) \(Self.timeFormatter.string(from: end))"
            } else {
                toolTip = strings.statusActiveIndefinite
            }
        } else {
            toolTip = strings.statusIdleTooltip
        }
        if button.toolTip != toolTip {
            button.toolTip = toolTip
        }

        // The icon decision depends on the title just written (the glyph may
        // hide only while metrics actually render), so it re-runs here — the
        // one place where title and icon can never get out of step.
        updateIconAppearance()
    }

    private func refreshMetricStatusItems(metrics: [MenuBarMetric],
                                          snapshot: SystemSnapshot,
                                          strings: Strings) {
        let groups = Self.metricStatusGroups(for: metrics, strings: strings)
        let wanted = Set(groups.map(\.id))
        removeMetricStatusItems(except: wanted)
        var rendered = 0
        defer { renderedMetricItemCount = rendered }

        for group in groups {
            let title = MenuBarRenderer.attributed(for: snapshot,
                                                   metrics: group.metrics,
                                                   allowStacked: false)
            let empties = title.length > 0 ? 0 : (metricEmptyRenders[group.id] ?? 0) + 1
            metricEmptyRenders[group.id] = empties
            guard MenuBarSpacingSupport.keepsMetricStatusItem(
                hasRenderedTitle: title.length > 0,
                itemExists: metricStatusItems[group.id] != nil,
                consecutiveEmptyRenders: empties) else {
                // The reading has been gone long enough to call it gone.
                removeMetricStatusItem(for: group.id)
                continue
            }
            if title.length > 0 { rendered += 1 }

            metricStatusItemFocus[group.id] = group.focusMetric
            let item = metricStatusItems[group.id] ?? installMetricStatusItem(for: group)
            if item.length != NSStatusItem.variableLength {
                item.length = NSStatusItem.variableLength
            }
            guard let button = item.button else { continue }

            let full = NSMutableAttributedString(attributedString: title)
            let font = MenuBarRenderer.statusFont(stacked: false)
            full.addAttribute(.font,
                              value: font,
                              range: NSRange(location: 0, length: full.length))
            if button.font?.isEqual(font) != true {
                button.font = font
            }
            if !full.isEqual(to: button.attributedTitle) {
                button.attributedTitle = full
            }
            if button.image !== Self.emptyStatusImage {
                button.image = Self.emptyStatusImage
            }
            if button.imagePosition != .noImage {
                button.imagePosition = .noImage
            }
            if button.toolTip != group.title {
                button.toolTip = group.title
            }
        }
    }

    /// How the enabled metrics split into separate items. Static so the
    /// Settings preview draws the same split the bar does.
    static func metricStatusGroups(for metrics: [MenuBarMetric], strings: Strings) -> [MetricStatusGroup] {
        guard MenuBarMetricAppearance.current.allowsCombinedTemperatures,
              UserDefaults.standard.bool(forKey: DefaultsKey.menuBarCombineTemperatures) else {
            return metrics.map {
                MetricStatusGroup(id: $0.rawValue, metrics: [$0], focusMetric: $0, title: $0.title(strings))
            }
        }

        let enabled = Set(metrics)
        var emittedIDs = Set<String>()
        var groups: [MetricStatusGroup] = []

        func appendComponentGroup(id: String,
                                  primary: MenuBarMetric,
                                  temperature: MenuBarMetric,
                                  primaryTitle: String) {
            guard emittedIDs.insert(id).inserted else { return }
            var groupedMetrics: [MenuBarMetric] = []
            if enabled.contains(primary) { groupedMetrics.append(primary) }
            if enabled.contains(temperature) { groupedMetrics.append(temperature) }
            guard let focusMetric = groupedMetrics.first else { return }
            let title = groupedMetrics.count > 1 ? primaryTitle : focusMetric.title(strings)
            groups.append(MetricStatusGroup(id: id,
                                            metrics: groupedMetrics,
                                            focusMetric: focusMetric,
                                            title: title))
        }

        for metric in metrics {
            switch metric {
            case .cpu, .cpuTemperature:
                appendComponentGroup(id: "cpu",
                                     primary: .cpu,
                                     temperature: .cpuTemperature,
                                     primaryTitle: strings.monitorShowCPU)
            case .gpu, .gpuTemperature:
                appendComponentGroup(id: "gpu",
                                     primary: .gpu,
                                     temperature: .gpuTemperature,
                                     primaryTitle: strings.monitorShowGPU)
            case .battery, .batteryTemperature:
                appendComponentGroup(id: "battery",
                                     primary: .battery,
                                     temperature: .batteryTemperature,
                                     primaryTitle: strings.batteryLabel)
            case .memory, .network, .diskUsage, .diskActivity, .batteryTime, .peripheralBattery, .power,
                 .fanSpeed, .connectedDevices:
                let id = metric.rawValue
                guard emittedIDs.insert(id).inserted else { continue }
                groups.append(MetricStatusGroup(id: id,
                                                metrics: [metric],
                                                focusMetric: metric,
                                                title: metric.title(strings)))
            }
        }

        return groups
    }

    private func installMetricStatusItem(for group: MetricStatusGroup) -> NSStatusItem {
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        item.autosaveName = "\(Self.metricAutosavePrefix).\(group.id)"
        item.behavior = []
        // Registered before it is shown: showing it writes its remembered
        // position and announces that write while this call is still on the
        // stack, and an unregistered item would be built all over again by
        // whoever answers that announcement.
        metricStatusItems[group.id] = item
        metricStatusItemFocus[group.id] = group.focusMetric
        item.isVisible = true
        if let button = item.button {
            button.font = MenuBarRenderer.statusFont(stacked: false)
            button.alignment = .left
            button.cell?.lineBreakMode = .byClipping
            button.cell?.usesSingleLineMode = true
            button.target = self
            button.action = #selector(metricClicked(_:))
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
            button.identifier = NSUserInterfaceItemIdentifier("\(Self.metricAutosavePrefix).\(group.id)")
        }
        return item
    }

    @objc private func metricClicked(_ sender: NSStatusBarButton) {
        if NSApp.currentEvent?.type == .rightMouseUp {
            onRightClick?(sender)
            return
        }
        guard let metric = focusMetric(from: sender) else {
            onLeftClick?()
            return
        }
        onMetricClick?(metric, sender)
    }

    private func focusMetric(from button: NSStatusBarButton) -> MenuBarMetric? {
        let prefix = "\(Self.metricAutosavePrefix)."
        guard let identifier = button.identifier?.rawValue,
              identifier.hasPrefix(prefix) else { return nil }
        return metricStatusItemFocus[String(identifier.dropFirst(prefix.count))]
    }

    private func removeMetricStatusItems(except wanted: Set<String>) {
        let staleMetrics = metricStatusItems.keys.filter { !wanted.contains($0) }
        for id in staleMetrics {
            removeMetricStatusItem(for: id)
        }
    }

    private func removeMetricStatusItem(for id: String) {
        metricStatusItemFocus.removeValue(forKey: id)
        metricEmptyRenders.removeValue(forKey: id)
        guard let item = metricStatusItems.removeValue(forKey: id) else { return }
        NSStatusBar.system.removeStatusItem(item)
    }

    // MARK: - Clipboard preview item

    /// Creates or removes the clipboard preview item for the feature itself
    /// being on or off, and keeps its text current while it exists — hidden
    /// rather than removed when there is simply nothing to show, so it never
    /// sits in the bar as a bare empty gap.
    /// Runs on every entries/isRunning change and on every settings sync, so
    /// toggling the option or the character limit takes effect immediately.
    private func syncClipboardPreviewItem() {
        let defaults = UserDefaults.standard
        // Checked before ever touching ClipboardHistoryService.shared: merely
        // referencing it brings the whole service to life — its saved history
        // file and image folder included — and this runs on every settings
        // change, not just clipboard ones.
        guard AppFeature.clipboardHistory.isAvailable,
              defaults.bool(forKey: DefaultsKey.clipboardHistoryEnabled),
              defaults.bool(forKey: DefaultsKey.clipboardHistoryMenuBarPreview)
        else {
            removeClipboardPreviewStatusItem()
            return
        }
        let history = ClipboardHistoryService.shared
        guard history.isRunning else {
            removeClipboardPreviewStatusItem()
            return
        }

        // The feature itself is on; keep the item itself alive even with
        // nothing to show right now (e.g. right after Clear All) rather than
        // removing it — macOS does not reliably restore a dragged position
        // for an item recreated later, so removing it would land it back at
        // the default spot the next time something is copied. Hidden rather
        // than shown blank, though: an empty title would otherwise sit in
        // the bar as a bare gap.
        //
        // No fallback to recentEntries here: latestPasteboardEntry is
        // matched against the pasteboard's real content as soon as history
        // starts watching (at launch, and whenever the feature is toggled
        // back on) and kept correct from then on (nil means the pasteboard
        // was actually cleared, or the last change was deliberately not
        // recorded), so falling back to history would undo exactly that —
        // e.g. auto clear wiping the pasteboard while the entry stays in
        // history.
        let entry = history.latestPasteboardEntry
        let maxCharacters = Defaults.sanitizedClipboardMenuBarPreviewLength(
            defaults.integer(forKey: DefaultsKey.clipboardHistoryMenuBarPreviewLength))
        let text = entry?.menuBarText(maxCharacters: maxCharacters) ?? ""

        let item = clipboardPreviewStatusItem ?? installClipboardPreviewStatusItem()
        if item.length != NSStatusItem.variableLength {
            item.length = NSStatusItem.variableLength
        }
        if item.isVisible != (entry != nil) {
            item.isVisible = entry != nil
        }
        guard let button = item.button else { return }
        // A non-nil empty image, not the metric items' actual glyph: same
        // reasoning as their own emptyStatusImage use, so this text also
        // dims correctly on an inactive display instead of staying full
        // strength beside metrics that do.
        if button.image !== Self.emptyStatusImage {
            button.image = Self.emptyStatusImage
        }
        if button.imagePosition != .noImage {
            button.imagePosition = .noImage
        }
        let font = MenuBarRenderer.statusFont(stacked: false)
        if button.font?.isEqual(font) != true {
            button.font = font
        }
        if button.title != text {
            button.title = text
        }
        // menuBarText again rather than entry.preview directly: preview's
        // .files case joins every file name with no bound of its own, so a
        // large batch of files would otherwise make an unbounded tooltip.
        // tooltipCharacters, not previewCharacters: previewCharacters is
        // sized for a list row's three lines, which would still let a whole
        // page of copied prose through as a hover tooltip.
        let tooltip = entry?.menuBarText(maxCharacters: ClipboardHistoryEditing.tooltipCharacters) ?? ""
        if button.toolTip != tooltip {
            button.toolTip = tooltip
        }
    }

    private func installClipboardPreviewStatusItem() -> NSStatusItem {
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        item.autosaveName = Self.clipboardPreviewAutosaveName
        item.behavior = []
        // Registered before it is shown, for the same reason as
        // installMetricStatusItem: showing it writes and announces its
        // remembered position while this call is still on the stack.
        clipboardPreviewStatusItem = item
        item.isVisible = true
        if let button = item.button {
            button.font = MenuBarRenderer.statusFont(stacked: false)
            button.alignment = .left
            button.cell?.lineBreakMode = .byClipping
            button.cell?.usesSingleLineMode = true
            button.target = self
            button.action = #selector(clipboardPreviewClicked)
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
        }
        return item
    }

    @objc private func clipboardPreviewClicked() {
        if NSApp.currentEvent?.type == .rightMouseUp {
            onRightClick?(clipboardPreviewStatusItem?.button)
            return
        }
        onClipboardPreviewClick?()
    }

    private func removeClipboardPreviewStatusItem() {
        guard let item = clipboardPreviewStatusItem else { return }
        clipboardPreviewStatusItem = nil
        NSStatusBar.system.removeStatusItem(item)
    }
}

/// The official mark, bundled as a template image so the idle state adapts to
/// light and dark menu bars. Active states can use real colors for attention.
/// A system symbol named in the menu bar settings can take the mark's place.
enum BlackHoleGlyph {
    /// Logical size of the glyph in the menu bar, in points. Wide because the
    /// mark is ~1.97:1 and sized from its height. Tools/MakeIcon.swift writes
    /// the bundled PNGs at this size; `--selftest` checks the two still agree.
    static let pointSize = NSSize(width: 26, height: 20)

    /// Requested ink height for the active states' system symbols. A compact
    /// symbol has to stand taller than the wide mark to read as the same size,
    /// matching the menu bar's other compact icons at ~15 pt. Antialiasing
    /// costs about a point of what is asked for here.
    private static let symbolHeight: CGFloat = 16

    /// Both scale representations go into one NSImage — loading the 1x file
    /// alone would render blurry on Retina menu bars.
    private static let base: NSImage? = {
        let image = NSImage(size: pointSize)
        for resource in ["MenuBarIcon", "MenuBarIcon@2x"] {
            guard let url = Bundle.main.url(forResource: resource, withExtension: "png"),
                  let data = try? Data(contentsOf: url),
                  let rep = NSBitmapImageRep(data: data)
            else { continue }
            rep.size = pointSize
            image.addRepresentation(rep)
        }
        guard !image.representations.isEmpty else { return nil }
        image.isTemplate = true
        return image
    }()

    /// The symbol named in the menu bar settings, empty for the mark.
    static var chosenSymbolName: String {
        Defaults.sanitizedMenuBarIconSymbol(
            UserDefaults.standard.string(forKey: DefaultsKey.menuBarIconSymbol))
    }

    /// What every state starts from: the chosen symbol, or the bundled mark
    /// when none is chosen or this Mac has no symbol by that name.
    static func mark(symbolName: String = BlackHoleGlyph.chosenSymbolName) -> NSImage? {
        customMark(named: symbolName) ?? base
    }

    /// A system symbol on the canvas the active symbols use, or nil when
    /// this Mac has no symbol by that name: a typo, or a name from a newer
    /// macOS that came with a settings backup.
    static func customMark(named name: String) -> NSImage? {
        guard !name.isEmpty else { return nil }
        return fixedSizeSymbol(named: name)
    }

    static func image(active: Bool) -> NSImage? {
        let tint = KeepAwakeIconTint.current
        guard active else { return mark() ?? fallback(active: false) }
        return activeImage(style: .current, tint: tint)
    }

    static func activeImage(style: KeepAwakeActiveIcon,
                            tint: KeepAwakeIconTint = .orange) -> NSImage? {
        let source: NSImage?
        if let symbolName = style.systemSymbolName {
            source = fixedSizeSymbol(named: symbolName, drop: style.menuBarDrop)
        } else {
            source = mark()
        }
        guard let source else { return fallback(active: tint != .none) }
        guard let color = color(for: tint) else {
            source.isTemplate = true
            return source
        }
        return tintedImage(source, color: color) ?? fallback(active: true)
    }

    /// System symbols have different natural widths. Center them inside the
    /// same canvas as the app glyph so activation never shifts nearby items.
    ///
    /// Sized by the symbol's ink rather than its bounding box: SF Symbols pad
    /// their box by different amounts, so fitting the box leaves each style a
    /// different, smaller size than asked for.
    private static func fixedSizeSymbol(named name: String, drop: CGFloat = 0) -> NSImage? {
        guard let symbol = NSImage(systemSymbolName: name, accessibilityDescription: nil)?
            .withSymbolConfiguration(.init(pointSize: 15, weight: .semibold)),
              symbol.size.width > 0,
              symbol.size.height > 0,
              let ink = inkBounds(of: symbol),
              ink.width > 0, ink.height > 0 else { return nil }
        let scale = min(symbolHeight / ink.height, (pointSize.width - 2) / ink.width)
        let drawSize = NSSize(width: symbol.size.width * scale,
                              height: symbol.size.height * scale)
        // Offsets used to center the ink rather than the padded box.
        let inkOrigin = NSPoint(x: ink.minX * scale, y: ink.minY * scale)
        let inkSize = NSSize(width: ink.width * scale, height: ink.height * scale)
        let image = NSImage(size: pointSize, flipped: false) { rect in
            let target = NSRect(x: rect.midX - inkOrigin.x - inkSize.width / 2,
                                y: rect.midY - inkOrigin.y - inkSize.height / 2 - drop,
                                width: drawSize.width,
                                height: drawSize.height)
            symbol.draw(in: target, from: .zero, operation: .sourceOver, fraction: 1)
            return true
        }
        image.isTemplate = true
        return image
    }

    /// Bounding box of an image's visible pixels, in its own (bottom-up) point
    /// space. Only runs when the menu bar icon changes, so rasterizing is cheap.
    private static func inkBounds(of image: NSImage) -> NSRect? {
        let sampling = 2
        let wide = Int(ceil(image.size.width)) * sampling
        let high = Int(ceil(image.size.height)) * sampling
        guard wide > 0, high > 0,
              let rep = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: wide, pixelsHigh: high,
                                         bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
                                         isPlanar: false, colorSpaceName: .deviceRGB,
                                         bytesPerRow: 0, bitsPerPixel: 0),
              let context = NSGraphicsContext(bitmapImageRep: rep) else { return nil }
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = context
        // The context comes from the rep's pixel dimensions, so it draws in
        // pixels; fill the whole bitmap and scale the bounds back down. A
        // point-sized rect here would only cover a corner of it.
        image.draw(in: NSRect(x: 0, y: 0, width: CGFloat(wide), height: CGFloat(high)))
        NSGraphicsContext.restoreGraphicsState()

        var minX = wide, minY = high, maxX = -1, maxY = -1
        for y in 0..<high {
            for x in 0..<wide where (rep.colorAt(x: x, y: y)?.alphaComponent ?? 0) > 0.05 {
                minX = min(minX, x); maxX = max(maxX, x)
                minY = min(minY, y); maxY = max(maxY, y)
            }
        }
        guard maxX >= minX, maxY >= minY else { return nil }
        // colorAt() reads top-down; NSImage coordinates run bottom-up.
        let unit = CGFloat(sampling)
        return NSRect(x: CGFloat(minX) / unit,
                      y: CGFloat(high - 1 - maxY) / unit,
                      width: CGFloat(maxX - minX + 1) / unit,
                      height: CGFloat(maxY - minY + 1) / unit)
    }

    /// A blue, full-strength glyph used to flag an available update. Non-template
    /// (a real color), drawn by masking blue into the glyph's shape.
    static func attentionImage() -> NSImage? {
        guard let glyph = mark() else { return fallback(active: true) }
        return tintedImage(glyph, color: .systemBlue) ?? fallback(active: true)
    }

    /// The given state image with a red slashed microphone beside it, shown
    /// while the mute indicator option is on and the mic is muted. The badge
    /// is a real color, so the composite can't stay a template image; the
    /// drawing handler runs against the destination appearance, which keeps a
    /// template underlying glyph legible on both light and dark menu bars.
    static func micMutedImage(over underlying: NSImage?) -> NSImage? {
        guard let underlying else { return nil }
        guard let badge = NSImage(systemSymbolName: "mic.slash.fill",
                                  accessibilityDescription: nil)?
            .withSymbolConfiguration(.init(pointSize: 12, weight: .semibold)) else { return nil }
        let gap: CGFloat = 2
        let badgeSize = badge.size
        let height = max(underlying.size.height, badgeSize.height)
        let size = NSSize(width: underlying.size.width + gap + badgeSize.width, height: height)
        let composed = NSImage(size: size, flipped: false) { _ in
            let glyphRect = NSRect(x: 0, y: (height - underlying.size.height) / 2,
                                   width: underlying.size.width, height: underlying.size.height)
            underlying.draw(in: glyphRect, from: .zero, operation: .sourceOver, fraction: 1)
            if underlying.isTemplate {
                // Template pixels carry no usable color of their own.
                NSColor.labelColor.setFill()
                glyphRect.fill(using: .sourceAtop)
            }
            let badgeRect = NSRect(x: underlying.size.width + gap,
                                   y: (height - badgeSize.height) / 2,
                                   width: badgeSize.width, height: badgeSize.height)
            badge.draw(in: badgeRect, from: .zero, operation: .sourceOver, fraction: 1)
            NSColor.systemRed.setFill()
            badgeRect.fill(using: .sourceAtop)
            return true
        }
        composed.isTemplate = false
        return composed
    }

    private static func tintedImage(_ source: NSImage, color: NSColor) -> NSImage? {
        let tinted = NSImage(size: source.size, flipped: false) { rect in
            source.draw(in: rect, from: .zero, operation: .sourceOver, fraction: 1)
            color.setFill()
            rect.fill(using: .sourceAtop)
            return true
        }
        tinted.isTemplate = false
        return tinted
    }

    private static func color(for tint: KeepAwakeIconTint) -> NSColor? {
        switch tint {
        case .orange: return .systemOrange
        case .green: return .systemGreen
        case .blue: return .systemBlue
        case .purple: return .systemPurple
        case .pink: return .systemPink
        case .none: return nil
        }
    }

    /// Keeps a recognizable presence if the bundled asset is ever missing
    /// (e.g. running the bare binary from build/).
    private static func fallback(active: Bool) -> NSImage? {
        if let symbol = NSImage(systemSymbolName: "circle.fill", accessibilityDescription: AppInfo.name)?
            .withSymbolConfiguration(.init(pointSize: 13, weight: active ? .bold : .regular)) {
            symbol.isTemplate = true
            return symbol
        }
        // Guaranteed last resort: draw a filled circle so the button always has a
        // visible, clickable image and can never become a zero-width, invisible item.
        let drawn = NSImage(size: NSSize(width: 14, height: 14), flipped: false) { rect in
            NSColor.black.setFill()
            NSBezierPath(ovalIn: rect.insetBy(dx: 2, dy: 2)).fill()
            return true
        }
        drawn.isTemplate = true
        return drawn
    }
}
